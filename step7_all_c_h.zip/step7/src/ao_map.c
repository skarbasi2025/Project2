/* ao_map.c - maps a source to 0..1000 per mille of the output's full scale. */
#include "ao_map.h"

static uint16_t clamp1000(uint32_t v) { return (uint16_t)(v > 1000u ? 1000u : v); }

uint16_t ao_permille(uint16_t src, const ao_in_t *in)
{
    switch (src) {
    case AO_SRC_AMPL:                                   /* 0..100 % -> 0..10 V */
        return clamp1000(in->amplitude);
    case AO_SRC_FREQ: {                                 /* f_min..f_max -> 0..10 V */
        if (in->f_max <= in->f_min) return 0;
        if (in->freq <= in->f_min) return 0;
        return clamp1000(((uint32_t)(in->freq - in->f_min) * 1000u) / (uint32_t)(in->f_max - in->f_min));
    }
    case AO_SRC_VBUS:
        return in->v_fs ? clamp1000((uint32_t)in->vbus * 1000u / in->v_fs) : 0;
    case AO_SRC_IBUS:
        return in->i_fs ? clamp1000((uint32_t)in->ibus * 1000u / in->i_fs) : 0;
    case AO_SRC_TEMP:                                   /* 0..t_max -> 0..10 V, below 0 C is 0 V */
        if (in->temp <= 0 || in->t_max == 0) return 0;
        return clamp1000((uint32_t)in->temp * 1000u / in->t_max);
    default:
        return 0;
    }
}
