/* lcd.c - HD44780 20x4 through a PCF8574 backpack on PB6 (SCL) / PB7 (SDA), open-drain, pull-ups on the backpack.
 * On the target the bus is the hardware I2C1 (polled, with timeouts): the LCD then costs almost no CPU time.
 * The bit-banged version (below) stays for the host tests (HOST_TEST), where I2C1 does not exist.
 * Bit-banging with busy-wait delays made every LCD write very slow in simulation (the delays scale with the
 * clock), so it is kept only where there is no I2C1.                                  */
#include "lcd.h"
#include "board.h"
#include "delay.h"

static uint8_t g_bl = PCF_BL;       /* backlight bit, on by default */
static uint8_t g_disp_ctrl;
static uint8_t g_ack_ok;
static char    g_shadow[LCD_ROWS][LCD_COLS];   /* what each row shows now: unchanged rows are not resent */
static uint8_t g_shadow_ok[LCD_ROWS];

static void shadow_invalidate(void)
{
    for (uint8_t r = 0; r < LCD_ROWS; r++) g_shadow_ok[r] = 0;
}

#if LCD_USE_HW_I2C && !defined(HOST_TEST)
#define LCD_HW_I2C 1
#endif

#if defined(LCD_HW_I2C)
/* ---------- hardware I2C1 (master, polled) ---------- */
#define I2C_TMO        20000u                          /* poll loops before giving up (about a few ms) */
#define I2C_PCLK1_HZ   APB1_HZ                         /* from board.h */
#define I2C_CR1_PE_BIT    (1u << 0)
#define I2C_CR1_SWRST_BIT (1u << 15)
#define I2C_CR1_START_BIT (1u << 8)
#define I2C_CR1_STOP_BIT  (1u << 9)
#define I2C_SR1_SB_BIT    (1u << 0)
#define I2C_SR1_ADDR_BIT  (1u << 1)
#define I2C_SR1_BTF_BIT   (1u << 2)
#define I2C_SR1_TXE_BIT   (1u << 7)
#define I2C_SR1_AF_BIT    (1u << 10)
#define I2C_SR2_BUSY_BIT  (1u << 1)

static void hw_i2c_reset(void)
{
    I2C1->CR1 |= I2C_CR1_SWRST_BIT;
    I2C1->CR1 &= (uint32_t)~I2C_CR1_SWRST_BIT;
    I2C1->CR1 |= I2C_CR1_PE_BIT;
}

static void i2c_bus_init(void)
{
    RCC->APB1ENR |= (1u << 21);                        /* I2C1 clock */
    gpio_set(I2C_SCL_PORT, I2C_SCL_PIN);
    gpio_set(I2C_SDA_PORT, I2C_SDA_PIN);
    gpio_cfg(I2C_SCL_PORT, I2C_SCL_PIN, 0xFu);         /* alternate function open-drain, 50 MHz */
    gpio_cfg(I2C_SDA_PORT, I2C_SDA_PIN, 0xFu);
    I2C1->CR1 = 0;
    I2C1->CR2 = I2C_PCLK1_HZ / 1000000u;               /* peripheral clock in MHz */
    I2C1->CCR = I2C_PCLK1_HZ / (2u * 100000u);         /* 100 kHz standard mode */
    I2C1->TRISE = I2C_PCLK1_HZ / 1000000u + 1u;        /* 1000 ns rise time */
    I2C1->CR1 = I2C_CR1_PE_BIT;
}

/* one transfer: START, address (write), the bytes, STOP. Returns 1 if the LCD acknowledged. */
static int hw_send(const uint8_t *d, uint8_t n)
{
    uint32_t t = I2C_TMO;
    while ((I2C1->SR2 & I2C_SR2_BUSY_BIT) && --t) { }
    if (!t) { hw_i2c_reset(); return 0; }

    I2C1->CR1 |= I2C_CR1_START_BIT;
    t = I2C_TMO; while (!(I2C1->SR1 & I2C_SR1_SB_BIT) && --t) { }
    if (!t) { hw_i2c_reset(); return 0; }

    I2C1->DR = (uint8_t)(LCD_I2C_ADDR << 1);
    t = I2C_TMO; while (!(I2C1->SR1 & (I2C_SR1_ADDR_BIT | I2C_SR1_AF_BIT)) && --t) { }
    if (!t || (I2C1->SR1 & I2C_SR1_AF_BIT)) {          /* no ACK: nobody at this address */
        I2C1->SR1 &= (uint32_t)~I2C_SR1_AF_BIT;
        I2C1->CR1 |= I2C_CR1_STOP_BIT;
        hw_i2c_reset();
        return 0;
    }
    (void)I2C1->SR1; (void)I2C1->SR2;                  /* clear ADDR */

    for (uint8_t i = 0; i < n; i++) {
        t = I2C_TMO; while (!(I2C1->SR1 & I2C_SR1_TXE_BIT) && --t) { }
        if (!t) { hw_i2c_reset(); return 0; }
        I2C1->DR = d[i];
    }
    t = I2C_TMO; while (!(I2C1->SR1 & I2C_SR1_BTF_BIT) && --t) { }
    I2C1->CR1 |= I2C_CR1_STOP_BIT;
    return t != 0u;
}
#else
/* ---------- bit-banged I2C (master only, no clock stretching): host tests only ---------- */
static void scl_hi(void) { gpio_set(I2C_SCL_PORT, I2C_SCL_PIN); delay_us(I2C_HALF_US); }
static void scl_lo(void) { gpio_clr(I2C_SCL_PORT, I2C_SCL_PIN); delay_us(I2C_HALF_US); }
static void sda_hi(void) { gpio_set(I2C_SDA_PORT, I2C_SDA_PIN); }
static void sda_lo(void) { gpio_clr(I2C_SDA_PORT, I2C_SDA_PIN); }

static void i2c_start(void)
{
    sda_hi(); scl_hi();
    sda_lo(); delay_us(I2C_HALF_US);
    scl_lo();
}

static void i2c_stop(void)
{
    sda_lo(); scl_hi();
    sda_hi(); delay_us(I2C_HALF_US);
}

static int i2c_write(uint8_t b)          /* returns 1 if the slave acknowledged */
{
    for (int i = 7; i >= 0; i--) {
        if (b & (1u << i)) sda_hi(); else sda_lo();
        delay_us(1);
        scl_hi();
        scl_lo();
    }
    sda_hi();                            /* release SDA for the ACK bit */
    delay_us(1);
    scl_hi();
    int ack = !gpio_get(I2C_SDA_PORT, I2C_SDA_PIN);
    scl_lo();
    return ack;
}

static void i2c_bus_init_bb(void)
{
    gpio_set(I2C_SCL_PORT, I2C_SCL_PIN);
    gpio_set(I2C_SDA_PORT, I2C_SDA_PIN);
    gpio_cfg(I2C_SCL_PORT, I2C_SCL_PIN, GPIO_OUT_OD_2MHZ);
    gpio_cfg(I2C_SDA_PORT, I2C_SDA_PIN, GPIO_OUT_OD_2MHZ);
}

#endif /* LCD_HW_I2C */

/* send up to 4 bytes to the PCF8574 in one transfer */
static void pcf_send(const uint8_t *d, uint8_t n)
{
#if defined(LCD_HW_I2C)
    g_ack_ok = (uint8_t)hw_send(d, n);
#else
    int ok;
    i2c_start();
    ok = i2c_write((uint8_t)(LCD_I2C_ADDR << 1));
    for (uint8_t i = 0; i < n; i++) i2c_write(d[i]);
    i2c_stop();
    g_ack_ok = (uint8_t)ok;
#endif
}

/* ---------- HD44780 over the PCF8574 ---------- */
static void write_nibble(uint8_t n, uint8_t rs)           /* used only during the reset sequence */
{
    uint8_t v = (uint8_t)((n << 4) | g_bl | (rs ? PCF_RS : 0));
    uint8_t d[2] = { (uint8_t)(v | PCF_E), v };            /* E high, then E low (latch) */
    pcf_send(d, 2);
}

static void write_byte(uint8_t b, uint8_t rs)
{
    uint8_t base = (uint8_t)(g_bl | (rs ? PCF_RS : 0));
    uint8_t hi = (uint8_t)((b & 0xF0u) | base);
    uint8_t lo = (uint8_t)(((b << 4) & 0xF0u) | base);
    uint8_t d[4] = { (uint8_t)(hi | PCF_E), hi, (uint8_t)(lo | PCF_E), lo };
    pcf_send(d, 4);                                        /* the transfer itself takes > 100 us */
}

static void cmd(uint8_t c) { write_byte(c, 0); }

#if !defined(LCD_HW_I2C)
#define i2c_bus_init i2c_bus_init_bb
#endif

int lcd_init(void)
{
    i2c_bus_init();
    delay_ms(50);                          /* LCD supply settle time */
    write_nibble(0x3, 0); delay_ms(5);
    write_nibble(0x3, 0); delay_us(150);
    write_nibble(0x3, 0); delay_us(150);
    write_nibble(0x2, 0); delay_us(150);   /* 4-bit mode */
    cmd(0x28);                             /* 4-bit, 2 line mode (4-line LCDs use the same setting), 5x8 font */
    cmd(0x08);                             /* display off */
    lcd_clear();
    cmd(0x06);                             /* entry mode: increment */
    g_disp_ctrl = 0x0C;                    /* display on, cursor off, blink off */
    cmd(g_disp_ctrl);
    return g_ack_ok;
}

int lcd_present(void) { return g_ack_ok; }

void lcd_clear(void)
{
    shadow_invalidate();
    cmd(0x01);
    delay_ms(2);
}

void lcd_goto(uint8_t row, uint8_t col)
{
    static const uint8_t row_addr[LCD_ROWS] = { 0x00, 0x40, 0x14, 0x54 };
    if (row >= LCD_ROWS) row = LCD_ROWS - 1;
    if (col >= LCD_COLS) col = LCD_COLS - 1;
    cmd((uint8_t)(0x80u | (row_addr[row] + col)));
}

void lcd_putc(char c)
{
    shadow_invalidate();            /* free-position writes: the row cache is no longer valid */
    write_byte((uint8_t)c, 1);
}

void lcd_puts(const char *s)
{
    while (*s) lcd_putc(*s++);
}

void lcd_line(uint8_t row, const char *s)
{
    char n[LCD_COLS];
    if (row >= LCD_ROWS) return;
    for (uint8_t i = 0; i < LCD_COLS; i++) n[i] = *s ? *s++ : ' ';
    /* send only the span between the first and the last changed character */
    uint8_t first = 0, last = LCD_COLS - 1;
    if (g_shadow_ok[row]) {
        while (first < LCD_COLS && n[first] == g_shadow[row][first]) first++;
        if (first == LCD_COLS) return;                     /* row unchanged */
        while (n[last] == g_shadow[row][last]) last--;
    }
    lcd_goto(row, first);
    for (uint8_t i = first; i <= last; i++) {
        write_byte((uint8_t)n[i], 1);
        g_shadow[row][i] = n[i];
    }
    if (first == 0 && last == LCD_COLS - 1) g_shadow_ok[row] = 1;

}

void lcd_cursor(uint8_t on)
{
    if (on) g_disp_ctrl |= 0x02u; else g_disp_ctrl &= (uint8_t)~0x02u;
    cmd(g_disp_ctrl);
}

void lcd_backlight(uint8_t on)
{
    g_bl = on ? PCF_BL : 0;
    uint8_t d = g_bl;
    pcf_send(&d, 1);
}
