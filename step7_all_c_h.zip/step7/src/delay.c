/* delay.c - microsecond delay with the DWT cycle counter, millisecond tick.
 *
 * Two ways to build it:
 *  - Project made by STM32CubeMX (HAL, macro USE_HAL_DRIVER is defined): the HAL already
 *    owns SysTick, so millis() simply returns HAL_GetTick().
 *  - Bare project without HAL: this file starts SysTick itself (1 ms).            */
#include "delay.h"
#include "stm32f1xx.h"

/* Some simulators (Proteus) do not implement the DWT cycle counter: it stays at 0 and a
 * busy wait on it would never end. dwt_start() checks that it counts; if not, delay_us()
 * falls back to a plain software loop (less accurate, still fine for the LCD / keypad). */
static uint8_t g_dwt_ok;

static void dwt_start(void)
{
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CYCCNT = 0;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
    for (volatile int i = 0; i < 16; i++) { }
    g_dwt_ok = (DWT->CYCCNT != 0u);
}

#ifdef USE_HAL_DRIVER
#include "stm32f1xx_hal.h"

void delay_init(void)
{
    dwt_start();
    /* If main() is ours and HAL_Init() was never called, SysTick is not running and
     * HAL_GetTick() would stay 0. Start it here (1 ms). CubeMX's SysTick_Handler in
     * stm32f1xx_it.c calls HAL_IncTick(). If HAL_Init() already ran, SysTick is on: untouched. */
    if (!(SysTick->CTRL & SysTick_CTRL_ENABLE_Msk))
        SysTick_Config(SystemCoreClock / 1000u);
}

uint32_t millis(void)
{
    return HAL_GetTick();
}

#else  /* no HAL */

#if defined(__ICCARM__)
#define WEAK __weak                       /* IAR */
#else
#define WEAK __attribute__((weak))        /* GCC / Keil (armclang) */
#endif

/* A weak default so the file also works outside a CubeMX project.
 * A real SystemCoreClock (system_stm32f1xx.c or your clock code) overrides it. */
WEAK uint32_t SystemCoreClock = 8000000u;

static volatile uint32_t g_ms;

void SysTick_Handler(void)
{
    g_ms++;
}

void delay_init(void)
{
    dwt_start();
    SysTick_Config(SystemCoreClock / 1000u);
}

uint32_t millis(void)
{
    return g_ms;
}

#endif

void delay_us(uint32_t us)
{
    if (!g_dwt_ok) {                      /* software fallback, about 4 cycles per pass */
        uint32_t n = us * (SystemCoreClock / 1000000u) / 4u + 1u;
        for (volatile uint32_t i = 0; i < n; i++) { }
        return;
    }
    uint32_t start = DWT->CYCCNT;
    uint32_t ticks = us * (SystemCoreClock / 1000000u);
    while ((uint32_t)(DWT->CYCCNT - start) < ticks) { }
}

void delay_ms(uint32_t ms)
{
    while (ms--) delay_us(1000u);
}
