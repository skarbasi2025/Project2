#include "regs.h"
#include "flash_store.h"

const reg_info_t reg_table[REG_COUNT] = {
#define X(id, a, n, u, mn, mx, df, fl) { (a), (n), (u), (mn), (mx), (df), (fl) },
    REG_LIST
#undef X
};

static uint16_t g_val[REG_COUNT];
static uint8_t  g_cmd_pending;     /* process command for control: start, stop, reset fault, reboot */
static uint8_t  g_cfg_cmd;         /* configuration command: save, defaults, apply comm */
static uint8_t  g_comm_dirty;
static uint8_t  g_loaded;
static uint8_t  g_dirty;           /* a saved register changed since the last flash save */
static uint8_t  g_auto_arm;        /* RS-485 wrote a saved register: (re)start the SAVE_DELAY timer */
static uint8_t  g_auto_wait;       /* timer running */
static uint32_t g_auto_due;

uint16_t reg_get(int idx) { return g_val[idx]; }

int32_t reg_val(int idx)
{
    return reg_is_signed(idx) ? (int32_t)(int16_t)g_val[idx] : (int32_t)g_val[idx];
}

void reg_set(int idx, int32_t v) { g_val[idx] = (uint16_t)v; }

static int is_comm(int idx) { return idx >= R_COM_ADDR && idx <= R_COM_T35; }

int reg_find(uint16_t addr)
{
    int lo = 0, hi = REG_COUNT - 1;                  /* table is sorted by address */
    while (lo <= hi) {
        int mid = (lo + hi) / 2;
        if (reg_table[mid].addr == addr) return mid;
        if (reg_table[mid].addr < addr) lo = mid + 1; else hi = mid - 1;
    }
    return -1;
}

/* standard baud rates / 100: 1200 2400 4800 9600 19200 38400 57600 115200 230400 */
static const uint16_t BAUD_LIST[] = { 12, 24, 48, 96, 192, 384, 576, 1152, 2304 };

static const uint16_t *list_of(int idx, int *n)
{
    if (idx == R_COM_BAUD) { *n = (int)(sizeof BAUD_LIST / sizeof BAUD_LIST[0]); return BAUD_LIST; }
    *n = 0;
    return 0;
}

int reg_list_step(int idx, int32_t cur, int dir, int32_t *out)
{
    int n;
    const uint16_t *l = list_of(idx, &n);
    if (!l) return 0;
    int pos = -1;
    if (dir > 0) { for (int i = 0; i < n; i++) if (l[i] > cur) { pos = i; break; } if (pos < 0) pos = 0; }
    else         { for (int i = n - 1; i >= 0; i--) if (l[i] < cur) { pos = i; break; } if (pos < 0) pos = n - 1; }
    *out = l[pos];
    return 1;
}

static int in_range(int idx, uint16_t raw)
{
    int32_t v = reg_is_signed(idx) ? (int32_t)(int16_t)raw : (int32_t)raw;
    if (v < reg_table[idx].min || v > reg_table[idx].max) return 0;
    int n;
    const uint16_t *l = list_of(idx, &n);
    if (l) {                                      /* only the listed values are allowed */
        for (int i = 0; i < n; i++) if (l[i] == v) return 1;
        return 0;
    }
    return 1;
}

/* relations between registers: the keypad and RS-485 both pass through here */
static int cross_ok(int idx, int32_t v)
{
    switch (idx) {
    case R_F_MIN:  return v < reg_val(R_F_MAX);
    case R_F_MAX:  return v > reg_val(R_F_MIN);
    case R_V_MIN:  return v < reg_val(R_V_MAX);
    case R_V_MAX:  return v > reg_val(R_V_MIN);
    case R_T_WARN: return v <= reg_val(R_T_MAX);
    case R_T_MAX:  return v >= reg_val(R_T_WARN);
    /* the STM32 UART has no 7-bit mode without parity: 7 data bits need parity.
     * To go from 8N to 7E set the parity first; to go back set 8 data bits first. */
    case R_COM_DATA:   return !(v == 7 && reg_val(R_COM_PARITY) == 0);
    case R_COM_PARITY: return !(v == 0 && reg_val(R_COM_DATA) == 7);
    default:       return 1;
    }
}

reg_err_t reg_read(uint16_t addr, uint16_t *raw)
{
    int i = reg_find(addr);
    if (i < 0) return REG_ERR_ADDR;
    *raw = (reg_table[i].flags & RS_CMD) ? 0u : g_val[i];
    return REG_OK;
}

int regs_start_allowed(reg_src_t src)
{
    uint16_t s = g_val[R_CTRL_SRC];
    return s == 2u || (s == 0u && src == SRC_LOCAL) || (s == 1u && src == SRC_RS485);
}

reg_err_t reg_write(uint16_t addr, uint16_t raw) { return reg_write_from(addr, raw, SRC_LOCAL); }

reg_err_t reg_write_from(uint16_t addr, uint16_t raw, reg_src_t src)
{
    int i = reg_find(addr);
    if (i < 0) return REG_ERR_ADDR;
    if (reg_table[i].flags & RS_RO) return REG_ERR_RO;
    if (!in_range(i, raw)) return REG_ERR_VALUE;
    if ((reg_table[i].flags & RS_LOCK) && (g_val[R_STATE] == ST_START || g_val[R_STATE] == ST_RUN))
        return REG_ERR_BUSY;
    int32_t v = reg_is_signed(i) ? (int32_t)(int16_t)raw : (int32_t)raw;
    if (!cross_ok(i, v)) return REG_ERR_VALUE;

    if (reg_table[i].flags & RS_CMD) {
        if (raw == CMD_NONE) return REG_OK;
        if ((raw == CMD_START || raw == CMD_RESET_FAULT) && !regs_start_allowed(src)) {
            g_val[R_CMD_RES] = 4;                             /* not allowed from this source */
            return REG_ERR_DENIED;
        }
        if (raw == CMD_SAVE || raw == CMD_DEFAULTS || raw == CMD_APPLY_COMM) g_cfg_cmd = (uint8_t)raw;
        else if (raw == CMD_STOP) g_cmd_pending = CMD_STOP;                /* STOP is never overwritten */
        else if (g_cmd_pending != CMD_STOP) g_cmd_pending = (uint8_t)raw;
        return REG_OK;
    }
    if (g_val[i] == raw) return REG_OK;                   /* nothing changes: nothing to save */
    int auto_was_on = (g_val[R_AUTO_SAVE] != 0u);
    g_val[i] = raw;
    if (is_comm(i)) g_comm_dirty = 1;
    if (reg_table[i].flags & RS_SAVE) {
        g_dirty = 1;
        g_val[R_SAVE_ST] = 1;
        /* the master changed it: save by itself (also when this very write switches AUTO_SAVE on or off) */
        if (src == SRC_RS485 && (auto_was_on || g_val[R_AUTO_SAVE] != 0u)) g_auto_arm = 1;
    }
    return REG_OK;
}

int regs_restore(uint16_t addr, uint16_t raw)
{
    int i = reg_find(addr);
    if (i < 0 || !(reg_table[i].flags & RS_SAVE) || !in_range(i, raw)) return 0;
    g_val[i] = raw;
    return 1;
}

void regs_load_defaults(void)
{
    for (int i = 0; i < REG_COUNT; i++)
        if (reg_table[i].flags & RS_SAVE) g_val[i] = (uint16_t)reg_table[i].def;
    g_comm_dirty = 1;
    g_dirty = 1;                                          /* flash still holds the old values until a save */
    g_val[R_SAVE_ST] = 1;
}

void regs_init(void)
{
    for (int i = 0; i < REG_COUNT; i++) g_val[i] = (uint16_t)reg_table[i].def;
    g_cmd_pending = 0;
    g_cfg_cmd = 0;
    g_comm_dirty = 1;
    g_loaded = (flash_store_load() >= 0);
    g_dirty = 0;
    g_auto_arm = g_auto_wait = 0;
}

int regs_loaded_from_flash(void) { return g_loaded; }

static int do_save(void)
{
    if (g_val[R_STATE] == ST_START || g_val[R_STATE] == ST_RUN) return 1;   /* flash erase stalls the CPU */
    if (flash_store_save() != 0) { g_val[R_SAVE_ST] = 2; return 2; }
    g_dirty = 0;
    g_auto_arm = g_auto_wait = 0;
    g_val[R_SAVE_ST] = 0;
    g_val[R_SAVE_CNT]++;
    return 0;
}

int regs_save(void)
{
    int rc = do_save();
    g_val[R_CMD_RES] = (uint16_t)rc;
    return rc;
}

void regs_autosave_service(uint32_t now_ms)
{
    if (g_auto_arm) {                                     /* every new write restarts the delay */
        g_auto_arm = 0;
        g_auto_wait = 1;
        g_auto_due = now_ms + (uint32_t)g_val[R_SAVE_DLY] * 1000u;
    }
    if (!g_auto_wait || !g_dirty) return;
    if ((int32_t)(now_ms - g_auto_due) < 0) return;
    int rc = do_save();                                   /* 1 = busy: try again on the next call */
    if (rc == 2) g_auto_wait = 0;                         /* flash error: shown in SAVE_STATE, no endless retries */
}

void regs_service(void)
{
    int c = g_cfg_cmd;
    g_cfg_cmd = 0;
    if (c == CMD_SAVE) {
        regs_save();
    } else if (c == CMD_DEFAULTS) {
        if (g_val[R_STATE] == ST_START || g_val[R_STATE] == ST_RUN) g_val[R_CMD_RES] = 1;
        else { regs_load_defaults(); g_val[R_CMD_RES] = 0; }
    } else if (c == CMD_APPLY_COMM) {
        g_comm_dirty = 1;
        g_val[R_CMD_RES] = 0;
    }
}

int regs_cmd_take(void)
{
    int c = g_cmd_pending;
    g_cmd_pending = 0;
    return c;
}

int regs_comm_changed_take(void)
{
    int d = g_comm_dirty;
    g_comm_dirty = 0;
    return d;
}
