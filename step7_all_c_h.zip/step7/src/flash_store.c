#include "flash_store.h"
#include "regs.h"
#include "crc16.h"
#include <string.h>

#define MAGIC    0x5AA5u
#define LAYOUT   2u                     /* 2: AO_SOURCE / AO_FREQ registers added */
#define HDR_HW   3u                        /* magic, layout, count (halfwords) */
#define MAX_PAIRS ((FLASH_STORE_SIZE / 2u - HDR_HW - 1u) / 2u)

static uint16_t g_buf[FLASH_STORE_SIZE / 2u];   /* static: no 1 KB on the small default stack */

static uint16_t crc_of(const uint16_t *w, uint32_t halfwords)
{
    return crc16_modbus((const uint8_t *)w, halfwords * 2u);
}

int flash_store_load(void)
{
    const uint16_t *p = flash_hw_page();
    if (p[0] != MAGIC || p[1] != LAYOUT) return -1;
    uint32_t n = p[2];
    if (n > MAX_PAIRS) return -1;
    uint32_t used = HDR_HW + 2u * n;
    if (p[used] != crc_of(p, used)) return -1;

    int restored = 0;
    for (uint32_t i = 0; i < n; i++) {
        uint16_t addr = p[HDR_HW + 2u * i];
        uint16_t val  = p[HDR_HW + 2u * i + 1u];
        if (regs_restore(addr, val)) restored++;       /* unknown or out of range: skipped */
    }
    return restored;
}

int flash_store_save(void)
{
    uint32_t n = 0;
    memset(g_buf, 0xFF, sizeof g_buf);
    for (int i = 0; i < REG_COUNT; i++) {
        if (!(reg_table[i].flags & RS_SAVE)) continue;
        if (n >= MAX_PAIRS) break;
        g_buf[HDR_HW + 2u * n]      = reg_table[i].addr;
        g_buf[HDR_HW + 2u * n + 1u] = reg_get(i);
        n++;
    }
    g_buf[0] = MAGIC;
    g_buf[1] = LAYOUT;
    g_buf[2] = (uint16_t)n;
    uint32_t used = HDR_HW + 2u * n;
    g_buf[used] = crc_of(g_buf, used);

    if (flash_hw_erase_page()) return -1;
    for (uint32_t i = 0; i <= used; i++)
        if (flash_hw_prog16(i * 2u, g_buf[i])) return -2;

    const uint16_t *p = flash_hw_page();
    for (uint32_t i = 0; i <= used; i++)
        if (p[i] != g_buf[i]) return -3;
    return 0;
}
