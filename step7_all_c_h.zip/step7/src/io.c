#include "io.h"
#include "board.h"
#include "delay.h"

static void in_pd(GPIO_TypeDef *g, unsigned pin, int active_high)
{
    if (active_high) gpio_clr(g, pin); else gpio_set(g, pin);   /* ODR picks pull-down / pull-up: the pin idles inactive */
    gpio_cfg(g, pin, GPIO_IN_PULL);
}

static unsigned g_pol;                                           /* INPUT_POL: 1 = inverted (active low) */

static int level_of(int default_active, unsigned bit) { return (default_active != 0) != ((g_pol >> bit) & 1u); }
static int active(GPIO_TypeDef *g, unsigned pin, int level) { return gpio_get(g, pin) == level; }

void io_set_polarity(unsigned mask)
{
    g_pol = mask & 0xFu;
    in_pd(START_EXT_PORT, START_EXT_PIN, level_of(START_EXT_ACTIVE, 0));
    in_pd(STOP_EXT_PORT, STOP_EXT_PIN, level_of(STOP_EXT_ACTIVE, 1));
    in_pd(FLOW_PORT, FLOW_PIN, level_of(FLOW_ACTIVE, 2));
    in_pd(ESTOP_PORT, ESTOP_PIN, level_of(ESTOP_ACTIVE, 3));
}

void io_init(void)
{
    io_set_polarity(g_pol);
    in_pd(HWFAULT_PORT, HWFAULT_PIN, HWFAULT_ACTIVE);
    in_pd(LATCH_Q_PORT, LATCH_Q_PIN, LATCH_Q_ACTIVE);
    gpio_put(LATCH_CLR_PORT, LATCH_CLR_PIN, !LATCH_CLR_ACTIVE);  /* released first, then the pin becomes an output */
    gpio_cfg(LATCH_CLR_PORT, LATCH_CLR_PIN, GPIO_OUT_OD_2MHZ);   /* open drain: the schematic has a pull-up on /CLR */
    gpio_clr(LED_RUN_PORT, LED_RUN_PIN);
    gpio_cfg(LED_RUN_PORT, LED_RUN_PIN, GPIO_OUT_PP_2MHZ);
    gpio_clr(LED_FAULT_PORT, LED_FAULT_PIN);
    gpio_cfg(LED_FAULT_PORT, LED_FAULT_PIN, GPIO_OUT_PP_2MHZ);
}

int io_flow_fault(void)  { return active(FLOW_PORT, FLOW_PIN, level_of(FLOW_ACTIVE, 2)); }
int io_estop(void)       { return active(ESTOP_PORT, ESTOP_PIN, level_of(ESTOP_ACTIVE, 3)); }
int io_hw_fault(void)
{
    return active(HWFAULT_PORT, HWFAULT_PIN, HWFAULT_ACTIVE) || active(LATCH_Q_PORT, LATCH_Q_PIN, LATCH_Q_ACTIVE);
}
int io_start_button(void) { return active(START_EXT_PORT, START_EXT_PIN, level_of(START_EXT_ACTIVE, 0)); }
int io_stop_button(void)  { return active(STOP_EXT_PORT, STOP_EXT_PIN, level_of(STOP_EXT_ACTIVE, 1)); }

void io_latch_clear(void)
{
    gpio_put(LATCH_CLR_PORT, LATCH_CLR_PIN, LATCH_CLR_ACTIVE);
    delay_us(20);
    gpio_put(LATCH_CLR_PORT, LATCH_CLR_PIN, !LATCH_CLR_ACTIVE);
}

void io_led_run(int on)   { gpio_put(LED_RUN_PORT, LED_RUN_PIN, on); }
void io_led_fault(int on) { gpio_put(LED_FAULT_PORT, LED_FAULT_PIN, on); }
