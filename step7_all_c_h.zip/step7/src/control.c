#include "control.h"
#include "regs.h"
#include "io.h"
#include "delay.h"

#define TICK_MS          5u        /* the logic runs every 5 ms */
#define FLOW_DEBOUNCE_MS 200u
#define IN_DEBOUNCE_MS   10u
#define RETRY_DELAY_MS   3000u
#define RETRY_RESET_MS   60000u    /* run this long without a trip: the retry counter is reloaded */

typedef struct { uint8_t state; uint32_t since; } deb_t;

static uint32_t g_last_tick;
static uint32_t g_state_ms;          /* time of the last state change */
static uint32_t g_amp_milli;         /* amplitude in 1/1000 of 0.1 % */
static uint8_t  g_reboot;
static uint8_t  g_prev_start_btn, g_prev_stop_btn;
static uint8_t  g_pol_applied;     /* INPUT_POL value the pins are configured for */
static uint32_t g_hold_until;      /* ignore button edges until then (after power-up or a polarity change) */
static uint16_t g_last_com_ok;
static uint32_t g_com_ms;            /* last time R_COM_OK changed */
static uint8_t  g_retries_left;
static uint8_t  g_want_run;          /* the operator asked for run and has not stopped */
static uint32_t g_clear_ms;          /* since when the retry conditions are clear */
static uint32_t g_blink;
static deb_t    d_flow, d_estop, d_hw;

static int debounce(deb_t *d, int raw, uint32_t now, uint32_t ms)
{
    if (raw == d->state) { d->since = now; return d->state; }
    if ((uint32_t)(now - d->since) >= ms) { d->state = (uint8_t)raw; d->since = now; }
    return d->state;
}

static void set_state(int st, uint32_t now)
{
    reg_set(R_STATE, st);
    g_state_ms = now;
}

static void outputs_off(void)
{
    g_amp_milli = 0;
    reg_set(R_AMPLITUDE, 0);
    reg_set(R_POWER_OUT, 0);
    reg_set(R_P_EFF, 0);
    reg_set(R_FREQ, 0);
}

/* Temperature derating (TEMP_DERATE = 1): between TEMP_WARN and TEMP_MAX the power set point falls linearly
 * from 100 % to 0 %. Below TEMP_WARN, or with the function off, P_SET is used unchanged.
 * p and the result are in 0.1 % units. The trip at TEMP_MAX itself is unchanged (conditions()). */
uint32_t derate_power(uint32_t p, int32_t t)
{
    if (!reg_get(R_DERATE_EN)) return p;
    int32_t w = reg_val(R_T_WARN), m = reg_val(R_T_MAX);
    if (m <= w || t <= w) return p;
    if (t >= m) return 0;
    return (uint32_t)(((int64_t)p * (int64_t)(m - t)) / (int64_t)(m - w));
}

void control_init(void)
{
    io_init();
    uint32_t now = millis();
    g_pol_applied = (uint8_t)reg_get(R_IN_POL);
    io_set_polarity(g_pol_applied);
    g_hold_until = now + 50u;            /* the pulls need a moment: a button already "pressed" at power-up never starts */
    g_last_tick = now;
    g_com_ms = now;
    d_flow.since = d_estop.since = d_hw.since = now;
    set_state(ST_IDLE, now);
    outputs_off();
}

int control_reboot_requested(void) { return g_reboot; }

/* conditions that stop or prevent a run */
static uint16_t conditions(uint32_t now)
{
    uint16_t c = 0;
    int32_t v, i, t;
    if (reg_get(R_SIM_EN)) {                       /* test aid: the SIM_xxx registers replace the measurements */
        v = reg_val(R_SIM_V); i = reg_val(R_SIM_I); t = reg_val(R_SIM_T);
        reg_set(R_V_BUS, v); reg_set(R_I_BUS, i); reg_set(R_TEMP, t);
    } else {
        v = reg_val(R_V_BUS); i = reg_val(R_I_BUS); t = reg_val(R_TEMP);
    }
    if ((i < 0 ? -i : i) > reg_val(R_I_MAX)) c |= F_OVERCURRENT;     /* |I|: the sensor is bidirectional */
    if (v > reg_val(R_V_MAX)) c |= F_OVERVOLT;
    if (v < reg_val(R_V_MIN)) c |= F_UNDERVOLT;
    if (t > reg_val(R_T_MAX)) c |= F_OVERTEMP;
    if (t > reg_val(R_T_WARN) && !(t > reg_val(R_T_MAX))) c |= F_TEMPWARN;     /* a trip replaces the warning */
    if (reg_get(R_FLOW_EN) && debounce(&d_flow, io_flow_fault(), now, FLOW_DEBOUNCE_MS)) c |= F_FLOW;
    if (debounce(&d_estop, io_estop(), now, IN_DEBOUNCE_MS)) c |= F_ESTOP;
    if (debounce(&d_hw, io_hw_fault(), now, IN_DEBOUNCE_MS)) c |= F_HWFAULT;

    uint16_t ok = reg_get(R_COM_OK);
    if (ok != g_last_com_ok) { g_last_com_ok = ok; g_com_ms = now; }
    /* master link: a status bit only (R_COMM_STATUS bit 0). The slave never stops or faults because the master is
     * absent: master and slave are independent, the master reads the bit and decides. Keypad and button starts
     * are not affected at all. */
    reg_set(R_COMM_ST, (reg_get(R_COMM_TMO) && (uint32_t)(now - g_com_ms) > (uint32_t)reg_get(R_COMM_TMO) * 1000u) ? 1u : 0u);
    return c;
}

static void clear_latch(void)
{
    reg_set(R_FAULT_LATCH, 0);
    reg_set(R_FAULT_FIRST, 0);
}

static void trip(uint16_t cause, uint32_t now)
{
    outputs_off();
    if (reg_get(R_FAULT_LATCH) == 0) reg_set(R_FAULT_FIRST, (uint16_t)(cause & ~F_TEMPWARN));   /* what stopped the unit first */
    reg_set(R_FAULT_LATCH, reg_get(R_FAULT_LATCH) | (cause & ~F_TEMPWARN));
    set_state(ST_FAULT, now);
    g_clear_ms = now;
}

static void do_start(uint32_t now)
{
    clear_latch();
    g_retries_left = (uint8_t)reg_get(R_RETRY);
    g_want_run = 1;
    g_amp_milli = 0;
    reg_set(R_FREQ, reg_get(R_F_START));
    set_state(ST_START, now);
}

static void do_stop(uint32_t now)
{
    g_want_run = 0;
    outputs_off();
    set_state(ST_IDLE, now);          /* the next pass makes it READY when the conditions allow it */
}

static void run_logic(uint32_t now, uint32_t dt)
{
    uint16_t cond = conditions(now);
    uint16_t trip_mask = (uint16_t)(cond & ~F_TEMPWARN);
    int st = (int)reg_get(R_STATE);
    int cmd = regs_cmd_take();

    reg_set(R_FAULT_NOW, cond);

    /* input polarity (INPUT_POL) changed from the keypad or RS-485: reconfigure the pulls, ignore the buttons for a moment */
    if ((uint8_t)reg_get(R_IN_POL) != g_pol_applied) {
        g_pol_applied = (uint8_t)reg_get(R_IN_POL);
        io_set_polarity(g_pol_applied);
        g_hold_until = now + 50u;
    }
    int hold = ((int32_t)(now - g_hold_until) < 0);

    /* start request from the external button: rising edge, if local control is allowed */
    int btn = io_start_button();
    if (hold) g_prev_start_btn = (uint8_t)btn;
    if (btn && !g_prev_start_btn && regs_start_allowed(SRC_LOCAL)) cmd = CMD_START;
    g_prev_start_btn = (uint8_t)btn;

    /* external stop button: always allowed, wins over any start while it is held */
    int sbtn = io_stop_button();
    if (hold) g_prev_stop_btn = (uint8_t)sbtn;
    if (sbtn) { if (cmd == CMD_START) cmd = 0; if (!g_prev_stop_btn) cmd = CMD_STOP; }
    g_prev_stop_btn = (uint8_t)sbtn;

    /* live state of the inputs for the display / master (1 = active, not debounced) */
    reg_set(R_IO_IN, (btn ? IN_START : 0) | (sbtn ? IN_STOP : 0) | (io_flow_fault() ? IN_FLOW : 0) |
                     (io_estop() ? IN_ESTOP : 0) | (io_hw_fault() ? IN_HW : 0));

    if (cmd == CMD_REBOOT) g_reboot = 1;
    if (cmd == CMD_STOP) {
        if (st != ST_FAULT) do_stop(now);
        else { g_want_run = 0; g_retries_left = 0; }         /* STOP also cancels a pending automatic retry; the fault stays latched */
        cmd = 0; st = (int)reg_get(R_STATE);
    }

    if (cmd == CMD_RESET_FAULT) {
        io_latch_clear();                                   /* clear the hardware latch first ... */
        d_hw.state = (uint8_t)io_hw_fault();                /* ... and look at the line again without debounce */
        d_hw.since = now;
        cond = conditions(now);
        trip_mask = (uint16_t)(cond & ~F_TEMPWARN);
        reg_set(R_FAULT_NOW, cond);
        if (st == ST_FAULT) {
            if (trip_mask == 0) {
                clear_latch();
                g_want_run = 0;
                set_state(ST_IDLE, now);
                st = ST_IDLE;
                reg_set(R_CMD_RES, RES_OK);
            } else reg_set(R_CMD_RES, RES_NOT_READY);       /* the cause is still there */
        } else {
            clear_latch();
            reg_set(R_CMD_RES, RES_OK);
        }
        cmd = 0;
    }

    switch (st) {
    case ST_IDLE:
    case ST_READY:
        if (trip_mask) { if (st != ST_IDLE) set_state(ST_IDLE, now); }
        else if (st == ST_IDLE) set_state(ST_READY, now);
        if (cmd == CMD_START) {
            if (trip_mask) reg_set(R_CMD_RES, RES_NOT_READY);
            else { do_start(now); reg_set(R_CMD_RES, RES_OK); }
        }
        break;

    case ST_START: {
        if (trip_mask) { trip(trip_mask, now); break; }
        uint32_t t = now - g_state_ms, T = reg_get(R_START_MS);
        if (t >= T) { reg_set(R_FREQ, reg_get(R_F_SET)); set_state(ST_RUN, now); }
        else {                                            /* frequency sweeps from F_START to F_SET */
            int32_t f0 = reg_val(R_F_START), f1 = reg_val(R_F_SET);
            reg_set(R_FREQ, f0 + (int32_t)(((int64_t)(f1 - f0) * (int64_t)t) / (int64_t)T));
        }
        break;
    }

    case ST_RUN: {
        if (trip_mask) { trip(trip_mask, now); break; }
        uint32_t p_eff = derate_power((uint32_t)reg_val(R_P_SET), reg_val(R_TEMP));
        reg_set(R_P_EFF, (int32_t)p_eff);
        uint32_t target = p_eff * 1000u;
        uint32_t step = (uint32_t)reg_get(R_P_RAMP) * dt;            /* milli-units: 0.1 %/s * ms */
        if (g_amp_milli < target) { g_amp_milli += step; if (g_amp_milli > target) g_amp_milli = target; }
        else if (g_amp_milli > target) { g_amp_milli = (g_amp_milli > target + step) ? g_amp_milli - step : target; }
        reg_set(R_AMPLITUDE, (int32_t)(g_amp_milli / 1000u));
        reg_set(R_POWER_OUT, (int32_t)(g_amp_milli / 1000u));        /* placeholder until power is measured */
        reg_set(R_FREQ, reg_get(R_F_SET));
        if ((uint32_t)(now - g_state_ms) > RETRY_RESET_MS) g_retries_left = (uint8_t)reg_get(R_RETRY);
        break;
    }

    case ST_FAULT: {
        if (trip_mask) reg_set(R_FAULT_LATCH, reg_get(R_FAULT_LATCH) | trip_mask);   /* later faults are latched too, until reset */
        /* automatic restart after an overcurrent / over- or undervoltage trip, if RETRY allows it */
        uint16_t latched = reg_get(R_FAULT_LATCH);
        uint16_t retryable = F_OVERCURRENT | F_OVERVOLT | F_UNDERVOLT;
        if (g_want_run && g_retries_left && (latched & ~retryable) == 0) {
            if (trip_mask) g_clear_ms = now;
            else if ((uint32_t)(now - g_clear_ms) >= RETRY_DELAY_MS) {
                uint8_t left = (uint8_t)(g_retries_left - 1u);
                do_start(now);
                g_retries_left = left;
            }
        }
        if (cmd == CMD_START) reg_set(R_CMD_RES, RES_NOT_READY);
        break;
    }
    default:
        set_state(ST_IDLE, now);
        break;
    }

    /* LEDs */
    st = (int)reg_get(R_STATE);
    g_blink += dt;
    io_led_run(st == ST_RUN || (st == ST_START && ((g_blink / 150u) & 1u)));
    io_led_fault(st == ST_FAULT || ((cond & F_TEMPWARN) && ((g_blink / 500u) & 1u)));
}

void control_step(void)
{
    uint32_t now = millis();
    uint32_t dt = (uint32_t)(now - g_last_tick);
    if (dt < TICK_MS) return;
    g_last_tick = now;
    run_logic(now, dt);
}
