/* flash_hw.c - STM32F103 internal flash, register level (works next to the HAL).
 * The CPU stalls while a page is erased (about 20-40 ms): never call it while the inverter runs. */
#include "flash_store.h"
#include "stm32f1xx.h"

const uint16_t *flash_hw_page(void)
{
    return (const uint16_t *)FLASH_STORE_ADDR;
}

static int wait_ready(void)
{
    uint32_t n = 2000000u;
    while ((FLASH->SR & FLASH_SR_BSY) && --n) { }
    return n ? 0 : -1;
}

static void unlock(void)
{
    if (FLASH->CR & FLASH_CR_LOCK) {
        FLASH->KEYR = 0x45670123u;
        FLASH->KEYR = 0xCDEF89ABu;
    }
}

static void lock(void)
{
    FLASH->CR |= FLASH_CR_LOCK;
}

int flash_hw_erase_page(void)
{
    int rc = 0;
    unlock();
    if (wait_ready()) { lock(); return -1; }
    FLASH->SR = FLASH_SR_EOP | FLASH_SR_PGERR | FLASH_SR_WRPRTERR;   /* clear old flags (write 1) */
    FLASH->CR |= FLASH_CR_PER;
    FLASH->AR = FLASH_STORE_ADDR;
    FLASH->CR |= FLASH_CR_STRT;
    if (wait_ready()) rc = -1;
    if (FLASH->SR & (FLASH_SR_PGERR | FLASH_SR_WRPRTERR)) rc = -1;
    FLASH->SR = FLASH_SR_EOP;
    FLASH->CR &= ~FLASH_CR_PER;
    lock();
    return rc;
}

int flash_hw_prog16(uint32_t offset, uint16_t v)
{
    int rc = 0;
    unlock();
    if (wait_ready()) { lock(); return -1; }
    FLASH->SR = FLASH_SR_EOP | FLASH_SR_PGERR | FLASH_SR_WRPRTERR;
    FLASH->CR |= FLASH_CR_PG;
    *(volatile uint16_t *)(FLASH_STORE_ADDR + offset) = v;
    if (wait_ready()) rc = -1;
    if (FLASH->SR & (FLASH_SR_PGERR | FLASH_SR_WRPRTERR)) rc = -1;
    FLASH->SR = FLASH_SR_EOP;
    FLASH->CR &= ~FLASH_CR_PG;
    lock();
    return rc;
}
