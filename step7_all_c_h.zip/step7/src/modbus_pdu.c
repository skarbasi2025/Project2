/* modbus_pdu.c - Modbus RTU frame handling, independent of the hardware (host-testable). */
#include "modbus.h"
#include "regs.h"
#include "crc16.h"

static int put_crc(uint8_t *b, int n)
{
    uint16_t c = crc16_modbus(b, (uint32_t)n);
    b[n] = (uint8_t)(c & 0xFFu);
    b[n + 1] = (uint8_t)(c >> 8);
    return n + 2;
}

static int exception(uint8_t *resp, uint8_t addr, uint8_t fn, uint8_t code)
{
    resp[0] = addr;
    resp[1] = (uint8_t)(fn | 0x80u);
    resp[2] = code;
    return put_crc(resp, 3);
}

/* 01 illegal function, 02 illegal data address, 03 illegal data value, 06 slave busy */
static uint8_t map_err(reg_err_t e)
{
    switch (e) {
    case REG_ERR_ADDR:
    case REG_ERR_RO:    return 0x02;      /* a read only register is "not writable at this address" */
    case REG_ERR_VALUE: return 0x03;
    case REG_ERR_BUSY:  return 0x06;
    case REG_ERR_DENIED: return 0x04;      /* START / RESET refused: CTRL_SRC does not allow RS-485 */
    default:            return 0x04;
    }
}

static uint16_t rd16(const uint8_t *p) { return (uint16_t)(((unsigned)p[0] << 8) | p[1]); }

int modbus_handle(const uint8_t *req, int len, uint8_t *resp, uint8_t own_addr, mb_result_t *res)
{
    *res = MB_IGNORED;
    if (len < 4) { *res = MB_CRC_ERR; return 0; }
    if (crc16_modbus(req, (uint32_t)len) != 0) { *res = MB_CRC_ERR; return 0; }   /* CRC over frame incl. CRC = 0 */

    uint8_t addr = req[0];
    if (addr != own_addr && addr != 0) return 0;                                    /* not for us */
    int broadcast = (addr == 0);
    uint8_t fn = req[1];
    int out = 0;
    *res = MB_OK;

    switch (fn) {
    case 0x03:
    case 0x04: {
        if (broadcast) return 0;
        if (len != 8) { out = exception(resp, addr, fn, 0x03); break; }
        uint16_t start = rd16(&req[2]), qty = rd16(&req[4]);
        if (qty < 1 || qty > 125) { out = exception(resp, addr, fn, 0x03); break; }
        if ((uint32_t)start + qty > 65536u) { out = exception(resp, addr, fn, 0x02); break; }
        resp[0] = addr; resp[1] = fn; resp[2] = (uint8_t)(qty * 2u);
        int n = 3;
        int bad = 0;
        for (uint16_t i = 0; i < qty; i++) {
            uint16_t v;
            if (reg_read((uint16_t)(start + i), &v) != REG_OK) { bad = 1; break; }
            resp[n++] = (uint8_t)(v >> 8);
            resp[n++] = (uint8_t)(v & 0xFFu);
        }
        out = bad ? exception(resp, addr, fn, 0x02) : put_crc(resp, n);
        break;
    }
    case 0x06: {
        if (len != 8) { out = exception(resp, addr, fn, 0x03); break; }
        reg_err_t e = reg_write_from(rd16(&req[2]), rd16(&req[4]), SRC_RS485);
        if (e != REG_OK) { out = exception(resp, addr, fn, map_err(e)); break; }
        for (int i = 0; i < 8; i++) resp[i] = req[i];                              /* echo */
        out = 8;
        break;
    }
    case 0x10: {
        if (len < 9) { out = exception(resp, addr, fn, 0x03); break; }
        uint16_t start = rd16(&req[2]), qty = rd16(&req[4]);
        uint8_t bc = req[6];
        if (qty < 1 || qty > 123 || bc != qty * 2u || len != 9 + bc) { out = exception(resp, addr, fn, 0x03); break; }
        reg_err_t e = REG_OK;
        for (uint16_t i = 0; i < qty && e == REG_OK; i++)
            e = reg_write_from((uint16_t)(start + i), rd16(&req[7 + 2 * i]), SRC_RS485);        /* values before an error stay written */
        if (e != REG_OK) { out = exception(resp, addr, fn, map_err(e)); break; }
        resp[0] = addr; resp[1] = fn;
        resp[2] = req[2]; resp[3] = req[3]; resp[4] = req[4]; resp[5] = req[5];
        out = put_crc(resp, 6);
        break;
    }
    default:
        out = exception(resp, addr, fn, 0x01);
        break;
    }

    if (out >= 3 && (resp[1] & 0x80u)) *res = MB_EXCEPTION;
    return broadcast ? 0 : out;
}
