/* meas.c - ADC counts to engineering units. See meas.h for the wiring assumptions. */
#include "meas.h"
#include <math.h>

static int32_t lin(uint32_t raw, uint32_t fs, int32_t gain_milli, int32_t off_counts)
{
    if (raw > ADC_FULL) raw = ADC_FULL;
    int64_t c = (int64_t)raw + off_counts;                    /* offset in counts */
    if (c < 0) c = 0;
    if (c > ADC_FULL) c = ADC_FULL;
    return (int32_t)(c * (int64_t)fs * (int64_t)gain_milli / ((int64_t)ADC_FULL * 1000));
}

int32_t meas_bus_v(uint32_t raw, uint32_t fs, int32_t gain_milli, int32_t off_counts)
{
    return lin(raw, fs, gain_milli, off_counts);
}

/* ACS758: zero at 1.6667 V = 2068 counts; 26.67 mV/A = 33.08 counts per A; 1 count = 0.3023 x0.1 A */
#define ACS_ZERO_COUNTS 2068
int32_t meas_bus_i(uint32_t raw, int32_t gain_milli, int32_t off_counts)
{
    if (raw > ADC_FULL) raw = ADC_FULL;
    int64_t c = (int64_t)raw + off_counts - ACS_ZERO_COUNTS;   /* signed: negative = current in reverse */
    c = c * gain_milli / 1000;                                  /* gain trim (1000 = 1.000) */
    return (int32_t)(c * 1000 / 3308);                          /* counts -> x0.1 A */
}

int32_t meas_temp(uint32_t raw, int32_t off_tenths)
{
    if (raw < 1u) raw = 1u;                                   /* keep the divider away from 0 and full scale */
    if (raw > ADC_FULL - 1u) raw = ADC_FULL - 1u;
    /* pull-up 10 k to 3.3 V, NTC to GND: R_ntc = 10 k * raw / (full - raw) */
    float r = 10000.0f * (float)raw / (float)(ADC_FULL - raw);
    /* beta model: 1/T = 1/T0 + ln(R/R0)/B, T0 = 298.15 K at R0 = 10 k, B = 3950 K */
    float tk = 1.0f / (1.0f / 298.15f + logf(r / 10000.0f) / 3950.0f);
    float tenths = (tk - 273.15f) * 10.0f;
    int32_t t = (int32_t)(tenths >= 0.0f ? tenths + 0.5f : tenths - 0.5f);
    return t + off_tenths;
}
