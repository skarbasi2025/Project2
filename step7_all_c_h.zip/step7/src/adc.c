/* adc.c - ADC1 + DMA1 measurement driver. Register level, no HAL.
 *   scan order: PA4 (I_BUS, ch4), PA6 (TEMP, ch6), PA7 (V_BUS, ch7)
 *   one DMA buffer = ADC_SCANS scans; the DMA fills it continuously, adc_step() averages it.
 *   sample time 71.5 cycles (sheet 4). */
#include "adc.h"
#include "meas.h"
#include "regs.h"
#include "board.h"
#include "delay.h"
#include "gpio_f1.h"
#include "stm32f1xx.h"

#define ADC_CH       3u
/* averaging window = 10 ms = three or more periods of the 300 Hz bus ripple (sheet 4).
 * one scan = 3 x (71.5 + 12.5) = 252 ADC cycles: 10.67 MHz -> 23.6 us (424 scans), 4 MHz -> 63 us (159 scans). */
#if CLOCK_64MHZ
#define ADC_SCANS    424u
#else
#define ADC_SCANS    159u
#endif
#define ADC_PERIOD_MS 10u

static volatile uint16_t g_buf[ADC_SCANS * ADC_CH];
static uint32_t g_last_ms;

void adc_init(void)
{
    RCC->AHBENR  |= RCC_AHBENR_DMA1EN;
    RCC->APB2ENR |= RCC_APB2ENR_ADC1EN | RCC_APB2ENR_IOPAEN;
    gpio_cfg(GPIOA, 4, GPIO_ANALOG);                    /* I_BUS_ADC */
    gpio_cfg(GPIOA, 6, GPIO_ANALOG);                    /* TEMP_ADC  */
    gpio_cfg(GPIOA, 7, GPIO_ANALOG);                    /* V_BUS_ADC */

    /* ADC clock must stay below 14 MHz: 64 MHz / 6 = 10.7 MHz, 8 MHz / 2 = 4 MHz */
#if CLOCK_64MHZ
    RCC->CFGR = (RCC->CFGR & ~RCC_CFGR_ADCPRE) | RCC_CFGR_ADCPRE_DIV6;
#else
    RCC->CFGR = (RCC->CFGR & ~RCC_CFGR_ADCPRE) | RCC_CFGR_ADCPRE_DIV2;
#endif

    /* DMA1 channel 1 = ADC1: 16-bit circular, memory increments */
    DMA1_Channel1->CCR   = 0;
    DMA1_Channel1->CPAR  = (uint32_t)&ADC1->DR;
    DMA1_Channel1->CMAR  = (uint32_t)g_buf;
    DMA1_Channel1->CNDTR = ADC_SCANS * ADC_CH;
    DMA1_Channel1->CCR   = DMA_CCR_MINC | DMA_CCR_CIRC | DMA_CCR_PSIZE_0 | DMA_CCR_MSIZE_0 | DMA_CCR_EN;

    /* ADC1: power up, reset and run the calibration */
    ADC1->CR2 = ADC_CR2_ADON;
    delay_us(10);
    ADC1->CR2 |= ADC_CR2_RSTCAL;
    while (ADC1->CR2 & ADC_CR2_RSTCAL) { }
    ADC1->CR2 |= ADC_CR2_CAL;
    while (ADC1->CR2 & ADC_CR2_CAL) { }

    ADC1->SMPR2 = (3u << 12) | (3u << 18) | (3u << 21); /* ch4, ch6, ch7: 71.5 cycles (sheet 4) */
    ADC1->SQR1  = (ADC_CH - 1u) << 20;                  /* 3 conversions in the sequence */
    ADC1->SQR3  = 4u | (6u << 5) | (7u << 10);          /* sequence: ch4, ch6, ch7 */
    ADC1->CR1   = ADC_CR1_SCAN;
    ADC1->CR2   = ADC_CR2_ADON | ADC_CR2_CONT | ADC_CR2_DMA | ADC_CR2_EXTTRIG | (7u << 17); /* software trigger */
    ADC1->CR2  |= ADC_CR2_SWSTART;                      /* start the continuous scan */
    g_last_ms = 0;
}

void adc_step(uint32_t now_ms)
{
    if ((uint32_t)(now_ms - g_last_ms) < ADC_PERIOD_MS && g_last_ms) return;
    g_last_ms = now_ms ? now_ms : 1u;

    uint32_t si = 0, st = 0, sv = 0;
    for (uint32_t k = 0; k < ADC_SCANS; k++) {
        si += g_buf[k * ADC_CH + 0u];
        st += g_buf[k * ADC_CH + 1u];
        sv += g_buf[k * ADC_CH + 2u];
    }
    uint32_t raw_i = si / ADC_SCANS, raw_t = st / ADC_SCANS, raw_v = sv / ADC_SCANS;

    reg_set(R_ADC_V, (int32_t)raw_v);
    reg_set(R_ADC_I, (int32_t)raw_i);
    reg_set(R_ADC_T, (int32_t)raw_t);

    reg_set(R_V_BUS, meas_bus_v(raw_v, reg_get(R_V_FS), reg_val(R_CAL_V_G), reg_val(R_CAL_V_O)));
    reg_set(R_I_BUS, meas_bus_i(raw_i, reg_val(R_CAL_I_G), reg_val(R_CAL_I_O)));
    reg_set(R_TEMP,  meas_temp(raw_t, reg_val(R_CAL_T_O)));
}
