/* modbus_uart.c - RS-485 hardware layer: the UART selected in board.h (USART3 PB10/PB11 by default), TIM4 as the t3.5 frame timer,
 * PC15 = driver enable. Register level, no HAL. Interrupt driven: RXNE restarts TIM4 on every byte;
 * when TIM4 expires (line silent for t3.5) the frame is complete. modbus_poll() answers it.
 *
 * Clock assumption: HCLK = SystemCoreClock, APB1 prescaler read from RCC->CFGR.               */
#include "modbus.h"
#include "regs.h"
#include "board.h"
#include "delay.h"
#include "stm32f1xx.h"

enum { S_IDLE, S_WAIT, S_TX };

static uint8_t  g_rx[MB_MAX_FRAME];
static volatile uint16_t g_rx_len;
static volatile uint8_t  g_rx_ready, g_rx_bad;
static uint8_t  g_tx[MB_MAX_FRAME];
static volatile uint16_t g_tx_len, g_tx_pos;
static volatile uint8_t  g_tx_done;
static uint8_t  g_state;
static uint32_t g_due;
static uint8_t  g_recovery;
static volatile uint32_t g_last_ms;      /* time of the last received byte */
static uint32_t g_gap_ms = 5;            /* software t3.5, a backup for the timer */

static uint32_t pclk1_hz(void)                 /* clock of the UART's bus (APB1 for USART3, APB2 for USART1) */
{
    return SystemCoreClock >> MB_PCLK_SHIFT();
}

static uint32_t tim4_hz(void)
{
    uint32_t ppre = (RCC->CFGR >> 8) & 7u;
    return (SystemCoreClock >> ((ppre < 4u) ? 0u : (ppre - 3u))) * ((ppre < 4u) ? 1u : 2u);   /* TIM4 is on APB1 */
}

static void de_on(void)  { gpio_set(RS485_DE_PORT, RS485_DE_PIN); }
static void de_off(void) { gpio_clr(RS485_DE_PORT, RS485_DE_PIN); }

void modbus_apply(void)
{
    uint32_t baud   = (g_recovery ? 96u : reg_get(R_COM_BAUD)) * 100u;
    uint32_t parity = g_recovery ? 0u : reg_get(R_COM_PARITY);       /* 0 none 1 even 2 odd */
    uint32_t stop   = g_recovery ? 1u : reg_get(R_COM_STOP);
    uint32_t data   = g_recovery ? 8u : reg_get(R_COM_DATA);
    if (data == 7u && parity == 0u) data = 8u;                        /* 7N is impossible on this UART */
    if (baud == 0u) baud = 9600u;

    uint32_t cr1 = USART_CR1_TE | USART_CR1_RE | USART_CR1_RXNEIE;
    if (parity) {
        cr1 |= USART_CR1_PCE;
        if (parity == 2u) cr1 |= USART_CR1_PS;
        if (data == 8u) cr1 |= USART_CR1_M;                           /* 8 data + parity = 9 bit word */
    }                                                                 /* 7 data + parity = 8 bit word */
    MB_UART->CR1 = 0;                                                  /* UE off while changing */
    MB_UART->CR2 = (stop == 2u) ? USART_CR2_STOP_1 : 0u;
    MB_UART->BRR = (pclk1_hz() + baud / 2u) / baud;                    /* 16x oversampling: BRR = fck / baud */
    MB_UART->CR1 = cr1 | USART_CR1_UE;

    /* t3.5 in microseconds */
    uint32_t bits = 1u + data + (parity ? 1u : 0u) + stop;
    uint32_t t35 = reg_get(R_COM_T35);
    if (g_recovery) t35 = 0;
    if (t35 == 0u) t35 = (baud > 19200u) ? 1750u : (3500000u * bits / baud);
    if (t35 < 100u) t35 = 100u;
    g_gap_ms = t35 / 1000u + 2u;                                      /* software gap: a bit longer than the timer */
    if (g_gap_ms < 3u) g_gap_ms = 3u;
    TIM4->CR1 = 0;
    TIM4->PSC = (uint16_t)(tim4_hz() / 1000000u - 1u);                /* 1 tick = 1 us */
    TIM4->ARR = (uint16_t)(t35 - 1u);
    TIM4->CR1 = TIM_CR1_OPM | TIM_CR1_URS;
    TIM4->EGR = TIM_EGR_UG;
    TIM4->SR = 0;
    TIM4->DIER = TIM_DIER_UIE;
    g_rx_len = 0; g_rx_bad = 0;
}

void modbus_init(int recovery)
{
    g_recovery = (uint8_t)recovery;
    MB_UART_CLK_ON();
    RCC->APB1ENR |= RCC_APB1ENR_TIM4EN;
    RCC->APB2ENR |= RCC_APB2ENR_IOPAEN | RCC_APB2ENR_IOPBEN | RCC_APB2ENR_IOPCEN;
    de_off();
    gpio_cfg(RS485_DE_PORT, RS485_DE_PIN, GPIO_OUT_PP_2MHZ);
    gpio_cfg(RS485_TX_PORT, RS485_TX_PIN, GPIO_AF_PP_50MHZ);
    gpio_set(RS485_RX_PORT, RS485_RX_PIN);                            /* pull-up: idle line = 1 */
    gpio_cfg(RS485_RX_PORT, RS485_RX_PIN, GPIO_IN_PULL);
    NVIC_SetPriority(MB_IRQn, 1);
    NVIC_SetPriority(TIM4_IRQn, 2);
    NVIC_EnableIRQ(MB_IRQn);
    NVIC_EnableIRQ(TIM4_IRQn);
    modbus_apply();
    regs_comm_changed_take();                                         /* already applied */
    g_state = S_IDLE;
}

static void bump(int idx);

/* Everything the UART interrupt does. It is also called from modbus_poll() (with interrupts off),
 * so the driver works even where the simulator does not deliver peripheral interrupts. */
static void uart_service(void)
{
    uint32_t sr = MB_UART->SR;

    if (sr & (USART_SR_RXNE | USART_SR_ORE)) {
        uint8_t d = (uint8_t)MB_UART->DR;                              /* reading SR then DR clears the flags */
        if (MB_UART->CR1 & USART_CR1_RXNEIE) {
            if (sr & (USART_SR_PE | USART_SR_FE | USART_SR_NE | USART_SR_ORE)) g_rx_bad = 1;
            bump(R_COM_RXB);
            g_last_ms = millis();
            if (!g_rx_ready) {
                uint16_t n = g_rx_len;
                if (n < MB_MAX_FRAME) { g_rx[n] = d; g_rx_len = (uint16_t)(n + 1u); }
                else g_rx_bad = 1;
                TIM4->CNT = 0;
                TIM4->CR1 |= TIM_CR1_CEN;                             /* restart the t3.5 timer */
            }
        }
    }
    if ((sr & USART_SR_TXE) && (MB_UART->CR1 & USART_CR1_TXEIE)) {
        uint16_t pos = g_tx_pos;                                       /* one volatile read per statement */
        if (pos < g_tx_len) {
            MB_UART->DR = g_tx[pos];
            g_tx_pos = (uint16_t)(pos + 1u);
            bump(R_COM_TXB);
        } else {
            MB_UART->CR1 &= ~USART_CR1_TXEIE;
            MB_UART->CR1 |= USART_CR1_TCIE;                            /* wait until the last bit has left */
        }
    }
    if ((sr & USART_SR_TC) && (MB_UART->CR1 & USART_CR1_TCIE)) {
        MB_UART->CR1 &= ~USART_CR1_TCIE;
        MB_UART->SR = (uint32_t)~USART_SR_TC;
        de_off();
        (void)MB_UART->DR;                                             /* drop the echo of our own frame */
        g_rx_len = 0; g_rx_bad = 0;
        MB_UART->CR1 |= USART_CR1_RXNEIE;
        g_tx_done = 1;
    }
}

static void tim_service(void)
{
    if (TIM4->SR & TIM_SR_UIF) {
        TIM4->SR = (uint32_t)~TIM_SR_UIF;
        if (g_rx_len) g_rx_ready = 1;                                 /* silence of t3.5: frame complete */
    }
}

void MB_IRQ_HANDLER(void) { uart_service(); }
void TIM4_IRQHandler(void) { tim_service(); }

static void start_tx(uint16_t n)
{
    g_tx_len = n;
    g_tx_pos = 0;
    g_tx_done = 0;
    MB_UART->CR1 &= ~USART_CR1_RXNEIE;                                 /* ignore our own echo */
    de_on();
    delay_us(10);                                                     /* transceiver enable time */
    MB_UART->CR1 |= USART_CR1_TXEIE;
}

int modbus_busy(void)
{
    return g_state != S_IDLE || g_rx_ready || g_rx_len != 0;
}

static void bump(int idx)
{
    reg_set(idx, (int32_t)((reg_get(idx) + 1u) & 0xFFFFu));
}

void modbus_poll(void)
{
    /* Same work as the interrupts, in case they are not delivered (simulators), plus a software
     * t3.5 in case the timer event does not come. With working interrupts this finds nothing to do. */
    __disable_irq();
    uart_service();
    tim_service();
    if (g_rx_len && !g_rx_ready && (uint32_t)(millis() - g_last_ms) >= g_gap_ms) g_rx_ready = 1;
    __enable_irq();

    switch (g_state) {
    case S_IDLE:
        if (g_rx_ready) {
            uint8_t  f[MB_MAX_FRAME];
            uint16_t n = g_rx_len;
            uint8_t  bad = g_rx_bad;
            for (uint16_t i = 0; i < n; i++) f[i] = g_rx[i];
            g_rx_len = 0; g_rx_bad = 0; g_rx_ready = 0;               /* ready for the next frame */

            mb_result_t res;
            int m = 0;
            if (bad) res = MB_CRC_ERR;
            else m = modbus_handle(f, n, g_tx, (uint8_t)reg_get(R_COM_ADDR), &res);
            if (res == MB_CRC_ERR) bump(R_COM_ERR);
            else if (res != MB_IGNORED) bump(R_COM_OK);
            if (m > 0) {
                g_tx_len = (uint16_t)m;
                g_due = millis() + reg_get(R_COM_RDLY);
                g_state = S_WAIT;
            }
        } else if (g_rx_len == 0 && regs_comm_changed_take()) {
            modbus_apply();                                           /* new line settings, after the reply */
        }
        break;
    case S_WAIT:
        if ((int32_t)(millis() - g_due) >= 0) { start_tx(g_tx_len); g_state = S_TX; }
        break;
    case S_TX:
        if (g_tx_done) g_state = S_IDLE;
        break;
    }
}
