/* ui_regtest.c - register browser / editor on the 20x4 LCD with five buttons.
 *
 *   row 0: "#100 COM_ADDR      S"   address, name, S = saved in flash, R = read only
 *   row 1: "Val=1 x100 bd"        current raw value and its unit/scale
 *   row 2: "Min=1 Max=247"        limits (or the edit step while editing)
 *   row 3: help (alternates), "New=12" while editing, "Go to #" while jumping, or a message
 *
 * Buttons (browse):  UP / DOWN   next / previous register (held: repeats)
 *                    ENTER       edit the value
 *                    MODE        settings list <-> status list (read only registers)
 *                    SHIFT       next group (command, communication, process, ...)
 *                    hold MODE   go to a register: UP / DOWN pick it, ENTER goes, MODE cancels
 *                    hold ENTER  save to flash
 * Buttons (edit):    UP / DOWN   change the digit selected by SHIFT (held: repeats, faster with the held time)
 *                    SHIFT       select the next digit (units, tens, ...)
 *                    ENTER       apply the value,  MODE  cancel
 *                    Registers with a fixed list of values (baud rate) pick the next / previous listed value.
 *                    Commands (register 20) take 1..7 with UP / DOWN.
 * UP / DOWN repeat while held: on / off, first delay and first period are registers KEY_REPEAT_EN / _DLY / _MS (241..243);
 * the period gets shorter the longer the key is held (acceleration, min 50 ms). The selected digit blinks in edit mode. */
#include "ui_regtest.h"
#include "regs.h"
#include "lcd.h"
#include "keypad.h"
#include "delay.h"

#ifndef UI_SPLASH_MS
#define UI_SPLASH_MS 800u     /* any button skips it */
#endif

#define W LCD_COLS
enum { M_BROWSE, M_EDIT, M_GOTO };

static int      g_idx;
static uint8_t  g_mode;
static uint8_t  g_status_view;       /* 0 = list of settable registers, 1 = status (read only) */
static uint8_t  g_home = 1;           /* home screen (live status) is shown; MODE cycles: home -> settings -> status -> home */
static uint32_t g_home_ms;
static uint8_t  g_help;               /* which help line is shown (changes every 3 s) */
static char     g_msg[W + 1];
static uint32_t g_msg_until;
static uint8_t  g_dirty;
static uint16_t g_shown;              /* raw value on the screen, to follow live status registers */
static int32_t  g_val;                /* edit: the value being changed */
static uint8_t  g_cur;                /* edit: digit selected (0 = units) */
static int      g_goto;               /* go to: index in reg_table */
static uint8_t  g_blink;              /* edit: blink phase of the selected digit (toggles every BLINK_MS) */
static char     g_hold_key;           /* edit: UP / DOWN currently held (0 = none) */
static uint32_t g_hold_ms;            /* when that hold started */
static uint8_t  g_hold_lvl;           /* how many digit steps the hold has already moved the cursor */

#define BLINK_MS 250u

static uint8_t put_str(char *d, uint8_t n, const char *s)
{
    while (*s && n < W) d[n++] = *s++;
    return n;
}

static uint8_t put_int(char *d, uint8_t n, int32_t v)
{
    char t[12];
    uint8_t k = 0;
    uint32_t u;
    if (v < 0) { if (n < W) d[n++] = '-'; u = (uint32_t)(-v); } else u = (uint32_t)v;
    do { t[k++] = (char)('0' + u % 10u); u /= 10u; } while (u);
    while (k && n < W) d[n++] = t[--k];
    return n;
}

static void say(const char *s)
{
    uint8_t n = 0;
    while (*s && n < W) g_msg[n++] = *s++;
    g_msg[n] = 0;
    g_msg_until = millis() + 1500u;
    if (!g_msg_until) g_msg_until = 1;
    g_dirty = 1;
}

static int is_status(int idx) { return (reg_table[idx].flags & RS_RO) != 0; }

/* next register in the current list (settings or status), wrapping around */
static int nav(int from, int dir)
{
    int i = from;
    for (int n = 0; n < REG_COUNT; n++) {
        i = (i + dir + REG_COUNT) % REG_COUNT;
        if (is_status(i) == (g_status_view != 0)) return i;
    }
    return from;
}

/* first register of each group (addresses), in the settings list and in the status list */
static const uint16_t GROUPS_SET[] = { 20, 100, 120, 160, 200, 240, 250 };
static const uint16_t GROUPS_STAT[] = { 0, 12, 21 };

static int next_group(int from)
{
    const uint16_t *g = g_status_view ? GROUPS_STAT : GROUPS_SET;
    int n = g_status_view ? (int)(sizeof GROUPS_STAT / sizeof GROUPS_STAT[0]) : (int)(sizeof GROUPS_SET / sizeof GROUPS_SET[0]);
    uint16_t cur = reg_table[from].addr;
    uint16_t want = g[0];
    for (int i = 0; i < n; i++) if (g[i] > cur) { want = g[i]; break; }
    for (int i = 0; i < REG_COUNT; i++) if (reg_table[i].addr == want) return i;
    return from;
}

static int first_in_list(void)
{
    int i = REG_COUNT - 1;                    /* nav() steps forward from "before the first" */
    return nav(i, 1);
}

/* fault registers are shown as a list of fault numbers (1 overcurrent, 2 overvoltage, 3 undervoltage, 4 overtemperature,
 * 5 flow, 6 E-stop, 7 hardware, 8 RS-485 timeout, W temperature warning), not as the sum of the bit values */
static int is_fault_reg(int idx) { return idx == R_FAULT_NOW || idx == R_FAULT_LATCH || idx == R_FAULT_FIRST; }

/* value x0.1 as "12.3" (sign if negative) */
static uint8_t put_tenths(char *d, uint8_t n, int32_t v)
{
    if (v < 0) { if (n < W) d[n++] = '-'; v = -v; }
    n = put_int(d, n, v / 10);
    if (n < W) d[n++] = '.';
    if (n < W) d[n++] = (char)('0' + v % 10);
    return n;
}

static uint8_t put_faults(char *d, uint8_t n, uint16_t m)
{
    if ((m & 0x80FFu) == 0) return put_str(d, n, "No fault");
    n = put_str(d, n, "F:");
    for (uint8_t b = 0; b < 8; b++)
        if (m & (1u << b)) { n = put_int(d, n, (int32_t)b + 1); if (n < W) d[n++] = ' '; }
    if (m & 0x8000u) n = put_str(d, n, "W");
    while (n && d[n - 1] == ' ') n--;
    return n;
}

static uint8_t put_fault_names(char *d, uint8_t n, uint16_t m)
{
    static const char *const nm[8] = { "OC", "OV", "UV", "OT", "FLOW", "ESTOP", "HW", "COMM" };
    for (uint8_t b = 0; b < 8; b++) {
        if (!(m & (1u << b))) continue;
        uint8_t len = 0;
        while (nm[b][len]) len++;
        if (n + len > W) break;
        n = put_str(d, n, nm[b]);
        if (n < W) d[n++] = ' ';
    }
    if ((m & 0x8000u) && n + 4u <= W) n = put_str(d, n, "WARN");
    while (n && d[n - 1] == ' ') n--;
    return n;
}

static uint8_t put_inputs(char *d, uint8_t n, uint16_t m)
{
    static const char *const nm[5] = { "St", "Sp", "Fl", "Es", "Hw" };
    for (uint8_t b = 0; b < 5; b++) {
        n = put_str(d, n, nm[b]);
        if (n < W) d[n++] = (m & (1u << b)) ? '1' : '0';
        if (n < W && b < 4) d[n++] = ' ';
    }
    return n;
}

/* ---------- editing ---------- */

/* number of digits of the largest magnitude the register can take (at least 1) */
static uint8_t edit_digits(void)
{
    const reg_info_t *r = &reg_table[g_idx];
    int32_t m = (r->max > -r->min) ? r->max : -r->min;
    uint8_t n = 1;
    while (m >= 10) { m /= 10; n++; }
    return n;
}

static int32_t pow10i(uint8_t k)
{
    int32_t p = 1;
    while (k--) p *= 10;
    return p;
}

static void start_edit(void)
{
    const reg_info_t *r = &reg_table[g_idx];
    if (r->flags & RS_RO) { say("Read only"); return; }
    g_mode = M_EDIT;
    g_cur = 0;
    g_val = (r->flags & RS_CMD) ? 0 : reg_val(g_idx);
    g_dirty = 1;
}

/* UP (+1) / DOWN (-1) on the selected digit; the value stays inside the register's limits */
static void edit_step(int dir)
{
    const reg_info_t *r = &reg_table[g_idx];
    int32_t out;
    if (g_idx == R_COM_BAUD) {
        if (reg_list_step(g_idx, g_val, dir, &out)) g_val = out;
    } else if (r->flags & RS_CMD) {
        g_val += dir;
        if (g_val < 1) g_val = 1;
        if (g_val > r->max) g_val = r->max;
    } else {
        int32_t v = g_val + dir * pow10i(g_cur);
        if (v > r->max) v = r->max;
        if (v < r->min) v = r->min;
        g_val = v;
    }
    g_dirty = 1;
}

static void apply_edit(void)
{
    const reg_info_t *r = &reg_table[g_idx];
    if (g_val < -32768 || g_val > 65535) { say("Out of range"); return; }
    switch (reg_write(r->addr, (uint16_t)g_val)) {
    case REG_OK:         say((r->flags & RS_CMD) ? "Command sent" : "OK"); g_mode = M_BROWSE; break;
    case REG_ERR_VALUE:  say("Out of range"); break;
    case REG_ERR_BUSY:   say("Stop inverter 1st"); break;
    case REG_ERR_RO:     say("Read only"); g_mode = M_BROWSE; break;
    default:             say("Error"); break;
    }
}

static void save_to_flash(void)
{
    switch (regs_save()) {
    case 0:  say("Saved to flash"); break;
    case 1:  say("Stop inverter 1st"); break;
    default: say("Flash error"); break;
    }
}

static void apply_repeat(void)
{
    static uint16_t last_en = 0xFFFF, last_ms, last_dly;
    uint16_t en = reg_get(R_KEY_RPT_EN), ms = reg_get(R_KEY_RPT_MS), dly = reg_get(R_KEY_RPT_DLY);
    if (en == last_en && ms == last_ms && dly == last_dly) return;
    last_en = en; last_ms = ms; last_dly = dly;
    keypad_set_repeat(en ? "UD" : "");
    keypad_set_timing(dly, ms);
}

/* ---------- screen ---------- */

static void draw_home(void)
{
    static const char *const st[5] = { "IDLE", "READY", "START", "RUN", "FAULT" };
    char l[W + 1];
    uint8_t n = 0;
    uint16_t state = reg_get(R_STATE);
    n = put_str(l, n, "STATE ");
    n = put_str(l, n, state < 5 ? st[state] : "?");
    while (n < 12) l[n++] = ' ';
    if (reg_get(R_FAULT_NOW)) n = put_faults(l, n, reg_get(R_FAULT_NOW));
    else n = put_str(l, n, "no fault");
    l[n] = 0;
    lcd_line(0, l);

    n = 0;
    n = put_str(l, n, "F=");
    n = put_int(l, n, reg_get(R_FREQ));
    n = put_str(l, n, "Hz  A=");
    n = put_tenths(l, n, reg_get(R_AMPLITUDE));
    n = put_str(l, n, "%");
    l[n] = 0;
    lcd_line(1, l);

    n = 0;
    n = put_str(l, n, "V=");
    n = put_tenths(l, n, reg_get(R_V_BUS));
    n = put_str(l, n, " I=");
    n = put_tenths(l, n, (int16_t)reg_get(R_I_BUS));
    n = put_str(l, n, " T=");
    n = put_tenths(l, n, (int16_t)reg_get(R_TEMP));
    l[n] = 0;
    lcd_line(2, l);

    n = 0;
    if (g_msg_until) n = put_str(l, n, g_msg);
    else n = put_str(l, n, "ENTER: settings");
    l[n] = 0;
    lcd_line(3, l);
    g_shown = reg_get(g_idx);
}

static void draw(void)
{
    char l[W + 1];
    uint8_t n;
    if (g_home) { draw_home(); return; }
    int idx = (g_mode == M_GOTO) ? g_goto : g_idx;
    const reg_info_t *r = &reg_table[idx];

    n = 0;
    l[n++] = '#';
    n = put_int(l, n, r->addr);
    l[n++] = ' ';
    n = put_str(l, n, r->name);
    while (n < W) l[n++] = ' ';
    l[W - 1] = (r->flags & RS_RO) ? 'R' : ((r->flags & RS_SAVE) ? 'S' : ' ');
    l[W] = 0;
    lcd_line(0, l);

    n = 0;
    if (is_fault_reg(idx)) {
        n = put_str(l, n, idx == R_FAULT_NOW ? "Active faults:" : idx == R_FAULT_LATCH ? "Latched faults:" : "First fault:");
    } else if (idx == R_IO_IN) {
        n = put_str(l, n, "Inputs 1=active:");
    } else {
        n = put_str(l, n, "Val=");
        n = put_int(l, n, reg_val(idx));
        l[n++] = ' ';
        n = put_str(l, n, r->unit);
    }
    l[n] = 0;
    lcd_line(1, l);

    n = 0;
    if (g_mode == M_EDIT) {
        if (idx == R_COM_BAUD) n = put_str(l, n, "U/D = next standard");
        else if (r->flags & RS_CMD) n = put_str(l, n, "U/D = command 1..7");
        else { n = put_str(l, n, "Step="); n = put_int(l, n, pow10i(g_cur)); n = put_str(l, n, " S=next digit"); }
    } else if (g_mode == M_GOTO) {
        n = put_str(l, n, "UP/DOWN pick, ENTER go");
    } else if (is_fault_reg(idx)) {
        n = put_faults(l, n, reg_get(idx));
    } else if (idx == R_IO_IN) {
        n = put_inputs(l, n, reg_get(idx));
    } else if (idx == R_COM_BAUD) {
        n = put_int(l, n, reg_val(idx) * 100); n = put_str(l, n, " baud");
    } else if (r->flags & RS_CMD) {
        n = put_str(l, n, "Write 1..7 = action");
    } else if (r->flags & RS_RO) {
        n = put_str(l, n, "Read only");
    } else {
        n = put_str(l, n, "Min=");
        n = put_int(l, n, r->min);
        n = put_str(l, n, " Max=");
        n = put_int(l, n, r->max);
    }
    l[n] = 0;
    lcd_line(2, l);

    n = 0;
    if (g_msg_until) {
        n = put_str(l, n, g_msg);
    } else if (g_mode == M_EDIT) {
        /* digits of the value; the cursor may sit past them (shown as 0). The selected digit blinks. */
        uint32_t u = (g_val < 0) ? (uint32_t)(-g_val) : (uint32_t)g_val;
        uint8_t nd = 1;
        while (u >= pow10i(nd)) nd++;
        if (nd < (uint8_t)(g_cur + 1u)) nd = (uint8_t)(g_cur + 1u);
        n = put_str(l, n, "New=");
        if (g_val < 0 && n < W) l[n++] = '-';
        for (int k = (int)nd - 1; k >= 0; k--) {
            char ch = (char)('0' + (char)(u / (uint32_t)pow10i((uint8_t)k) % 10u));
            if ((uint8_t)k == g_cur && !g_blink) ch = ' ';
            if (n < W) l[n++] = ch;
        }
        if (n + 6 <= W) n = put_str(l, n, "  ENTER");
    } else if (g_mode == M_GOTO) {
        n = put_str(l, n, "Go to #");
        n = put_int(l, n, r->addr);
        if (n + 6 <= W) n = put_str(l, n, " ENTER");
    } else if (is_fault_reg(idx) && (reg_get(idx) & 0x80FFu)) {
        n = put_fault_names(l, n, reg_get(idx));
    } else {
        static const char *const help[4] = { "UP/DN nav ENTER edit", "MODE stat SHIFT grp", "hold MODE: goto", "hold ENTER: save" };
        n = put_str(l, n, help[g_help]);
    }
    l[n] = 0;
    lcd_line(3, l);
    g_shown = reg_get(g_idx);
}

void ui_regtest_init(void)
{
    lcd_init();
    keypad_init();
    lcd_goto(0, 0);
    lcd_puts("Hello Saeid");
    lcd_line(1, regs_loaded_from_flash() ? "Settings: from flash" : "Settings: defaults");
    {   /* diagnostic: does millis() (SysTick / HAL tick) advance? the buttons need it */
        uint32_t a = millis();
        delay_ms(20);
        lcd_line(2, (millis() != a) ? "Tick: OK" : "Tick: STOPPED");
    }
    /* splash: at most UI_SPLASH_MS passes of 1 ms; any button skips it. Counted by passes,
     * not by millis(), so it ends even when the tick is dead. */
    for (uint32_t i = 0; i < UI_SPLASH_MS; i++) {
        keypad_poll();
        if (keypad_get()) break;
        delay_ms(1);
    }
    lcd_clear();
    g_status_view = 0;
    g_home = 1;
    g_idx = first_in_list();
    g_mode = M_BROWSE;
    g_msg_until = 0;
    g_dirty = 1;
}

void ui_regtest_step(void)
{
    apply_repeat();
    keypad_poll();
    char k = keypad_get();
    if (k) {
        if (g_mode == M_EDIT) {
            switch (k) {
            case KEY_UP:    edit_step(1); break;
            case KEY_DOWN:  edit_step(-1); break;
            case KEY_SHIFT: g_cur = (uint8_t)((g_cur + 1u) % edit_digits()); break;
            case KEY_ENTER: apply_edit(); break;
            case KEY_MODE:  g_mode = M_BROWSE; break;
            default: break;
            }
        } else if (g_mode == M_GOTO) {
            switch (k) {
            case KEY_UP:    g_goto = (g_goto + 1) % REG_COUNT; break;
            case KEY_DOWN:  g_goto = (g_goto + REG_COUNT - 1) % REG_COUNT; break;
            case KEY_ENTER:
                g_idx = g_goto;
                g_status_view = (uint8_t)is_status(g_idx);
                g_mode = M_BROWSE;
                break;
            case KEY_MODE:  g_mode = M_BROWSE; break;
            default: break;
            }
        } else if (g_home) {
            switch (k) {
            case KEY_ENTER: g_home = 0; g_status_view = 0; g_idx = first_in_list(); break;
            case KEY_MODE:  g_home = 0; g_status_view = 0; g_idx = first_in_list(); break;
            default: break;
            }
        } else {
            switch (k) {
            case KEY_UP:    g_idx = nav(g_idx, 1); break;
            case KEY_DOWN:  g_idx = nav(g_idx, -1); break;
            case KEY_ENTER: start_edit(); g_blink = 1; break;
            case KEY_MODE:
                if (!g_status_view) { g_status_view = 1; }
                else { g_status_view = 0; g_home = 1; }     /* status list -> home */
                g_idx = first_in_list();
                break;
            case KEY_SHIFT: g_idx = next_group(g_idx); break;
            case KEY_MODE_LONG:  g_goto = g_idx; g_mode = M_GOTO; break;
            case KEY_ENTER_LONG: save_to_flash(); break;
            default: break;
            }
        }
        g_dirty = 1;
    }

    if (g_msg_until && (int32_t)(millis() - g_msg_until) >= 0) { g_msg_until = 0; g_dirty = 1; }
    if (g_mode == M_EDIT) {                              /* holding UP / DOWN: after 1 s the cursor moves to the next digit every second */
        char hk = keypad_held();
        if (hk == KEY_UP || hk == KEY_DOWN) {
            if (hk != g_hold_key) { g_hold_key = hk; g_hold_ms = millis(); g_hold_lvl = 0; }
            uint32_t held = millis() - g_hold_ms;
            uint8_t lvl = (held >= 1000u) ? (uint8_t)((held - 1000u) / 1000u + 1u) : 0u;
            while (g_hold_lvl < lvl) {
                g_hold_lvl++;
                if (g_cur + 1u < edit_digits()) { g_cur++; g_dirty = 1; }
            }
        } else {
            g_hold_key = 0;
        }
    }
    if (g_mode == M_EDIT) {                              /* blink the selected digit */
        uint8_t b = (uint8_t)((millis() / BLINK_MS) & 1u);
        if (b != g_blink) { g_blink = b; g_dirty = 1; }
    }
    if (reg_get(g_idx) != g_shown) g_dirty = 1;         /* live value changed */
    {   uint8_t h = (uint8_t)((millis() / 3000u) % 4u);
        if (h != g_help) { g_help = h; g_dirty = 1; } }

    if (g_home && (uint32_t)(millis() - g_home_ms) >= 250u) { g_home_ms = millis(); g_dirty = 1; }
    if (g_dirty) { g_dirty = 0; draw(); }
}
