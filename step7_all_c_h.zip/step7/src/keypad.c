/* keypad.c - five push buttons (pins in board.h: KEY_*_PORT / KEY_*_PIN), active high, internal pull-down.
 * Every 5 ms the pins are sampled; a level must be seen 3 times in a row (15 ms) before it counts. */
#include "keypad.h"
#include "board.h"
#include "gpio_f1.h"
#include "delay.h"

#define SCAN_MS      5u
#define DEBOUNCE     3u
#define QUEUE_SIZE   8u                /* power of two */
#define NKEYS        5u
#define REP_MIN_MS   40u              /* fastest auto-repeat period */
#define REP_ACCEL    8u               /* period = base * 8 / (8 + repeats): halves after 8 repeats, a quarter after 24 */

/* order of the table: UP, DOWN, ENTER, MODE, SHIFT */
static const pin_t PIN[NKEYS]  = KEY_PINS_INIT;
static const char  CODE[NKEYS] = { KEY_UP, KEY_DOWN, KEY_ENTER, KEY_MODE, KEY_SHIFT };

static char     g_queue[QUEUE_SIZE];
static uint8_t  g_head, g_tail;
static uint32_t g_last_scan;
static uint8_t  g_cand[NKEYS], g_cnt[NKEYS], g_stable[NKEYS];
static uint32_t g_press_ms[NKEYS], g_rep_ms[NKEYS];
static uint8_t  g_long_done[NKEYS], g_repeating[NKEYS];
static uint16_t g_rep_count[NKEYS];   /* repeats sent so far in this hold (drives the acceleration) */
static char     g_repeat_keys[8] = "UD";
static uint16_t g_rep_delay = 500;     /* ms before the first repeat */
static uint16_t g_rep_rate  = 150;     /* ms between repeats         */

static void push(char k)
{
    uint8_t next = (uint8_t)((g_head + 1u) & (QUEUE_SIZE - 1u));
    if (next == g_tail) return;        /* full: drop the newest */
    g_queue[g_head] = k;
    g_head = next;
}

static uint8_t is_repeat_key(char k)
{
    for (const char *p = g_repeat_keys; *p; p++)
        if (*p == k) return 1;
    return 0;
}

/* UP, DOWN and SHIFT act on press; MODE and ENTER act on release (so a long press can be told apart) */
static uint8_t acts_on_press(uint8_t i) { return CODE[i] == KEY_UP || CODE[i] == KEY_DOWN || CODE[i] == KEY_SHIFT; }
static char long_code(uint8_t i)
{
    if (CODE[i] == KEY_MODE)  return KEY_MODE_LONG;
    if (CODE[i] == KEY_ENTER) return KEY_ENTER_LONG;
    return KEY_NONE;
}

void keypad_init(void)
{
    for (uint8_t i = 0; i < NKEYS; i++) {
        gpio_clr(PIN[i].port, PIN[i].pin);             /* ODR = 0 selects the pull-down: released = low */
        gpio_cfg(PIN[i].port, PIN[i].pin, GPIO_IN_PULL);
        g_cand[i] = g_cnt[i] = g_stable[i] = 0;
        g_long_done[i] = g_repeating[i] = 0;
    }
    g_head = g_tail = 0;
    g_last_scan = millis();
}

void keypad_poll(void)
{
    uint32_t now = millis();
    if ((uint32_t)(now - g_last_scan) < SCAN_MS) return;
    g_last_scan = now;

    for (uint8_t i = 0; i < NKEYS; i++) {
        uint8_t raw = (uint8_t)(gpio_get(PIN[i].port, PIN[i].pin) != 0);
        if (raw == g_cand[i]) { if (g_cnt[i] < 255u) g_cnt[i]++; }
        else { g_cand[i] = raw; g_cnt[i] = 1; }

        if (g_cnt[i] == DEBOUNCE && g_cand[i] != g_stable[i]) {
            g_stable[i] = g_cand[i];
            if (g_stable[i]) {                                   /* press edge */
                g_press_ms[i] = now;
                g_long_done[i] = 0;
                g_repeating[i] = 0;
                g_rep_count[i] = 0;
                if (acts_on_press(i)) push(CODE[i]);
            } else if (!acts_on_press(i) && !g_long_done[i]) {   /* release edge: short press */
                push(CODE[i]);
            }
        }

        if (g_stable[i]) {
            if (!g_long_done[i] && long_code(i) && (uint32_t)(now - g_press_ms[i]) >= KEY_LONG_MS) {
                push(long_code(i));
                g_long_done[i] = 1;
            }
            if (is_repeat_key(CODE[i])) {                        /* held UP / DOWN: repeat */
                if (!g_repeating[i]) {
                    if ((uint32_t)(now - g_press_ms[i]) >= g_rep_delay) {
                        push(CODE[i]);
                        g_repeating[i] = 1;
                        g_rep_ms[i] = now;
                        g_rep_count[i] = 0;
                    }
                } else {
                    uint32_t period = (uint32_t)g_rep_rate * REP_ACCEL / (REP_ACCEL + g_rep_count[i]);
                    if (period < REP_MIN_MS) period = REP_MIN_MS;
                    if ((uint32_t)(now - g_rep_ms[i]) >= period) {
                        push(CODE[i]);
                        g_rep_ms[i] = now;
                        if (g_rep_count[i] < 0xFFFFu) g_rep_count[i]++;
                    }
                }
            }
        }
    }
}

char keypad_get(void)
{
    if (g_tail == g_head) return 0;
    char k = g_queue[g_tail];
    g_tail = (uint8_t)((g_tail + 1u) & (QUEUE_SIZE - 1u));
    return k;
}

char keypad_held(void)
{
    for (uint8_t i = 0; i < NKEYS; i++)
        if (g_stable[i]) return CODE[i];
    return KEY_NONE;
}

void keypad_set_repeat(const char *keys)
{
    uint8_t i = 0;
    while (keys[i] && i < sizeof(g_repeat_keys) - 1u) {
        g_repeat_keys[i] = keys[i];
        i++;
    }
    g_repeat_keys[i] = 0;
}

void keypad_set_timing(uint16_t first_delay_ms, uint16_t rate_ms)
{
    g_rep_delay = first_delay_ms;
    g_rep_rate = rate_ms;
}
