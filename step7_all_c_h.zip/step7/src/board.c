/* board.c - board-level setup that is not HAL: GPIO / AFIO clocks and JTAG off.
 * The clock is configured by HAL in main.c (SystemClock_Config); SystemCoreClock is set by HAL too. */
#include "board.h"

void board_init(void)
{
    RCC->APB2ENR |= RCC_APB2ENR_IOPAEN | RCC_APB2ENR_IOPBEN | RCC_APB2ENR_IOPCEN | RCC_APB2ENR_AFIOEN;
    /* SWJ_CFG = 010: JTAG-DP disabled, SW-DP enabled. Frees PA15, PB3 and PB4 as normal pins. */
    AFIO->MAPR = (AFIO->MAPR & ~AFIO_MAPR_SWJ_CFG) | AFIO_MAPR_SWJ_CFG_JTAGDISABLE;
}
