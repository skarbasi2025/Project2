/* analog.c - TIM2 PWM for the analog outputs. PWM frequency 10 kHz (timer clock / 10000), 1000 steps.
 * Duty = per mille of full scale. The PWM is 0..3.3 V; the op-amp after the RC filter gives 0..10 V. */
#include "analog.h"
#include "ao_map.h"
#include "board.h"
#include "gpio_f1.h"
#include "regs.h"

#define AO_PERIOD_MS 50u
#define AO_ARR       (SYSCLK_HZ / 10000u - 1u)     /* timer clock = SYSCLK (APB1 is divided by 2 at 64 MHz) */

static uint32_t g_last_ms;

void ao_init(void)
{
    RCC->APB1ENR |= (1u << 0);                        /* TIM2 clock */
    gpio_cfg(GPIOA, 0, GPIO_AF_PP_50MHZ);             /* PA0 = TIM2_CH1 */
    gpio_cfg(GPIOA, 1, GPIO_AF_PP_50MHZ);             /* PA1 = TIM2_CH2 */
    TIM2->CR1 = 0;
    TIM2->PSC = 0;
    TIM2->ARR = AO_ARR;
    TIM2->CCR1 = 0;
    TIM2->CCR2 = 0;
    TIM2->CCMR1 = (6u << 4) | (1u << 3)               /* CH1: PWM mode 1, preload */
                | (6u << 12) | (1u << 11);            /* CH2: PWM mode 1, preload */
    TIM2->CCER = (1u << 0) | (1u << 4);               /* CC1E, CC2E */
    TIM2->EGR = 1u;                                   /* load the registers */
    TIM2->CR1 = (1u << 7) | (1u << 0);                /* ARPE, CEN */
    g_last_ms = 0;
}

static uint16_t ccr_of(uint16_t permille)
{
    return (uint16_t)((uint32_t)permille * (AO_ARR + 1u) / 1000u);
}

void ao_step(uint32_t now_ms)
{
    if ((uint32_t)(now_ms - g_last_ms) < AO_PERIOD_MS && g_last_ms) return;
    g_last_ms = now_ms ? now_ms : 1u;

    ao_in_t in;
    in.amplitude = reg_get(R_AMPLITUDE);
    in.freq      = reg_get(R_FREQ);
    in.vbus      = reg_get(R_V_BUS);
    { int32_t iv = reg_val(R_I_BUS); in.ibus = (uint16_t)(iv < 0 ? -iv : iv); }   /* AO uses |I| */
    in.temp      = (int16_t)reg_get(R_TEMP);
    in.f_min     = reg_get(R_AO_F_MIN);
    in.f_max     = reg_get(R_AO_F_MAX);
    in.v_fs      = reg_get(R_V_FS);
    in.i_fs      = reg_get(R_I_FS);
    in.t_max     = reg_get(R_T_MAX);

    uint16_t p1 = 0, p2 = 0;
    if (reg_get(R_AO_EN)) {
        p1 = ao_permille(reg_get(R_AO1_SRC), &in);
        p2 = ao_permille(reg_get(R_AO2_SRC), &in);
    }
    TIM2->CCR1 = ccr_of(p1);                          /* AO1 = PA0 */
    TIM2->CCR2 = ccr_of(p2);                          /* AO2 = PA1 */
}
