/* control.h - inverter state machine and protections (no PWM yet: it produces the setpoints
 * R_FREQ and R_AMPLITUDE that the PWM module will follow in a later step).
 *
 * States (R_STATE): 0 IDLE (not ready: a condition is active) | 1 READY | 2 STARTING | 3 RUN | 4 FAULT
 * Fault bits (R_FAULT_NOW = active now, R_FAULT_LATCH = tripped since the last reset):
 *   0 overcurrent   1 overvoltage   2 undervoltage   3 overtemperature   4 cooling flow
 *   5 emergency stop   6 hardware fault (BKIN / latch)   7 RS-485 timeout   15 temperature warning (no trip) */
#ifndef CONTROL_H
#define CONTROL_H
#include <stdint.h>

#define F_OVERCURRENT 0x0001u
#define F_OVERVOLT    0x0002u
#define F_UNDERVOLT   0x0004u
#define F_OVERTEMP    0x0008u
#define F_FLOW        0x0010u
#define F_ESTOP       0x0020u
#define F_HWFAULT     0x0040u
#define F_COMMTMO     0x0080u   /* reserved: the master link no longer makes a fault (see R_COMM_STATUS) */
#define F_TEMPWARN    0x8000u

/* values of R_CMD_RES */
enum { RES_OK = 0, RES_BUSY = 1, RES_FLASH = 2, RES_NOT_READY = 3, RES_DENIED = 4 };

void control_init(void);
void control_step(void);              /* call often; works from millis() */
int  control_reboot_requested(void);  /* CMD_REBOOT was received */
uint32_t derate_power(uint32_t p, int32_t t);   /* P_SET after temperature derating (TEMP_DERATE), 0.1 % units */

#endif
