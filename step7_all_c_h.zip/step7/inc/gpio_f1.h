/* gpio_f1.h - tiny GPIO helpers for STM32F10x (register level, no HAL) */
#ifndef GPIO_F1_H
#define GPIO_F1_H

#include <stdint.h>
#include "stm32f1xx.h"

/* 4-bit CNF/MODE codes for CRL / CRH */
#define GPIO_OUT_PP_2MHZ  0x2u   /* push-pull output, 2 MHz  */
#define GPIO_OUT_PP_50MHZ 0x3u   /* push-pull output, 50 MHz */
#define GPIO_IN_FLOAT     0x4u   /* floating input           */
#define GPIO_IN_PULL      0x8u   /* input with pull-up/down (ODR bit selects) */
#define GPIO_OUT_OD_2MHZ  0x6u   /* open-drain output, 2 MHz  */
#define GPIO_AF_PP_50MHZ  0xBu   /* alternate function push-pull, 50 MHz */
#define GPIO_ANALOG       0x0u

#ifdef HOST_TEST
extern void mock_bsrr(GPIO_TypeDef *g, uint32_t v);
#define GPIO_BSRR_WRITE(g, v) mock_bsrr((g), (v))
#else
#define GPIO_BSRR_WRITE(g, v) ((g)->BSRR = (v))
#endif

typedef struct { GPIO_TypeDef *port; uint8_t pin; } pin_t;

static inline void gpio_cfg(GPIO_TypeDef *g, unsigned pin, unsigned cfg4)
{
    volatile uint32_t *r = (pin < 8) ? &g->CRL : &g->CRH;
    unsigned sh = (pin & 7u) * 4u;
    *r = (*r & ~(0xFu << sh)) | ((uint32_t)cfg4 << sh);
}

static inline void gpio_set(GPIO_TypeDef *g, unsigned pin)   { GPIO_BSRR_WRITE(g, 1u << pin); }
static inline void gpio_clr(GPIO_TypeDef *g, unsigned pin)   { GPIO_BSRR_WRITE(g, 1u << (pin + 16u)); }
static inline void gpio_put(GPIO_TypeDef *g, unsigned pin, int v) { if (v) gpio_set(g, pin); else gpio_clr(g, pin); }
static inline int  gpio_get(GPIO_TypeDef *g, unsigned pin)   { return (int)((g->IDR >> pin) & 1u); }

#endif
