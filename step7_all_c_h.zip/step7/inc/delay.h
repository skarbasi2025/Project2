#ifndef DELAY_H
#define DELAY_H
#include <stdint.h>

void     delay_init(void);          /* DWT cycle counter + 1 ms SysTick       */
void     delay_us(uint32_t us);     /* busy wait, accurate, any clock         */
void     delay_ms(uint32_t ms);
uint32_t millis(void);              /* milliseconds since delay_init()        */

#endif
