/* ao_map.h - analog outputs: which value goes to which output (pure function, host-testable).
 * Output value is per mille of full scale (1000 = 10 V after the op-amp, i.e. 3.3 V PWM before it). */
#ifndef AO_MAP_H
#define AO_MAP_H
#include <stdint.h>

enum { AO_SRC_OFF = 0, AO_SRC_AMPL, AO_SRC_FREQ, AO_SRC_VBUS, AO_SRC_IBUS, AO_SRC_TEMP, AO_SRC_COUNT };

typedef struct {
    uint16_t amplitude;     /* x0.1 %  (0..1000) */
    uint16_t freq;          /* Hz */
    uint16_t vbus;          /* x0.1 V */
    uint16_t ibus;          /* x0.1 A */
    int16_t  temp;          /* x0.1 C */
    uint16_t f_min, f_max;  /* Hz: AO_FREQ_MIN / MAX (freq maps f_min..f_max to 0..10 V) */
    uint16_t v_fs, i_fs;    /* x0.1 V / A: full scale for bus V and I */
    uint16_t t_max;         /* x0.1 C: full scale for temperature (0..t_max) */
} ao_in_t;

uint16_t ao_permille(uint16_t src, const ao_in_t *in);

#endif
