/* io.h - digital inputs, hardware fault latch and LEDs of the controller */
#ifndef IO_H
#define IO_H
void io_init(void);
void io_set_polarity(unsigned mask);   /* INPUT_POL: bit0 START, bit1 STOP, bit2 FLOW, bit3 E-STOP, 1 = active LOW; re-sets the pulls */
int  io_flow_fault(void);       /* 1 = cooling water flow missing */
int  io_estop(void);            /* 1 = emergency stop active */
int  io_hw_fault(void);         /* 1 = TIM1_BKIN line active or the hardware latch holds a fault */
int  io_start_button(void);     /* 1 = external start button pressed */
int  io_stop_button(void);      /* 1 = external stop button pressed */
void io_latch_clear(void);      /* pulse on the latch clear line */
void io_led_run(int on);
void io_led_fault(int on);
#endif
