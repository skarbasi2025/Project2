/* analog.h - the two analog outputs: TIM2 PWM on PA0 (AO1, frequency) and PA1 (AO2, power).
 * Each PWM goes through an RC filter and an op-amp (gain ~3) to 0..10 V. Target only. */
#ifndef ANALOG_H
#define ANALOG_H
#include <stdint.h>
void ao_init(void);
void ao_step(uint32_t now_ms);      /* call often; updates the outputs every 50 ms */
#endif
