#ifndef CRC16_H
#define CRC16_H
#include <stdint.h>
uint16_t crc16_modbus(const uint8_t *p, uint32_t n);   /* poly 0xA001, init 0xFFFF */
#endif
