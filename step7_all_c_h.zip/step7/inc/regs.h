/* regs.h - the register table: every parameter / measurement / command of the controller.
 *
 * One table, three users: the firmware (reg_get / R_xxx), the keypad menu and RS-485 (Modbus).
 * Each register is a 16-bit word. Signed ones (flag RS_SGN) are two's complement.
 * Modbus holding register address = "addr" in the table below (no +40001 offset).
 *
 * The X-macro list MUST stay sorted by ascending address.
 *   X(ID, addr, "name", "unit", min, max, default, flags)
 *   name  : at most 14 characters (fits the 20x4 LCD)
 *   flags : RS_RO   read only (firmware writes it, keypad/RS-485 cannot)
 *           RS_SAVE stored in flash by the Save command
 *           RS_SGN  signed value
 *           RS_LOCK cannot be changed while the inverter is starting/running
 *           RS_CMD  command register (a write triggers an action, reads as 0)       */
#ifndef REGS_H
#define REGS_H
#include <stdint.h>

#define RS_RO    0x01u
#define RS_SAVE  0x02u
#define RS_SGN   0x04u
#define RS_LOCK  0x08u
#define RS_CMD   0x10u

#define REG_LIST \
 /* ---- status (read only) ---- */ \
 X(STATE,      0, "STATE",       "enum", 0,     4,     0,     RS_RO) \
 X(FAULT_NOW,  1, "FAULT_NOW",   "bits",         0,     65535, 0,     RS_RO) \
 X(FAULT_LATCH,2, "FAULT_LATCH", "bits",         0,     65535, 0,     RS_RO) \
 X(FREQ,       3, "FREQ",        "Hz",           0,     65535, 0,     RS_RO) \
 X(POWER_OUT,  4, "POWER_OUT",   "x0.1 %",       0,     1000,  0,     RS_RO) \
 X(V_BUS,      5, "V_BUS",       "x0.1 V",       0,     65535, 0,     RS_RO) \
 X(I_BUS,      6, "I_BUS",       "x0.1 A",       -3000, 3000,  0,     RS_RO|RS_SGN) \
 X(TEMP,       7, "TEMP",        "x0.1 C",       -500,  2000,  0,     RS_RO|RS_SGN) \
 X(PHASE,      8, "PHASE",       "x0.1 deg",     -1800, 1800,  0,     RS_RO|RS_SGN) \
 X(AMPLITUDE,  9, "AMPLITUDE",   "x0.1 %",       0,     1000,  0,     RS_RO) \
 X(UPTIME,    10, "UPTIME",      "min",          0,     65535, 0,     RS_RO) \
 X(FW_VER,    11, "FW_VER",      "x0.01",        0,     65535, 100,   RS_RO) \
 X(COM_OK,    12, "COM_FRAMES_OK","frames",      0,     65535, 0,     RS_RO) \
 X(COM_ERR,   13, "COM_ERRORS",  "frames",       0,     65535, 0,     RS_RO) \
 X(COM_RXB,   14, "COM_RX_BYTES","bytes",       0,     65535, 0,     RS_RO) \
 X(COM_TXB,   15, "COM_TX_BYTES","bytes",       0,     65535, 0,     RS_RO) \
 X(SAVE_CNT,  16, "SAVE_COUNT",  "saves",        0,     65535, 0,     RS_RO) \
 X(SAVE_ST,   17, "SAVE_STATE",  "0ok 1wait 2err",0,    2,     0,     RS_RO) \
 X(IO_IN,     18, "INPUTS",      "bits",         0,     31,    0,     RS_RO) \
 X(FAULT_FIRST,19, "FAULT_FIRST", "bits",         0,     65535, 0,     RS_RO) \
 /* ---- commands ---- */ \
 X(CMD,       20, "COMMAND",     "enum", 0, 7, 0,    RS_CMD) \
 X(CMD_RES,   21, "CMD_RESULT",  "enum", 0,   65535, 0,     RS_RO) \
 X(COMM_ST,   22, "COMM_STATUS", "bit0=lost", 0,  1,     0,     RS_RO) \
 X(P_EFF,     23, "P_EFFECTIVE", "x0.1 %",    0,     1000,  0,     RS_RO) \
 X(ADC_V,     24, "ADC_V_RAW",   "counts",    0,     4095,  0,     RS_RO) \
 X(ADC_I,     25, "ADC_I_RAW",   "counts",    0,     4095,  0,     RS_RO) \
 X(ADC_T,     26, "ADC_T_RAW",   "counts",    0,     4095,  0,     RS_RO) \
 /* ---- communication (RS-485), apply after command 6 or at once from the keypad ---- */ \
 X(COM_ADDR, 100, "COM_ADDR",    "",             1,     247,   1,     RS_SAVE) \
 X(COM_BAUD, 101, "COM_BAUD",    "x100 bd",      12,    2304,  96,    RS_SAVE) \
 X(COM_PARITY,102,"COM_PARITY",  "0N 1E 2O",     0,     2,     0,     RS_SAVE) \
 X(COM_STOP, 103, "COM_STOP",    "bits",         1,     2,     1,     RS_SAVE) \
 X(COM_DATA, 104, "COM_DATABITS","bits",         7,     8,     8,     RS_SAVE) \
 X(COM_RDLY, 105, "COM_REPLY_DLY","ms",          0,     1000,  0,     RS_SAVE) \
 X(COM_T35,  106, "COM_T35",     "us 0=auto",    0,     20000, 0,     RS_SAVE) \
 /* ---- process ---- */ \
 X(F_START,  120, "F_START",     "Hz",           1000,  50000, 40000, RS_SAVE) \
 X(F_MIN,    121, "F_MIN",       "Hz",           1000,  50000, 28000, RS_SAVE) \
 X(F_MAX,    122, "F_MAX",       "Hz",           1000,  50000, 50000, RS_SAVE) \
 X(F_SET,    123, "F_SET",       "Hz",           1000,  50000, 31000, RS_SAVE) \
 X(P_SET,    124, "P_SET",       "x0.1 %",       0,     1000,  200,   RS_SAVE) \
 X(P_RAMP,   125, "P_RAMP",      "x0.1 %/s",     1,     1000,  100,   RS_SAVE) \
 X(DEADTIME, 126, "DEADTIME",    "ns",           100,   5000,  500,   RS_SAVE|RS_LOCK) \
 X(PWM_MODE, 127, "PWM_MODE",    "0PS 1Cross",   0,     1,     0,     RS_SAVE|RS_LOCK) \
 X(PH_TARGET,128, "PHASE_TARGET","x0.1 deg",     -900,  900,   300,   RS_SAVE|RS_SGN) \
 X(KP,       129, "PI_KP",       "x0.01",        0,     10000, 100,   RS_SAVE) \
 X(KI,       130, "PI_KI",       "x0.01",        0,     10000, 20,    RS_SAVE) \
 X(TRACK_EN, 131, "TRACK_EN",    "0off 1on",     0,     1,     1,     RS_SAVE) \
 X(CTRL_SRC, 132, "CTRL_SRC",    "0K 1485 2both",0,     2,     2,     RS_SAVE) \
 X(START_MS, 133, "START_TIME",  "ms",           100,   10000, 1000,  RS_SAVE) \
 X(AO_EN,    140, "AO_EN",       "0off 1on",     0,     1,     0,     RS_SAVE) \
 X(AO1_SRC,  141, "AO1_SOURCE",  "src 0..5", 0, 5, 2, RS_SAVE) \
 X(AO2_SRC,  142, "AO2_SOURCE",  "src 0..5", 0, 5, 1, RS_SAVE) \
 X(AO_F_MIN, 143, "AO_FREQ_MIN", "Hz",          1000,  50000, 28000, RS_SAVE) \
 X(AO_F_MAX, 144, "AO_FREQ_MAX", "Hz",          1000,  50000, 50000, RS_SAVE) \
 /* ---- protection ---- */ \
 X(I_MAX,    160, "I_BUS_MAX",   "x0.1 A",       10,    3000,  200,   RS_SAVE) \
 X(V_MAX,    161, "V_BUS_MAX",   "x0.1 V",       100,   8000,  300,   RS_SAVE) \
 X(V_MIN,    162, "V_BUS_MIN",   "x0.1 V",       0,     8000,  100,   RS_SAVE) \
 X(T_MAX,    163, "TEMP_MAX",    "x0.1 C",       300,   1500,  700,   RS_SAVE) \
 X(T_WARN,   164, "TEMP_WARN",   "x0.1 C",       300,   1500,  600,   RS_SAVE) \
 X(COMM_TMO, 165, "COMM_TIMEOUT","s 0=off",      0,     3600,  0,     RS_SAVE) \
 X(FLOW_EN,  166, "FLOW_EN",     "0off 1on",     0,     1,     1,     RS_SAVE) \
 X(RETRY,    167, "RETRY",       "count",        0,     9,     0,     RS_SAVE) \
 X(IN_POL,   168, "INPUT_POL",   "bit=active low",0,    15,    0,     RS_SAVE) \
 X(DERATE_EN,169, "TEMP_DERATE", "0off 1on",     0,     1,     0,     RS_SAVE) \
 /* ---- calibration ---- */ \
 X(CAL_I_G,  200, "CAL_I_GAIN",  "x0.001",       500,   1500,  1000,  RS_SAVE) \
 X(CAL_I_O,  201, "CAL_I_OFFSET","counts",       -500,  500,   0,     RS_SAVE|RS_SGN) \
 X(CAL_V_G,  202, "CAL_V_GAIN",  "x0.001",       500,   1500,  1000,  RS_SAVE) \
 X(CAL_V_O,  203, "CAL_V_OFFSET","counts",       -500,  500,   0,     RS_SAVE|RS_SGN) \
 X(CAL_T_O,  204, "CAL_T_OFFSET","x0.1 C",       -200,  200,   0,     RS_SAVE|RS_SGN) \
 X(I_FS,     205, "I_FULLSCALE", "x0.1 A",       10,    5000,  500,   RS_SAVE) \
 X(V_FS,     206, "V_FULLSCALE", "x0.1 V",       100,   10000, 330,   RS_SAVE) \
 /* ---- display ---- */ \
 X(BL_TMO,   240, "BACKLIGHT_TMO","s 0=on",      0,     3600,  0,     RS_SAVE) \
 X(KEY_RPT_EN,241,"KEY_REPEAT_EN","0off 1on",    0,     1,     1,     RS_SAVE) \
 X(KEY_RPT_MS,242,"KEY_REPEAT_MS","ms",          100,   1000,  300,   RS_SAVE) \
 X(KEY_RPT_DLY,243,"KEY_REPEAT_DLY","ms",        200,   2000,  800,   RS_SAVE) \
 /* ---- storage ---- */ \
 X(AUTO_SAVE,244, "AUTO_SAVE",   "0off 1on",     0,     1,     1,     RS_SAVE) \
 X(SAVE_DLY, 245, "SAVE_DELAY",  "s",            1,     60,    3,     RS_SAVE) \
 /* ---- simulation (test aid, not saved): replaces the measurements while SIM_EN = 1 ---- */ \
 X(SIM_EN,   250, "SIM_EN",      "0off 1on",     0,     1,     0,     0) \
 X(SIM_V,    251, "SIM_V_BUS",   "x0.1 V",       0,     10000, 240,   0) \
 X(SIM_I,    252, "SIM_I_BUS",   "x0.1 A",       0,     10000, 0,     0) \
 X(SIM_T,    253, "SIM_TEMP",    "x0.1 C",       -500,  2000,  250,   RS_SGN)

/* register index = position in the table; use R_xxx with reg_get() */
enum {
#define X(id, a, n, u, mn, mx, df, fl) R_##id,
    REG_LIST
#undef X
    REG_COUNT
};

typedef struct {
    uint16_t    addr;
    const char *name;
    const char *unit;
    int32_t     min, max, def;
    uint8_t     flags;
} reg_info_t;

extern const reg_info_t reg_table[REG_COUNT];

/* bits of R_FAULT_NOW / R_FAULT_LATCH are F_xxx in control.h (the LCD shows them as fault numbers 1..8 and W) */
/* bits of R_IO_IN (live state of the inputs, 1 = active, after INPUT_POL) and bits of R_IN_POL */
enum { IN_START = 1u << 0, IN_STOP = 1u << 1, IN_FLOW = 1u << 2, IN_ESTOP = 1u << 3, IN_HW = 1u << 4 };

/* values of R_STATE */
enum { ST_IDLE = 0, ST_READY = 1, ST_START = 2, ST_RUN = 3, ST_FAULT = 4 };

/* values written to R_CMD */
enum { CMD_NONE = 0, CMD_START = 1, CMD_STOP = 2, CMD_RESET_FAULT = 3, CMD_SAVE = 4,
       CMD_DEFAULTS = 5, CMD_APPLY_COMM = 6, CMD_REBOOT = 7 };

/* result codes of reg_write(); the RS-485 layer maps them to Modbus exceptions */
typedef enum { REG_OK = 0, REG_ERR_ADDR, REG_ERR_VALUE, REG_ERR_RO, REG_ERR_BUSY, REG_ERR_DENIED } reg_err_t;

/* who writes: START and RESET FAULT are accepted only from the source allowed by CTRL_SRC
 * (0 keypad/local input, 1 RS-485, 2 both). STOP and all settings are accepted from anywhere. */
typedef enum { SRC_LOCAL = 0, SRC_RS485 = 1 } reg_src_t;

/* Registers that accept only a fixed list of values (COM_BAUD: standard baud rates only).
 * Returns 1 and the next/previous allowed value in *out if the register has such a list, else 0. */
int      reg_list_step(int idx, int32_t cur, int dir, int32_t *out);

void     regs_init(void);                 /* defaults, then load from flash; returns nothing */
int      regs_loaded_from_flash(void);    /* 1 if the flash copy was valid at boot            */

/* firmware side (no checks) */
static inline int reg_is_signed(int idx) { return (reg_table[idx].flags & RS_SGN) != 0; }
uint16_t reg_get(int idx);                /* raw 16-bit                                       */
int32_t  reg_val(int idx);                /* signed-aware value                               */
void     reg_set(int idx, int32_t v);     /* firmware updates status registers                */

/* external side: keypad and RS-485 (all checks) */
int       reg_find(uint16_t addr);        /* table index or -1                                */
reg_err_t reg_read(uint16_t addr, uint16_t *raw);
reg_err_t reg_write(uint16_t addr, uint16_t raw);                      /* = reg_write_from(.., SRC_LOCAL) */
reg_err_t reg_write_from(uint16_t addr, uint16_t raw, reg_src_t src);

/* commands and housekeeping */
void regs_service(void);                  /* call in the main loop: executes Save and Defaults */
int  regs_cmd_take(void);                 /* process commands (start, stop, reset, reboot) for control */
int  regs_start_allowed(reg_src_t src);   /* may this source start / reset the inverter?        */
int  regs_comm_changed_take(void);        /* 1 once after any COM_xxx register changed         */
int  regs_restore(uint16_t addr, uint16_t raw);   /* used by flash_store: 1 if accepted     */
int  regs_save(void);                     /* 0 ok, 1 busy (running), 2 flash error             */
void regs_autosave_service(uint32_t now_ms);   /* main loop: saves settings written from RS-485 after SAVE_DELAY, never while starting/running */
void regs_load_defaults(void);            /* factory values of all saved registers (not saved) */

#endif
