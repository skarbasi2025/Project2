/* lcd.h - HD44780 20x4 character LCD behind a PCF8574 I2C backpack (4-bit mode) */
#ifndef LCD_H
#define LCD_H
#include <stdint.h>

#define LCD_COLS 20
#define LCD_ROWS 4
#define LCD_DEG  "\xDF"      /* degree sign in the standard HD44780 ROM (A00) */

int  lcd_init(void);                          /* returns 1 if the backpack answered, 0 if not */
int  lcd_present(void);                       /* result of the last I2C transfer              */
void lcd_clear(void);                         /* clear and home (takes 2 ms)                  */
void lcd_goto(uint8_t row, uint8_t col);
void lcd_putc(char c);
void lcd_puts(const char *s);
void lcd_line(uint8_t row, const char *s);    /* writes exactly 20 chars, pads with spaces    */
void lcd_cursor(uint8_t on);                  /* underline cursor on/off                      */
void lcd_backlight(uint8_t on);

#endif
