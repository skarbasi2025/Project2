#ifndef UI_REGTEST_H
#define UI_REGTEST_H
void ui_regtest_init(void);
void ui_regtest_step(void);     /* call as often as possible */
#endif
