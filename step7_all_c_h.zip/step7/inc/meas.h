/* meas.h - conversion of ADC counts to engineering units (x0.1 V, x0.1 A, x0.1 C). Pure functions, no hardware:
 * tested on the PC (test/test_meas.c). The ADC driver (adc.c) only averages the counts and calls these.
 *
 * Assumed wiring (confirm on the schematic):
 *   V_BUS  (PA7): 91k / 10k divider (sheet 4): 33.0 V on the bus = 3.3 V at the pin (V_FULLSCALE = 330).
 *   I_BUS  (PA4): ACS758LCB-050B, 2/3 divider (sheet 4): 0 A = 1.667 V, +50 A = 3.0 V, -50 A = 0.33 V.
 *   TEMP   (PA6): NTC 10 k B3950 to GND, 10 k pull-up to 3.3 V (sheet 4).
 * The tank current (CT, sheet 5) does NOT go to the ADC: it feeds the phase capture and the hardware
 * over-current window (sheet 6).                                                                       */
#ifndef MEAS_H
#define MEAS_H
#include <stdint.h>

#define ADC_FULL 4095u              /* 12-bit ADC, full scale = 3.3 V */

/* x0.1 V.  fs = V_FULLSCALE (x0.1 V), gain = CAL_V_GAIN (x0.001, 1000 = 1.0), off = CAL_V_OFFSET (counts) */
int32_t meas_bus_v(uint32_t raw, uint32_t fs, int32_t gain_milli, int32_t off_counts);
/* x0.1 A, signed. ACS758LCB-050B (+-50 A, bidirectional) through the 2/3 divider (sheet 4):
 * pin = 1.667 V at 0 A, +26.67 mV per A.  gain = CAL_I_GAIN (x0.001), off = CAL_I_OFFSET (counts) */
int32_t meas_bus_i(uint32_t raw, int32_t gain_milli, int32_t off_counts);
/* x0.1 C.  off = CAL_T_OFFSET (x0.1 C) */
int32_t meas_temp(uint32_t raw, int32_t off_tenths);

#endif
