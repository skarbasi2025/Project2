/* keypad.h - five push buttons (MODE, SHIFT, UP, DOWN, ENTER) with debounce, event queue and auto-repeat.
 *
 * Events returned by keypad_get():
 *   KEY_UP, KEY_DOWN    pressed (and again while held, see keypad_set_repeat)
 *   KEY_SHIFT           pressed
 *   KEY_MODE, KEY_ENTER released after a short press (less than KEY_LONG_MS)
 *   KEY_MODE_LONG       MODE held for KEY_LONG_MS (sent once, no short event on release)
 *   KEY_ENTER_LONG      ENTER held for KEY_LONG_MS (sent once, no short event on release)
 *
 * Wiring: each button connects its pin to +3.3 V; a 10k pull-down holds the pin low when released (active high). */
#ifndef KEYPAD_H
#define KEYPAD_H
#include <stdint.h>

#define KEY_NONE       0
#define KEY_UP        'U'
#define KEY_DOWN      'D'
#define KEY_ENTER     'E'
#define KEY_MODE      'M'
#define KEY_SHIFT     'S'
#define KEY_MODE_LONG 'G'      /* MODE held: go to a register by number */
#define KEY_ENTER_LONG 'W'     /* ENTER held: save to flash            */
#define KEY_LONG_MS   2000u

void keypad_init(void);
void keypad_poll(void);                   /* call often from the main loop (it scans every 5 ms) */
char keypad_get(void);                    /* oldest event, or 0 if none                          */
char keypad_held(void);                   /* key that is down right now (debounced), or 0        */
void keypad_set_repeat(const char *keys); /* keys that repeat while held, e.g. "UD" ("" = none)  */
void keypad_set_timing(uint16_t first_delay_ms, uint16_t rate_ms);   /* auto-repeat: first delay, then the first period;
                                                                        * the period shrinks while held (accelerates), min 50 ms */

#endif
