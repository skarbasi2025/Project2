/* board.h - pin assignment for the induction heater controller, STM32F103C8 (48 pins)
 *
 *  PA0  AO_FREQ_PWM (TIM2_CH1)   PB0  LATCH_Q          PC13 FLOW_FAULT
 *  PA1  AO_PWR_PWM  (TIM2_CH2)   PB1  LATCH_CLR        PC14 ESTOP_FAULT
 *  PA2  free                     PB2  STOP_EXT (BOOT1)   PC15 RS485_DE
 *  PA3  free                     PB3  KEY_DOWN           PD0, PD1: crystal
 *  PA4  I_BUS_ADC                PB4  LED_FAULT
 *  PA5  free                     PB5  KEY_MODE
 *  PA6  TEMP_ADC                 PB6  I2C_SCL (LCD)
 *  PA7  V_BUS_ADC                PB7  I2C_SDA (LCD)
 *  PA8  HIN1 (TIM1_CH1)          PB8  START_EXT
 *  PA9  HIN2 (TIM1_CH2)          PB9  KEY_SHIFT
 *  PA10 CAP_I (TIM1_CH3)         PB10 RS485_TX (USART3)
 *  PA11 CAP_V (TIM1_CH4)         PB11 RS485_RX (USART3)
 *  PA12 KEY_ENTER                PB12 FAULT (TIM1_BKIN)
 *  PA13 SWDIO                    PB13 LIN1 (TIM1_CH1N)
 *  PA14 SWCLK                    PB14 LIN2 (TIM1_CH2N)
 *  PA15 LED_RUN                  PB15 KEY_UP
 *
 * PA15, PB3, PB4 are JTAG pins after reset: board_init() turns JTAG off (SWD stays).  */
#ifndef BOARD_H
#define BOARD_H

#include "stm32f1xx.h"
#include "gpio_f1.h"

/* ---------- clock: set by HAL (SystemClock_Config in main.c) ----------
 * CLOCK_64MHZ 1 = HSE 8 MHz x PLL 8 = 64 MHz (the board). 0 = HSE 8 MHz without PLL (Proteus test: the simulation
 * runs much faster, the LCD and keys respond at once). Both are real-time correct on the board. */
#ifndef CLOCK_64MHZ
#define CLOCK_64MHZ 0
#endif
#if CLOCK_64MHZ
#define SYSCLK_HZ  64000000u
#define APB1_HZ    32000000u                          /* SYSCLK / 2 */
#else
#define SYSCLK_HZ  8000000u
#define APB1_HZ    8000000u                           /* APB1 prescaler 1 */
#endif
/* LCD bus. 0 = bit-banged I2C (slow in Proteus, busy-wait delays). 1 = hardware I2C1 on PB6/PB7. */
#ifndef LCD_USE_HW_I2C
#define LCD_USE_HW_I2C 0
#endif
extern uint32_t SystemCoreClock;

void board_init(void);   /* GPIOA/B/C + AFIO clocks, JTAG off (SWD on). The clock is set by HAL before this. */

/* ---------- LCD 20x4 with I2C backpack (PCF8574), bit-banged I2C ---------- */
#define I2C_SCL_PORT   GPIOB
#define I2C_SCL_PIN    6
#define I2C_SDA_PORT   GPIOB
#define I2C_SDA_PIN    7
#define I2C_HALF_US    2          /* half bit time in us: about 200 kHz in practice */
#define LCD_I2C_ADDR   0x38       /* 7-bit address. Proteus I2C LCD field $70 = 0x38. Real backpacks: 0x27 (PCF8574T) or 0x3F (PCF8574AT) */

/* PCF8574 bit order of the usual backpack: P0 RS, P1 RW, P2 E, P3 backlight, P4..P7 = D4..D7 */
#define PCF_RS   0x01
#define PCF_RW   0x02
#define PCF_E    0x04
#define PCF_BL   0x08

/* ---------- Five buttons: active high (to +3.3 V), 10k pull-down. Order = keypad.c table: UP, DOWN, ENTER, MODE, SHIFT ---------- */
#define KEY_UP_PORT    GPIOB
#define KEY_UP_PIN     15
#define KEY_DOWN_PORT  GPIOB
#define KEY_DOWN_PIN   3
#define KEY_ENTER_PORT GPIOA
#define KEY_ENTER_PIN  12
#define KEY_MODE_PORT  GPIOB
#define KEY_MODE_PIN   5
#define KEY_SHIFT_PORT GPIOB
#define KEY_SHIFT_PIN  9
#define KEY_PINS_INIT { {KEY_UP_PORT, KEY_UP_PIN}, {KEY_DOWN_PORT, KEY_DOWN_PIN}, {KEY_ENTER_PORT, KEY_ENTER_PIN}, \
                        {KEY_MODE_PORT, KEY_MODE_PIN}, {KEY_SHIFT_PORT, KEY_SHIFT_PIN} }

/* ---------- RS-485 UART ----------
 * Normal: USART3 (PB10 TX, PB11 RX). If the simulator (Proteus) does not drive USART3, uncomment the next line to
 * use USART1 (PA9 TX, PA10 RX) in BOTH the controller and the test master. Keep it commented for the real board:
 * PA9/PA10 are needed by TIM1 there.                                                                          */
/* #define MB_USE_USART1 */
#ifdef MB_USE_USART1
#define MB_UART           USART1
#define MB_IRQn           USART1_IRQn
#define MB_IRQ_HANDLER    USART1_IRQHandler
#define MB_UART_CLK_ON()  (RCC->APB2ENR |= RCC_APB2ENR_USART1EN)
#define MB_PCLK_SHIFT()   (((RCC->CFGR >> 11) & 7u) < 4u ? 0u : (((RCC->CFGR >> 11) & 7u) - 3u))   /* APB2 */
#define RS485_TX_PORT  GPIOA
#define RS485_TX_PIN   9
#define RS485_RX_PORT  GPIOA
#define RS485_RX_PIN   10
#else
#define MB_UART           USART3
#define MB_IRQn           USART3_IRQn
#define MB_IRQ_HANDLER    USART3_IRQHandler
#define MB_UART_CLK_ON()  (RCC->APB1ENR |= RCC_APB1ENR_USART3EN)
#define MB_PCLK_SHIFT()   (((RCC->CFGR >> 8) & 7u) < 4u ? 0u : (((RCC->CFGR >> 8) & 7u) - 3u))     /* APB1 */
#define RS485_TX_PORT  GPIOB
#define RS485_TX_PIN   10
#define RS485_RX_PORT  GPIOB
#define RS485_RX_PIN   11
#endif
#define RS485_DE_PORT  GPIOC
#define RS485_DE_PIN   15

/* ---------- Digital inputs / latch. Active level: 1 = the line is HIGH when the condition is true.
 * The *_ACTIVE macros are the default; register INPUT_POL (168) inverts START, STOP, FLOW and E-STOP at run time. The internal pull always holds the inactive level. ---------- */
#define FLOW_PORT      GPIOC          /* flow switch of the cooling water: fault when the flow is missing */
#define FLOW_PIN       13
#define FLOW_ACTIVE    1
#define ESTOP_PORT     GPIOC          /* emergency stop chain */
#define ESTOP_PIN      14
#define ESTOP_ACTIVE   1
#define HWFAULT_PORT   GPIOB          /* TIM1_BKIN line: driver fault / hardware overcurrent comparator */
#define HWFAULT_PIN    12
#define HWFAULT_ACTIVE 1
#define LATCH_Q_PORT   GPIOB          /* output Q of the hardware fault latch */
#define LATCH_Q_PIN    0
#define LATCH_Q_ACTIVE 1
#define LATCH_CLR_PORT GPIOB          /* clears the hardware latch (pulse) */
#define LATCH_CLR_PIN  1
#define LATCH_CLR_ACTIVE 0            /* the 74HC74 /CLR is active LOW (sheet 6): low pulse clears, idle = released (open drain) */
#define START_EXT_PORT GPIOB          /* external start push button */
#define START_EXT_PIN  8
#define START_EXT_ACTIVE 1
#define STOP_EXT_PORT  GPIOB          /* external stop push button (PB2 = BOOT1: keep it low at reset) */
#define STOP_EXT_PIN   2
#define STOP_EXT_ACTIVE 1

/* ---------- LEDs ---------- */
#define LED_RUN_PORT   GPIOA
#define LED_RUN_PIN    15
#define LED_FAULT_PORT GPIOB
#define LED_FAULT_PIN  4

#endif
