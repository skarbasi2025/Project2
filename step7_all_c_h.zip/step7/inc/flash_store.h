/* flash_store.h - keeps the saved registers in one flash page.
 * STM32F103C8 has 64 KB guaranteed: the last 1 KB page is 0x0800FC00.
 * In the IAR linker file (.icf) reduce the ROM region so the program never uses it:
 *     define symbol __ICFEDIT_region_ROM_end__ = 0x0800FBFF;
 * Content: magic, layout version, count, then (address, value) pairs, then CRC16.
 * Pairs by address (not by table position) keep old settings valid after a firmware update. */
#ifndef FLASH_STORE_H
#define FLASH_STORE_H
#include <stdint.h>

#define FLASH_STORE_ADDR  0x0800FC00u
#define FLASH_STORE_SIZE  1024u

int flash_store_load(void);   /* number of registers restored, -1 if the page is empty/corrupt */
int flash_store_save(void);   /* 0 ok, -1 erase, -2 program, -3 verify error                    */

/* low level, in flash_hw.c (replaced by a mock in the host test) */
const uint16_t *flash_hw_page(void);
int  flash_hw_erase_page(void);                     /* 0 ok */
int  flash_hw_prog16(uint32_t offset, uint16_t v);  /* 0 ok; offset in bytes from the page start */

#endif
