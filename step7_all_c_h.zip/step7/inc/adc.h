/* adc.h - measurements: ADC1 scan of PA4 (I_BUS), PA6 (TEMP), PA7 (V_BUS) by DMA1 channel 1, averaged over
 * 16 scans. adc_step() converts the average to units (meas.c) and writes R_V_BUS, R_I_BUS, R_TEMP and the raw
 * counts R_ADC_V / R_ADC_I / R_ADC_T. SIM_EN (250) still overrides these values in control.c.          */
#ifndef ADC_H
#define ADC_H
#include <stdint.h>

void adc_init(void);                  /* clocks, DMA, calibration, start the continuous scan */
void adc_step(uint32_t now_ms);       /* call often; converts every 10 ms */

#endif
