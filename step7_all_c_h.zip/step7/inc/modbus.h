/* modbus.h - Modbus RTU slave on USART3 (RS-485), reading and writing the register table.
 *
 * Functions: 03 read holding registers, 04 read input registers (same table), 06 write single,
 * 16 write multiple. Address 0 = broadcast (writes only, no reply).
 * Everything about the line is a register (100-106): address, baud, parity, stop bits, data bits,
 * reply delay, t3.5. They are applied automatically after the reply to the write that changed
 * them, so the answer still goes out with the old settings.                                     */
#ifndef MODBUS_H
#define MODBUS_H
#include <stdint.h>

#define MB_MAX_FRAME 256

typedef enum { MB_IGNORED = 0, MB_OK, MB_EXCEPTION, MB_CRC_ERR } mb_result_t;

/* protocol only (no hardware): handles one received frame and builds the reply.
 * Returns the reply length in bytes (0 = no reply); *res tells what happened. */
int modbus_handle(const uint8_t *req, int len, uint8_t *resp, uint8_t own_addr, mb_result_t *res);

/* hardware layer (USART3, TIM4, PC15) */
void modbus_init(int recovery);   /* recovery = 1: use 9600 8N1, address 1 until the next reset */
void modbus_poll(void);           /* call in the main loop */
int  modbus_busy(void);           /* 1 while a frame is being received/answered: do not erase flash or reboot */
void modbus_apply(void);          /* (re)configure the UART from the COM_xxx registers */

#endif
