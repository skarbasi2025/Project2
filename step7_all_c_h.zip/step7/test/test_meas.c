/* test_meas.c - host test of the count-to-unit conversions (meas.c). Build: gcc -Iinc test/test_meas.c src/meas.c -lm -o t && ./t */
#include <stdio.h>
#include <stdlib.h>
#include "meas.h"

static int fails;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

int main(void)
{
    CHECK(meas_bus_v(4095, 330, 1000, 0) == 330);
    CHECK(meas_bus_v(2048, 330, 1000, 0) == 165);
    CHECK(meas_bus_v(0, 330, 1000, 0) == 0);
    CHECK(meas_bus_v(5000, 330, 1000, 0) == 330);            /* clamped to full scale */
    CHECK(meas_bus_v(4095, 330, 1000, -10) == 329);          /* offset -10 counts */
    CHECK(meas_bus_v(2048, 330, 1100, 0) == 181);            /* gain 1.100 */
    CHECK(meas_bus_v(0, 330, 1000, 10) == 0);                /* offset +10 counts at zero input */

    /* bus current: ACS758 through the 2/3 divider. Zero = 2068 counts (1.667 V), 33.08 counts per A */
    CHECK(meas_bus_i(2068, 1000, 0) == 0);
    int32_t ip = meas_bus_i(2068 + 1654, 1000, 0);           /* +50 A */
    CHECK(ip >= 495 && ip <= 505);
    int32_t in = meas_bus_i(2068 - 1654, 1000, 0);           /* -50 A (reverse current) */
    CHECK(in <= -495 && in >= -505);
    CHECK(meas_bus_i(4095, 1000, 0) > 500);                  /* full scale: beyond 50 A, not clamped to 50 */
    CHECK(meas_bus_i(2068, 1000, 10) > 0);                   /* CAL_I_OFFSET trim */
    CHECK(meas_bus_i(2068 + 1654, 1100, 0) > ip);            /* gain trim 1.100 */

    /* bus voltage: V_FULLSCALE 330 (33.0 V at 3.3 V on the pin, 91k/10k divider) */
    CHECK(meas_bus_v(4095, 330, 1000, 0) == 330);
    int32_t v24 = meas_bus_v(2949, 330, 1000, 0);            /* 24 V on the bus = 2.376 V on the pin = 2949 counts */
    CHECK(v24 >= 236 && v24 <= 240);

    /* temperature: NTC 10 k B3950, 10 k pull-up. Mid-scale divider = 10 k = 25.0 C */
    int32_t t25 = meas_temp(2048, 0);
    CHECK(t25 >= 248 && t25 <= 252);
    CHECK(meas_temp(2048, -30) == t25 - 30);                 /* CAL_T_OFFSET applied */
    CHECK(meas_temp(1000, 0) > 250);                          /* low count = low resistance = hot */
    CHECK(meas_temp(3000, 0) < 250);                          /* high count = high resistance = cold */
    CHECK(meas_temp(0, 0) == meas_temp(1, 0));               /* ends are clamped, no crash */
    CHECK(meas_temp(4095, 0) == meas_temp(4094, 0));

    printf(fails ? "\n%d FAILED\n" : "\nALL OK (meas)\n", fails);
    return fails != 0;
}
