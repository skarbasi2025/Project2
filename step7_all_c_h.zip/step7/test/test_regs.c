/* Host test of regs.c, flash_store.c (with a mock flash page) and the register editor UI. */
#include "regs.h"
#include "flash_store.h"
#include "ui_regtest.h"
#include "hostsim.h"

/* ---------- mock flash page ---------- */
static uint16_t mock_page[512];
static int mock_erases, mock_fail_erase;
const uint16_t *flash_hw_page(void) { return mock_page; }
int flash_hw_erase_page(void) { if (mock_fail_erase) return -1; mock_erases++; for (int i = 0; i < 512; i++) mock_page[i] = 0xFFFF; return 0; }
int flash_hw_prog16(uint32_t off, uint16_t v) { if (mock_page[off / 2] != 0xFFFF) return -1; mock_page[off / 2] = v; return 0; }

static int fails;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

static void row_text(int row, char *out)
{
    static const int base[4] = {0x00, 0x40, 0x14, 0x54};
    memcpy(out, &ddram[base[row]], 20); out[20] = 0;
}
static void run_ms(int ms) { for (int i = 0; i < ms; i++) { sim_us += 1000; update_idr(); ui_regtest_step(); } }
/* five buttons: index 0 UP, 1 DOWN, 2 ENTER, 3 MODE, 4 SHIFT (see hostsim.h) */
enum { B_UP, B_DOWN, B_ENTER, B_MODE, B_SHIFT };
/* the selected digit blinks (off half of each 500 ms): wait for the on half before reading row 3 */
static void show_on(void) { for (int i = 0; i < 100 && !((millis() / 250u) & 1u); i++) run_ms(10); run_ms(5); }

static void press(int b, int ms) { sim_key_down[b] = 1; run_ms(ms); sim_key_down[b] = 0; run_ms(40); }
static void tap(int b) { press(b, 40); }
static void hold(int b, int ms) { press(b, ms); }
static void tapn(int b, int n) { for (int i = 0; i < n; i++) tap(b); }

int main(void)
{
    /* ---- table sanity ---- */
    for (int i = 0; i < REG_COUNT; i++) {
        const reg_info_t *r = &reg_table[i];
        if (i) CHECK(r->addr > reg_table[i - 1].addr);                 /* sorted, unique */
        CHECK(r->min <= r->def && r->def <= r->max);
        CHECK(strlen(r->name) <= 14);
        CHECK(strlen(r->unit) <= 15);
        if (!(r->flags & RS_SGN)) CHECK(r->min >= 0 && r->max <= 65535);
        else CHECK(r->min >= -32768 && r->max <= 32767);
        CHECK(reg_find(r->addr) == i);
    }
    CHECK(reg_find(99) < 0 && reg_find(65535) < 0);
    printf("registers: %d\n", REG_COUNT);

    /* ---- empty flash -> defaults ---- */
    memset(mock_page, 0xFF, sizeof mock_page);
    regs_init();
    CHECK(!regs_loaded_from_flash());
    CHECK(reg_get(R_COM_ADDR) == 1 && reg_get(R_COM_BAUD) == 96 && reg_get(R_FW_VER) == 100);
    CHECK(regs_comm_changed_take() == 1 && regs_comm_changed_take() == 0);

    /* ---- reads / writes ---- */
    uint16_t v;
    CHECK(reg_read(100, &v) == REG_OK && v == 1);
    CHECK(reg_read(50, &v) == REG_ERR_ADDR);
    CHECK(reg_write(100, 0) == REG_ERR_VALUE);
    CHECK(reg_write(100, 248) == REG_ERR_VALUE);
    CHECK(reg_write(100, 17) == REG_OK && reg_get(R_COM_ADDR) == 17);
    CHECK(regs_comm_changed_take() == 1);
    CHECK(reg_write(101, 2501) == REG_ERR_VALUE);                       /* above max */
    CHECK(reg_write(101, 11) == REG_ERR_VALUE);
    CHECK(reg_write(101, 100) == REG_ERR_VALUE);                        /* 10000 is not a standard baud */
    CHECK(reg_write(101, 2400) == REG_ERR_VALUE);
    CHECK(reg_write(101, 2304) == REG_OK && reg_write(101, 12) == REG_OK && reg_write(101, 1152) == REG_OK);
    { static const int ok[] = {12,24,48,96,192,384,576,1152,2304};
      for (int b = 0; b < 3000; b++) { int is = 0; for (unsigned k = 0; k < 9; k++) if (ok[k] == b) is = 1;
          reg_err_t e = reg_write(101, (uint16_t)b);
          if (is) CHECK(e == REG_OK); else CHECK(e == REG_ERR_VALUE); }
      CHECK(reg_write(101, 1152) == REG_OK); }
    { int32_t o; CHECK(reg_list_step(R_COM_BAUD, 96, 1, &o) && o == 192);
      CHECK(reg_list_step(R_COM_BAUD, 96, -1, &o) && o == 48);
      CHECK(reg_list_step(R_COM_BAUD, 2304, 1, &o) && o == 12);
      CHECK(reg_list_step(R_COM_BAUD, 12, -1, &o) && o == 2304);
      CHECK(reg_list_step(R_COM_BAUD, 100, 1, &o) && o == 192);
      CHECK(!reg_list_step(R_COM_ADDR, 1, 1, &o)); }
    
    CHECK(reg_write(3, 1) == REG_ERR_RO);
    CHECK(reg_write(0, 1) == REG_ERR_RO);
    CHECK(reg_write(999, 1) == REG_ERR_ADDR);
    CHECK(reg_write(128, (uint16_t)-100) == REG_OK && reg_val(R_PH_TARGET) == -100);   /* signed */
    CHECK(reg_write(128, (uint16_t)-901) == REG_ERR_VALUE);
    CHECK(reg_write(128, 901) == REG_ERR_VALUE);
    CHECK(reg_write(120, 1) == REG_ERR_VALUE);
    CHECK(reg_write(121, 50000) == REG_ERR_VALUE);                      /* F_MIN must be < F_MAX */
    CHECK(reg_write(122, 28000) == REG_ERR_VALUE);                      /* F_MAX must be > F_MIN */
    CHECK(reg_write(121, 20000) == REG_OK);
    CHECK(reg_write(163, 500) == REG_ERR_VALUE);                        /* T_MAX >= T_WARN(600) */

    /* ---- lock while running ---- */
    reg_set(R_STATE, ST_RUN);
    CHECK(reg_write(126, 300) == REG_ERR_BUSY);
    CHECK(reg_write(127, 1) == REG_ERR_BUSY);
    CHECK(reg_write(124, 300) == REG_OK);                               /* power can change live */
    CHECK(regs_save() == 1 && reg_get(R_CMD_RES) == 1);
    reg_set(R_STATE, ST_IDLE);
    CHECK(reg_write(126, 300) == REG_OK);

    /* ---- commands ---- */
    CHECK(reg_write(20, CMD_START) == REG_OK);
    CHECK(reg_read(20, &v) == REG_OK && v == 0);
    CHECK(regs_cmd_take() == CMD_START && regs_cmd_take() == 0);
    CHECK(reg_write(20, 8) == REG_ERR_VALUE);

    /* ---- save / load ---- */
    CHECK(reg_write(20, CMD_SAVE) == REG_OK);
    regs_service();
    CHECK(reg_get(R_CMD_RES) == 0 && mock_erases == 1);
    CHECK(mock_page[0] == 0x5AA5);
    regs_load_defaults();
    CHECK(reg_get(R_COM_ADDR) == 1 && reg_val(R_PH_TARGET) == 300);
    regs_init();                                                        /* reload from the mock flash */
    CHECK(regs_loaded_from_flash());
    CHECK(reg_get(R_COM_ADDR) == 17 && reg_get(R_COM_BAUD) == 1152 && reg_val(R_PH_TARGET) == -100 &&
          reg_get(R_DEADTIME) == 300 && reg_get(R_F_MIN) == 20000 && reg_get(R_P_SET) == 300);
    CHECK(reg_get(R_STATE) == 0 && reg_get(R_FW_VER) == 100);

    /* ---- auto save: settings written from RS-485 are stored by themselves after SAVE_DELAY ---- */
    { int e0 = mock_erases; unsigned c0 = reg_get(R_SAVE_CNT);
      CHECK(reg_get(R_AUTO_SAVE) == 1 && reg_get(R_SAVE_DLY) == 3 && reg_get(R_SAVE_ST) == 0);
      CHECK(reg_write_from(124, 400, SRC_RS485) == REG_OK && reg_get(R_SAVE_ST) == 1);
      regs_autosave_service(1000);                       /* timer starts: due at 4000 */
      regs_autosave_service(3900); CHECK(mock_erases == e0);
      CHECK(reg_write_from(123, 32000, SRC_RS485) == REG_OK);
      regs_autosave_service(4000);                       /* a new write restarts the delay: due at 7000 */
      regs_autosave_service(6900); CHECK(mock_erases == e0);
      regs_autosave_service(7000);
      CHECK(mock_erases == e0 + 1 && reg_get(R_SAVE_ST) == 0 && reg_get(R_SAVE_CNT) == c0 + 1);
      CHECK(reg_get(R_CMD_RES) == 0);                    /* a master's own command result is not touched */
      /* same value again: nothing changes, nothing is saved */
      CHECK(reg_write_from(124, 400, SRC_RS485) == REG_OK);
      regs_autosave_service(8000); regs_autosave_service(30000);
      CHECK(mock_erases == e0 + 1 && reg_get(R_SAVE_ST) == 0);
      /* keypad edits wait for D, they do not start the timer */
      CHECK(reg_write_from(124, 410, SRC_LOCAL) == REG_OK && reg_get(R_SAVE_ST) == 1);
      regs_autosave_service(31000); regs_autosave_service(50000);
      CHECK(mock_erases == e0 + 1 && reg_get(R_SAVE_ST) == 1);
      CHECK(regs_save() == 0 && reg_get(R_SAVE_ST) == 0 && mock_erases == e0 + 2);   /* the D key */
      /* running: the value applies at once, the save waits for the stop */
      reg_set(R_STATE, ST_RUN);
      CHECK(reg_write_from(124, 420, SRC_RS485) == REG_OK && reg_get(R_P_SET) == 420);
      regs_autosave_service(60000); regs_autosave_service(80000);
      CHECK(mock_erases == e0 + 2 && reg_get(R_SAVE_ST) == 1);
      reg_set(R_STATE, ST_IDLE);
      regs_autosave_service(80001);
      CHECK(mock_erases == e0 + 3 && reg_get(R_SAVE_ST) == 0);
      /* AUTO_SAVE = 0 */
      CHECK(reg_write_from(244, 0, SRC_RS485) == REG_OK);
      regs_autosave_service(90000); regs_autosave_service(120000);
      CHECK(mock_erases == e0 + 4);                      /* the write of AUTO_SAVE itself is the last one saved */
      CHECK(reg_write_from(124, 430, SRC_RS485) == REG_OK);
      regs_autosave_service(130000); regs_autosave_service(160000);
      CHECK(mock_erases == e0 + 4 && reg_get(R_SAVE_ST) == 1);
      reg_write(244, 1);
      /* flash error: shown in SAVE_STATE, no endless retries */
      mock_fail_erase = 1;
      CHECK(reg_write_from(124, 440, SRC_RS485) == REG_OK);
      regs_autosave_service(170000); regs_autosave_service(174000);
      CHECK(reg_get(R_SAVE_ST) == 2);
      mock_fail_erase = 0;
      regs_autosave_service(180000); regs_autosave_service(200000);
      CHECK(mock_erases == e0 + 4 && reg_get(R_SAVE_ST) == 2);
      CHECK(regs_save() == 0 && reg_get(R_SAVE_ST) == 0); }

    /* ---- input polarity register ---- */
    CHECK(reg_write(168, 16) == REG_ERR_VALUE && reg_write(168, 3) == REG_OK && reg_get(R_IN_POL) == 3);
    CHECK(reg_write(168, 0) == REG_OK);

    /* ---- defaults command ---- */
    CHECK(reg_write(20, CMD_DEFAULTS) == REG_OK);
    regs_service();
    CHECK(reg_get(R_COM_ADDR) == 1 && regs_comm_changed_take());

    /* ---- corruption: one flipped bit -> flash ignored ---- */
    regs_init();
    mock_page[10] ^= 0x0100;
    regs_init();
    CHECK(!regs_loaded_from_flash());
    CHECK(reg_get(R_COM_ADDR) == 1);

    /* ---- new firmware: unknown address and out-of-range values in the page are skipped ---- */
    regs_init();
    CHECK(reg_write(100, 33) == REG_OK);
    CHECK(regs_save() == 0);
    uint16_t n = mock_page[2];
    mock_page[3 + 2 * n] = 0xFFFF;                                      /* keep it simple: rebuild below */
    {
        extern uint16_t crc16_modbus(const uint8_t *, uint32_t);
        uint16_t pg[512]; memcpy(pg, mock_page, sizeof pg);
        /* pair 0 = COM_ADDR: set to an illegal value; pair 1 = COM_BAUD: unknown address */
        pg[3 + 1] = 500; pg[3 + 2] = 4242;
        uint32_t used = 3 + 2 * n;
        pg[used] = crc16_modbus((const uint8_t *)pg, used * 2);
        memcpy(mock_page, pg, sizeof pg);
    }
    regs_init();
    CHECK(regs_loaded_from_flash());
    CHECK(reg_get(R_COM_ADDR) == 1);                                    /* illegal 500 ignored */

    /* ---- save failure is reported ---- */
    mock_fail_erase = 1;
    CHECK(regs_save() == 2 && reg_get(R_CMD_RES) == 2);
    mock_fail_erase = 0;


    /* ================= UI (five buttons) ================= */
    memset(mock_page, 0xFF, sizeof mock_page);
    regs_init();
    stub_gpiob.ODR = 0xFFFF; i2c_update();
    ui_regtest_init();
    CHECK(lcd_4bit && lcd_disp_on);
    char t[21];
    run_ms(5);
    /* home screen first: live status (STATE, F, A, V, I, T). ENTER opens the settings list */
    row_text(0, t); printf("H0 [%s]\n", t); CHECK(strncmp(t, "STATE IDLE", 10) == 0);
    row_text(2, t); printf("H2 [%s]\n", t); CHECK(strncmp(t, "V=0.0 I=0.0 T=0.0", 17) == 0);
    tap(B_ENTER);
    row_text(0, t); printf("R0 [%s]\n", t); CHECK(strncmp(t, "#20 COMMAND", 11) == 0);   /* first settable register */
    show_on(); row_text(3, t); printf("R3 [%s]\n", t); CHECK(strncmp(t, "UP/DN nav ENTER edit", 20) == 0);

    /* UP / DOWN walk the settable registers only (status #0..#19 and #21 are skipped) */
    tap(B_UP); row_text(0, t); printf("R0 [%s]\n", t); CHECK(strncmp(t, "#100 COM_ADDR", 13) == 0 && t[19] == 'S');
    tap(B_DOWN); row_text(0, t); CHECK(strncmp(t, "#20 COMMAND", 11) == 0);

    /* MODE: status list (read only), again MODE: back */
    tap(B_MODE); row_text(0, t); printf("R0 [%s]\n", t); CHECK(strncmp(t, "#0 STATE", 8) == 0 && t[19] == 'R');
    tapn(B_UP, 3); row_text(0, t); CHECK(strncmp(t, "#3 FREQ", 7) == 0);
    tap(B_ENTER); show_on(); row_text(3, t); CHECK(strncmp(t, "Read only", 9) == 0);
    run_ms(1600);
    tap(B_MODE); tap(B_ENTER); row_text(0, t); CHECK(strncmp(t, "#20 COMMAND", 11) == 0);   /* MODE -> home, ENTER -> settings */

    /* SHIFT: next group, wraps around */
    tap(B_SHIFT); row_text(0, t); CHECK(strncmp(t, "#100 COM_ADDR", 13) == 0);
    tap(B_SHIFT); row_text(0, t); CHECK(strncmp(t, "#120 F_START", 12) == 0);
    tapn(B_SHIFT, 4); row_text(0, t); printf("R0 [%s]\n", t);
    CHECK(strncmp(t, "#250 SIM_EN", 11) == 0);
    tap(B_SHIFT); row_text(0, t); CHECK(strncmp(t, "#20 COMMAND", 11) == 0);

    /* edit COM_ADDR: 1 -> 42 with UP (step 1) */
    tap(B_UP); row_text(0, t); CHECK(strncmp(t, "#100 COM_ADDR", 13) == 0);
    tap(B_ENTER); show_on(); row_text(3, t); printf("R3 [%s]\n", t); CHECK(strncmp(t, "New=1", 5) == 0);
    row_text(2, t); CHECK(strncmp(t, "Step=1 S=next digit", 19) == 0);
    tapn(B_UP, 41); show_on(); row_text(3, t); printf("R3 [%s]\n", t); CHECK(strncmp(t, "New=42", 6) == 0);
    tap(B_ENTER); show_on(); row_text(3, t); printf("R3 [%s]\n", t); CHECK(strncmp(t, "OK", 2) == 0);
    CHECK(reg_get(R_COM_ADDR) == 42);
    run_ms(1600);

    /* digits: SHIFT selects tens, hundreds; MODE cancels without applying */
    tap(B_ENTER); tap(B_SHIFT); row_text(2, t); CHECK(strncmp(t, "Step=10 S=next digit", 20) == 0);
    tap(B_DOWN); show_on(); row_text(3, t); CHECK(strncmp(t, "New=32", 6) == 0);
    tap(B_SHIFT); row_text(2, t); CHECK(strncmp(t, "Step=100", 8) == 0);
    tap(B_SHIFT); row_text(2, t); CHECK(strncmp(t, "Step=1 ", 7) == 0);            /* 3 digits: wraps to units */
    tap(B_MODE); row_text(0, t); CHECK(strncmp(t, "#100 COM_ADDR", 13) == 0);
    CHECK(reg_get(R_COM_ADDR) == 42);

    /* hundreds: 42 -> 142 -> 242 -> clamped at Max 247 */
    tap(B_ENTER); tap(B_SHIFT); tap(B_SHIFT);
    tap(B_UP); show_on(); row_text(3, t); CHECK(strncmp(t, "New=142", 7) == 0);
    tap(B_UP); show_on(); row_text(3, t); CHECK(strncmp(t, "New=242", 7) == 0);
    tap(B_UP); show_on(); row_text(3, t); printf("R3 [%s]\n", t); CHECK(strncmp(t, "New=247", 7) == 0);
    tap(B_ENTER); run_ms(1600);
    CHECK(reg_get(R_COM_ADDR) == 247);

    /* 247 -> 47 (hundreds down twice is clamped? no: 247 - 100 - 100 = 47) */
    tap(B_ENTER); tap(B_SHIFT); tap(B_SHIFT);
    tapn(B_DOWN, 2); tap(B_ENTER); run_ms(1600);
    CHECK(reg_get(R_COM_ADDR) == 47);

    /* 47 -> below Min 1 is clamped: hundreds down, then units down */
    tap(B_ENTER); tap(B_SHIFT); tap(B_SHIFT);
    tap(B_DOWN); tap(B_ENTER); run_ms(1600);
    CHECK(reg_get(R_COM_ADDR) == 1);
    tap(B_ENTER); tapn(B_UP, 41); tap(B_ENTER); run_ms(1600);
    CHECK(reg_get(R_COM_ADDR) == 42);

    /* baud: UP / DOWN pick standard values only */
    tap(B_UP); row_text(0, t); CHECK(strncmp(t, "#101 COM_BAUD", 13) == 0);
    tap(B_ENTER); row_text(2, t); CHECK(strncmp(t, "U/D = next standard", 19) == 0);
    tap(B_UP); show_on(); row_text(3, t); printf("R3 [%s]\n", t); CHECK(strncmp(t, "New=192", 7) == 0);
    tapn(B_DOWN, 2); show_on(); row_text(3, t); CHECK(strncmp(t, "New=48", 6) == 0);
    tap(B_ENTER); run_ms(1600);
    CHECK(reg_get(R_COM_BAUD) == 48);
    tap(B_ENTER); tap(B_UP); tap(B_ENTER); run_ms(1600);                      /* back to 96 */
    CHECK(reg_get(R_COM_BAUD) == 96);

    /* go to: hold MODE 2 s, UP / DOWN pick, ENTER goes, MODE cancels */
    hold(B_MODE, 2100);
    show_on(); row_text(3, t); printf("R3 [%s]\n", t); CHECK(strncmp(t, "Go to #", 7) == 0);
    tap(B_UP); show_on(); row_text(3, t); CHECK(strncmp(t, "Go to #", 7) == 0);
    tap(B_MODE); show_on(); row_text(3, t); CHECK(strncmp(t, "Go to #", 7) != 0);          /* cancelled */
    hold(B_MODE, 2100);
    { int guard = 0; while (guard++ < 200) { row_text(0, t); if (strncmp(t, "#128 PHASE_TARGET", 17) == 0) break; tap(B_UP); } }
    tap(B_ENTER); row_text(0, t); printf("R0 [%s]\n", t); CHECK(strncmp(t, "#128 PHASE_TARGET", 17) == 0);

    /* signed register: 300 -> -100 */
    tap(B_ENTER); show_on(); row_text(3, t); CHECK(strncmp(t, "New=300", 7) == 0);
    tap(B_SHIFT); tap(B_SHIFT);                                                /* hundreds */
    tapn(B_DOWN, 4); show_on(); row_text(3, t); printf("R3 [%s]\n", t); CHECK(strncmp(t, "New=-100", 8) == 0);
    tap(B_ENTER); run_ms(1600);
    CHECK(reg_val(R_PH_TARGET) == -100);

    /* locked while running: 'Stop inverter 1st' */
    reg_set(R_STATE, ST_RUN);
    hold(B_MODE, 2100);
    { int guard = 0; while (guard++ < 200) { row_text(0, t); if (strncmp(t, "#126 DEADTIME", 13) == 0) break; tap(B_DOWN); } }
    tap(B_ENTER);                                        /* go to DEADTIME */
    tap(B_ENTER); tap(B_UP); tap(B_ENTER); show_on(); row_text(3, t); printf("R3 [%s]\n", t);   /* edit, UP, apply */
    CHECK(strncmp(t, "Stop inverter 1st", 17) == 0);
    tap(B_MODE); run_ms(1600);
    reg_set(R_STATE, ST_IDLE);

    /* save to flash: hold ENTER 2 s in browse mode */
    int e0 = mock_erases;
    hold(B_ENTER, 2100); show_on(); row_text(3, t); printf("R3 [%s]\n", t); CHECK(strncmp(t, "Saved to flash", 14) == 0);
    CHECK(mock_erases == e0 + 1 && mock_page[0] == 0x5AA5);
    run_ms(1600);

    /* a short ENTER (after the long one) starts editing */
    tap(B_ENTER); show_on(); row_text(3, t); CHECK(strncmp(t, "New=", 4) == 0);
    tap(B_MODE);
    run_ms(1600);

    /* status: faults as lists, first fault, inputs (registers 1, 2, 19, 18) */
    tap(B_MODE); row_text(0, t); CHECK(strncmp(t, "#0 STATE", 8) == 0);
    tap(B_UP); row_text(0, t); CHECK(strncmp(t, "#1 FAULT_NOW", 12) == 0);
    reg_set(R_FAULT_NOW, 3); run_ms(100);
    row_text(1, t); CHECK(strncmp(t, "Active faults:", 14) == 0);
    row_text(2, t); printf("faults [%s]\n", t); CHECK(strncmp(t, "F:1 2 ", 6) == 0 && t[5] == ' ');
    show_on(); row_text(3, t); CHECK(strncmp(t, "OC OV ", 6) == 0);
    reg_set(R_FAULT_NOW, 0x8008); run_ms(100);
    row_text(2, t); CHECK(strncmp(t, "F:4 W", 5) == 0);
    show_on(); row_text(3, t); CHECK(strncmp(t, "OT WARN", 7) == 0);
    reg_set(R_FAULT_NOW, 0x80FF); run_ms(100);
    row_text(2, t); CHECK(strncmp(t, "F:1 2 3 4 5 6 7 8 W", 19) == 0);
    reg_set(R_FAULT_NOW, 0); run_ms(100);
    row_text(2, t); CHECK(strncmp(t, "No fault", 8) == 0);
    tap(B_UP); row_text(0, t); CHECK(strncmp(t, "#2 FAULT_LATCH", 14) == 0);
    reg_set(R_FAULT_LATCH, 5); run_ms(100);
    row_text(1, t); CHECK(strncmp(t, "Latched faults:", 15) == 0);
    row_text(2, t); CHECK(strncmp(t, "F:1 3", 5) == 0);
    hold(B_MODE, 2100);                                  /* go to FAULT_FIRST (#19) */
    { int guard = 0; while (guard++ < 200) { row_text(0, t); if (strncmp(t, "#19 FAULT_FIRST", 15) == 0) break; tap(B_UP); } }
    tap(B_ENTER); row_text(1, t); printf("R1 [%s]\n", t); CHECK(strncmp(t, "First fault:", 12) == 0);
    reg_set(R_FAULT_FIRST, 2); run_ms(100);
    row_text(2, t); CHECK(strncmp(t, "F:2", 3) == 0);
    hold(B_MODE, 2100);                                  /* go to INPUTS (#18) */
    tap(B_DOWN); tap(B_ENTER); row_text(0, t); CHECK(strncmp(t, "#18 INPUTS", 10) == 0);
    row_text(1, t); CHECK(strncmp(t, "Inputs 1=active:", 16) == 0);
    row_text(2, t); CHECK(strncmp(t, "St0 Sp0 Fl0 Es0 Hw0", 19) == 0);
    reg_set(R_IO_IN, 0x0A); run_ms(100);
    row_text(2, t); CHECK(strncmp(t, "St0 Sp1 Fl0 Es1 Hw0", 19) == 0);

    /* auto repeat of UP follows the registers: delay 500 ms, first period 200 ms, then it speeds up */
    tap(B_MODE); tap(B_MODE);
    reg_write(241, 1); reg_write(242, 200); reg_write(243, 500);
    run_ms(20);
    { int moves = 0; char prev[21], cur[21];
      tap(B_SHIFT); row_text(0, prev);
      sim_key_down[B_UP] = 1;
      for (int i = 0; i < 200; i++) { run_ms(10); row_text(0, cur); if (strcmp(cur, prev)) { moves++; memcpy(prev, cur, 21); } }
      sim_key_down[B_UP] = 0; run_ms(60);
      printf("moves with repeat 500/200 ms over 2 s (accelerating): %d\n", moves);
      CHECK(moves >= 10 && moves <= 18); }
    reg_write(241, 0);                                   /* repeat off: one step per press */
    run_ms(1600);
    { int moves = 0; char prev[21], cur[21]; row_text(0, prev);
      sim_key_down[B_UP] = 1;
      for (int i = 0; i < 300; i++) { run_ms(10); row_text(0, cur); if (strcmp(cur, prev)) { moves++; memcpy(prev, cur, 21); } }
      sim_key_down[B_UP] = 0; run_ms(60);
      CHECK(moves == 1); }
    reg_write(241, 1); reg_write(242, 300); reg_write(243, 800);

    /* edit: holding UP for more than 1 s moves the cursor to the next digit every second */
    hold(B_MODE, 2100);
    { int guard = 0; char tt[21]; while (guard++ < 200) { row_text(0, tt); if (strncmp(tt, "#100 COM_ADDR", 13) == 0) break; tap(B_UP); } }
    tap(B_ENTER); tap(B_ENTER);                       /* goto, then edit */
    { char s2[21]; row_text(2, s2); CHECK(strncmp(s2, "Step=1 ", 7) == 0);
      sim_key_down[B_UP] = 1; run_ms(3200); sim_key_down[B_UP] = 0; run_ms(60);
      row_text(2, s2); printf("after 3.2 s hold: [%s]\n", s2);
      CHECK(strncmp(s2, "Step=100", 8) == 0 || strncmp(s2, "Step=1000", 9) == 0);
      tap(B_MODE); }

    /* help line alternates through its four texts (from the first settings register: MODE twice) */
    tap(B_MODE); tap(B_MODE); row_text(0, t); if (strncmp(t, "STATE", 5) == 0) tap(B_ENTER);   /* home -> settings */
    run_ms(1600);
    { int a1 = 0, a2 = 0, a3 = 0, a4 = 0;
      for (int i = 0; i < 140; i++) { run_ms(100); char h[21];
          row_text(3, h);
          if (strncmp(h, "UP/DN nav ENTER edit", 20) == 0) a1 = 1;
          if (strncmp(h, "MODE stat SHIFT grp", 19) == 0) a2 = 1;
          if (strncmp(h, "hold MODE: goto", 15) == 0) a3 = 1;
          if (strncmp(h, "hold ENTER: save", 16) == 0) a4 = 1; }
      CHECK(a1 && a2 && a3 && a4); }

    CHECK(lcd_bad == 0);
    printf(fails ? "\n%d FAILED\n" : "\nALL OK (lcd violations %d)\n", fails ? fails : lcd_bad);
    return fails != 0;
}
