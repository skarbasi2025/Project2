"""Checks tools/mbtool.py framing (CRC, requests, reply parsing) against the real firmware protocol code."""
import ctypes, os, sys
here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(here, "..", "tools"))
import mbtool

lib = ctypes.CDLL(sys.argv[1] if len(sys.argv) > 1 else "/tmp/libsim.so")
lib.sim_init()
regs = mbtool.load_registers()
assert len(regs) >= 50, len(regs)

def talk(req):
    buf = ctypes.create_string_buffer(300)
    n = lib.sim_handle(req, len(req), buf, 1)
    return bytes(buf.raw[:n])

fails = 0
def check(c, msg):
    global fails
    if not c:
        print("FAIL", msg); fails += 1

# every register, one at a time, through the tool's own builder/parser
for r in regs:
    v = mbtool.parse_response(talk(mbtool.build_read(1, r["addr"], 1)), 1, 3, 1)[0]
    check(v == (r["default"] & 0xFFFF) or r["cmd"], "read " + r["name"])

# the 12 status registers as one block; FW_VER = 100
vals = mbtool.parse_response(talk(mbtool.build_read(1, 0, 12, fn=4)), 1, 4, 12)
check(vals[11] == 100, "FW_VER")

# write / read back a signed register
reg = next(r for r in regs if r["name"] == "PHASE_TARGET")
mbtool.parse_response(talk(mbtool.build_write(1, reg["addr"], -120)), 1, 6)
v = mbtool.parse_response(talk(mbtool.build_read(1, reg["addr"], 1)), 1, 3, 1)[0]
check(mbtool.signed(v, reg) == -120, "signed round trip")

# errors are reported as exceptions
for bad, text in [((100, 0), "data value"), ((3, 1), "address"), ((101, 100), "data value")]:
    try:
        mbtool.parse_response(talk(mbtool.build_write(1, *bad)), 1, 6)
        check(False, "expected exception for %r" % (bad,))
    except mbtool.ModbusError as e:
        check(text in str(e), "message %s for %r" % (e, bad))

# write multiple: baud 9600, parity even, stop 2
mbtool.parse_response(talk(mbtool.build_write_multi(1, 101, [96, 1, 2])), 1, 16)
vals = mbtool.parse_response(talk(mbtool.build_read(1, 101, 3)), 1, 3, 3)
check(vals == [96, 1, 2], "write multiple")

# CRC error in a reply is detected by the parser
rep = bytearray(talk(mbtool.build_read(1, 100, 1))); rep[-1] ^= 0xFF
try:
    mbtool.parse_response(bytes(rep), 1, 3, 1); check(False, "bad crc accepted")
except mbtool.ModbusError:
    pass

print("%d FAILED" % fails if fails else "ALL OK (mbtool)")
sys.exit(1 if fails else 0)
