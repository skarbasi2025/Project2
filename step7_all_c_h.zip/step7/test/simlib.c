/* shared library for test_mbtool.py: the real protocol layer + register table with a mock flash page */
#include <string.h>
#include "modbus.h"
#include "regs.h"
#include "flash_store.h"
static uint16_t mock_page[512];
const uint16_t *flash_hw_page(void) { return mock_page; }
int flash_hw_erase_page(void) { memset(mock_page, 0xFF, sizeof mock_page); return 0; }
int flash_hw_prog16(uint32_t o, uint16_t v) { mock_page[o / 2] = v; return 0; }
void sim_init(void) { memset(mock_page, 0xFF, sizeof mock_page); regs_init(); }
int sim_handle(const uint8_t *req, int len, uint8_t *resp, int addr)
{ mb_result_t r; return modbus_handle(req, len, resp, (uint8_t)addr, &r); }
int sim_reg(int idx) { return (int)reg_get(idx); }
