/* test_ao.c - analog output mapping (host). Build: gcc -Iinc test/test_ao.c src/ao_map.c -o t && ./t */
#include <stdio.h>
#include <string.h>
#include "ao_map.h"

static int fails;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

int main(void)
{
    ao_in_t in;
    memset(&in, 0, sizeof in);
    in.v_fs = 500; in.i_fs = 500; in.t_max = 700; in.f_min = 28000; in.f_max = 50000;

    in.amplitude = 500;                                   /* 50.0 % -> 5 V */
    CHECK(ao_permille(AO_SRC_AMPL, &in) == 500);
    in.amplitude = 1200;                                  /* above full scale is clamped */
    CHECK(ao_permille(AO_SRC_AMPL, &in) == 1000);

    in.freq = 28000; CHECK(ao_permille(AO_SRC_FREQ, &in) == 0);
    in.freq = 39000; CHECK(ao_permille(AO_SRC_FREQ, &in) == 500);   /* middle of 28000..50000 */
    in.freq = 50000; CHECK(ao_permille(AO_SRC_FREQ, &in) == 1000);
    in.freq = 20000; CHECK(ao_permille(AO_SRC_FREQ, &in) == 0);     /* below min: 0 V */

    in.vbus = 250; CHECK(ao_permille(AO_SRC_VBUS, &in) == 500);     /* 25.0 V of 50.0 V full scale */
    in.ibus = 500; CHECK(ao_permille(AO_SRC_IBUS, &in) == 1000);
    in.temp = 350; CHECK(ao_permille(AO_SRC_TEMP, &in) == 500);     /* 35 C of 70 C */
    in.temp = -50; CHECK(ao_permille(AO_SRC_TEMP, &in) == 0);       /* below 0 C: 0 V */

    CHECK(ao_permille(AO_SRC_OFF, &in) == 0);
    CHECK(ao_permille(99, &in) == 0);

    printf(fails ? "\n%d FAILED\n" : "ALL OK (ao)\n", fails);
    return fails != 0;
}
