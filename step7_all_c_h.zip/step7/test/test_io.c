/* Host test of the real io.c on simulated GPIO registers: which pin is which input, pull direction and INPUT_POL.
 * The pin model: an external driver (0, 1) or none (floating); a floating pin with an internal pull follows the pull. */
#include <stdio.h>
#include <string.h>
#include "stm32f1xx.h"
#include "board.h"
#include "delay.h"
#include "io.h"

GPIO_TypeDef stub_gpioa, stub_gpiob, stub_gpioc;
AFIO_TypeDef stub_afio;
RCC_TypeDef  stub_rcc;
uint32_t millis(void) { return 0; }
void delay_init(void) {}
void delay_us(uint32_t u) { (void)u; }
void delay_ms(uint32_t m) { (void)m; }

static int ext[3][16];                                   /* -1 floating, 0, 1 */
static GPIO_TypeDef *port[3] = { &stub_gpioa, &stub_gpiob, &stub_gpioc };
static int fails;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

void mock_bsrr(GPIO_TypeDef *g, uint32_t v) { g->ODR |= (v & 0xFFFFu); g->ODR &= ~(v >> 16); }

static unsigned cfg_of(GPIO_TypeDef *g, int pin)
{
    uint32_t r = (pin < 8) ? g->CRL : g->CRH;
    return (r >> ((pin & 7) * 4)) & 0xFu;
}
static void settle(void)
{
    for (int p = 0; p < 3; p++)
        for (int b = 0; b < 16; b++) {
            GPIO_TypeDef *g = port[p];
            int v;
            if (ext[p][b] >= 0) v = ext[p][b];
            else if (cfg_of(g, b) == 8) v = (g->ODR >> b) & 1;       /* pulled by the ODR bit */
            else v = 0;
            if (v) g->IDR |= (1u << b); else g->IDR &= ~(1u << b);
        }
}
#define PA 0
#define PB 1
#define PC 2
static void drive(int p, int b, int v) { ext[p][b] = v; settle(); }
static void reset(void) { memset(ext, 0xFF, sizeof ext); memset(&stub_gpioa, 0, sizeof stub_gpioa); memset(&stub_gpiob, 0, sizeof stub_gpiob); memset(&stub_gpioc, 0, sizeof stub_gpioc); }

int main(void)
{
    reset();
    io_init(); settle();
    /* default: active high, pull-down: open switch reads inactive */
    CHECK(!io_start_button() && !io_stop_button() && !io_flow_fault() && !io_estop() && !io_hw_fault());
    drive(PB, 8, 1);  CHECK(io_start_button() && !io_stop_button());       /* START = PB8 */
    drive(PB, 8, -1); CHECK(!io_start_button());
    drive(PB, 2, 1);  CHECK(io_stop_button() && !io_start_button());       /* STOP = PB2 */
    drive(PB, 2, -1);
    drive(PC, 13, 1); CHECK(io_flow_fault() && !io_estop());               /* flow = PC13 */
    drive(PC, 13, -1);
    drive(PC, 14, 1); CHECK(io_estop() && !io_flow_fault());               /* E-stop = PC14 */
    drive(PC, 14, -1);
    drive(PB, 12, 1); CHECK(io_hw_fault()); drive(PB, 12, -1); CHECK(!io_hw_fault());
    drive(PB, 0, 1);  CHECK(io_hw_fault()); drive(PB, 0, -1);
    CHECK(cfg_of(&stub_gpiob, 8) == 8 && cfg_of(&stub_gpiob, 2) == 8);     /* inputs with pull */

    /* button wired to GND: INPUT_POL bit0 (START) and bit1 (STOP) = active low, pull-up */
    io_set_polarity(3); settle();
    CHECK(!io_start_button() && !io_stop_button());                        /* idle: pulled high = inactive */
    drive(PB, 8, 0);  CHECK(io_start_button() && !io_stop_button());
    drive(PB, 8, -1);
    drive(PB, 2, 0);  CHECK(io_stop_button() && !io_start_button());
    drive(PB, 2, -1);
    CHECK(!io_flow_fault() && !io_estop());                                /* the other inputs keep their polarity */
    /* NC contacts for flow and E-stop: active low (open contact + pull-up would be a fault, so a closed NC to GND = healthy) */
    io_set_polarity(0x0C); settle();
    CHECK(!io_flow_fault() && !io_estop());
    drive(PC, 13, 0); CHECK(io_flow_fault()); drive(PC, 13, -1);
    drive(PC, 14, 0); CHECK(io_estop()); drive(PC, 14, -1);
    drive(PB, 8, 1);  CHECK(io_start_button()); drive(PB, 8, -1);           /* START back to active high */
    io_set_polarity(0); settle();

    /* the latch clear line: idle released (high), low pulse clears, open drain */
    CHECK(((stub_gpiob.ODR >> 1) & 1u) == 1u && cfg_of(&stub_gpiob, 1) == 6);
    reset(); io_init();
    CHECK(cfg_of(&stub_gpiob, 4) == 2 && cfg_of(&stub_gpioa, 15) == 2);   /* both LEDs: push-pull output */
    io_led_fault(1); CHECK(((stub_gpiob.ODR >> 4) & 1u) == 1u && ((stub_gpioa.ODR >> 15) & 1u) == 0u);
    io_led_fault(0); CHECK(((stub_gpiob.ODR >> 4) & 1u) == 0u);
    io_led_run(1);   CHECK(((stub_gpioa.ODR >> 15) & 1u) == 1u && ((stub_gpiob.ODR >> 4) & 1u) == 0u);
    printf(fails ? "\n%d FAILED\n" : "\nALL OK (io)\n", fails);
    return fails != 0;
}
