/* Host test of the Modbus RTU protocol layer (modbus_pdu.c) against the real register table. */
#include <stdio.h>
#include <string.h>
#include "modbus.h"
#include "regs.h"
#include "crc16.h"
#include "flash_store.h"

static uint16_t mock_page[512];
const uint16_t *flash_hw_page(void) { return mock_page; }
int flash_hw_erase_page(void) { memset(mock_page, 0xFF, sizeof mock_page); return 0; }
int flash_hw_prog16(uint32_t o, uint16_t v) { mock_page[o / 2] = v; return 0; }

static int fails;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

static int build(uint8_t *f, uint8_t addr, uint8_t fn, const uint8_t *data, int n)
{
    f[0] = addr; f[1] = fn;
    memcpy(&f[2], data, (size_t)n);
    uint16_t c = crc16_modbus(f, (uint32_t)(2 + n));
    f[2 + n] = c & 0xFF; f[3 + n] = c >> 8;
    return 4 + n;
}
static uint8_t rq[300], rs[300];
static int ask(uint8_t addr, uint8_t fn, const uint8_t *d, int n, mb_result_t *res)
{
    int len = build(rq, addr, fn, d, n);
    return modbus_handle(rq, len, rs, 1, res);
}
static int crc_ok(const uint8_t *f, int n) { return crc16_modbus(f, (uint32_t)n) == 0; }

int main(void)
{
    mb_result_t res;
    memset(mock_page, 0xFF, sizeof mock_page);
    regs_init();

    /* known frame: read 1 register at 100 (COM_ADDR=1), slave 1: 01 03 00 64 00 01 + CRC */
    { uint8_t d[] = {0x00, 0x64, 0x00, 0x01};
      int n = ask(1, 3, d, 4, &res);
      CHECK(res == MB_OK && n == 7 && rs[0] == 1 && rs[1] == 3 && rs[2] == 2 && rs[3] == 0 && rs[4] == 1 && crc_ok(rs, n)); }

    /* reference CRC of a classic request 01 03 00 00 00 0A -> C5 CD */
    { uint8_t f[] = {0x01, 0x03, 0x00, 0x00, 0x00, 0x0A};
      uint16_t c = crc16_modbus(f, 6); CHECK(c == 0xCDC5); }

    /* read the 12 status registers 0..11 */
    { uint8_t d[] = {0x00, 0x00, 0x00, 0x0C};
      int n = ask(1, 4, d, 4, &res);
      CHECK(res == MB_OK && n == 3 + 24 + 2 && rs[2] == 24 && crc_ok(rs, n));
      CHECK(rs[3 + 22] == 0 && rs[3 + 23] == 100); }                        /* FW_VER = 100 */

    /* address gap in a read -> exception 02 */
    { uint8_t d[] = {0x00, 0x18, 0x00, 0x04};                              /* 24..27: none of them exists */
      int n = ask(1, 3, d, 4, &res);
      CHECK(res == MB_EXCEPTION && n == 5 && rs[1] == 0x83 && rs[2] == 0x02 && crc_ok(rs, n)); }

    /* bad quantity -> 03 */
    { uint8_t d[] = {0x00, 0x00, 0x00, 0x00};
      int n = ask(1, 3, d, 4, &res); CHECK(res == MB_EXCEPTION && rs[2] == 0x03 && n == 5); }
    { uint8_t d[] = {0x00, 0x00, 0x00, 0x7E};
      int n = ask(1, 3, d, 4, &res); CHECK(res == MB_EXCEPTION && rs[2] == 0x03 && n == 5); }

    /* write single COM_ADDR=7: echo; value changes */
    { uint8_t d[] = {0x00, 0x64, 0x00, 0x07};
      int n = ask(1, 6, d, 4, &res);
      CHECK(res == MB_OK && n == 8 && memcmp(rs, rq, 8) == 0);
      CHECK(reg_get(R_COM_ADDR) == 7);
      CHECK(regs_comm_changed_take()); }
    CHECK(reg_get(R_COM_ADDR) == 7);
    { uint8_t d[] = {0x00, 0x64, 0x00, 0x01};
      int len = build(rq, 7, 6, d, 4);
      int n = modbus_handle(rq, len, rs, 7, &res); CHECK(res == MB_OK && n == 8 && reg_get(R_COM_ADDR) == 1); }

    /* frame for another slave: ignored, no reply */
    { uint8_t d[] = {0x00, 0x00, 0x00, 0x01};
      int n = ask(5, 3, d, 4, &res); CHECK(n == 0 && res == MB_IGNORED); }

    /* bad CRC */
    { uint8_t d[] = {0x00, 0x00, 0x00, 0x01};
      int len = build(rq, 1, 3, d, 4); rq[len - 1] ^= 1;
      int n = modbus_handle(rq, len, rs, 1, &res); CHECK(n == 0 && res == MB_CRC_ERR); }
    { int n = modbus_handle(rq, 2, rs, 1, &res); CHECK(n == 0 && res == MB_CRC_ERR); }

    /* write errors: out of range 03, read only 02, unknown address 02, busy 06 */
    { uint8_t d[] = {0x00, 0x64, 0x00, 0x00};
      int n = ask(1, 6, d, 4, &res); CHECK(res == MB_EXCEPTION && n == 5 && rs[1] == 0x86 && rs[2] == 0x03); }
    { uint8_t d[] = {0x00, 0x03, 0x00, 0x01};
      int n = ask(1, 6, d, 4, &res); CHECK(rs[1] == 0x86 && rs[2] == 0x02 && n == 5); }
    { uint8_t d[] = {0x03, 0xE7, 0x00, 0x01};
      int n = ask(1, 6, d, 4, &res); CHECK(rs[1] == 0x86 && rs[2] == 0x02 && n == 5); }
    reg_set(R_STATE, ST_RUN);
    { uint8_t d[] = {0x00, 0x7E, 0x01, 0x2C};                              /* DEADTIME = 300 while running */
      int n = ask(1, 6, d, 4, &res); CHECK(rs[1] == 0x86 && rs[2] == 0x06 && n == 5); }
    reg_set(R_STATE, ST_IDLE);

    /* baud rate: standard values only, also over RS-485 */
    { uint8_t d[] = {0x00, 0x65, 0x00, 0x64};                              /* 10000 baud */
      int n = ask(1, 6, d, 4, &res); CHECK(rs[2] == 0x03 && n == 5); }
    { uint8_t d[] = {0x00, 0x65, 0x04, 0x80};                              /* 1152 = 115200 */
      int n = ask(1, 6, d, 4, &res); CHECK(res == MB_OK && n == 8 && reg_get(R_COM_BAUD) == 1152); }

    /* write multiple: baud, parity, stop (101..103) in one frame */
    { uint8_t d[] = {0x00, 0x65, 0x00, 0x03, 0x06, 0x00, 0x60, 0x00, 0x01, 0x00, 0x02};
      int n = ask(1, 16, d, 11, &res);
      CHECK(res == MB_OK && n == 8 && rs[1] == 16 && rs[5] == 3 && crc_ok(rs, n));
      CHECK(reg_get(R_COM_BAUD) == 96 && reg_get(R_COM_PARITY) == 1 && reg_get(R_COM_STOP) == 2); }
    /* wrong byte count */
    { uint8_t d[] = {0x00, 0x65, 0x00, 0x02, 0x03, 0x00, 0x60, 0x00, 0x01};
      int n = ask(1, 16, d, 9, &res); CHECK(rs[1] == 0x90 && rs[2] == 0x03 && n == 5); }
    /* second value out of range: first stays written, exception 03 */
    { uint8_t d[] = {0x00, 0x65, 0x00, 0x02, 0x04, 0x00, 0x30, 0x00, 0x09};
      int n = ask(1, 16, d, 9, &res);
      CHECK(rs[1] == 0x90 && rs[2] == 0x03 && n == 5 && reg_get(R_COM_BAUD) == 48 && reg_get(R_COM_PARITY) == 1); }

    /* 7 data bits need parity: 7 with parity 1 is fine, parity 0 with 7 data bits is refused */
    { uint8_t d[] = {0x00, 0x68, 0x00, 0x07};
      int n = ask(1, 6, d, 4, &res); CHECK(res == MB_OK && n == 8 && reg_get(R_COM_DATA) == 7); }
    { uint8_t d[] = {0x00, 0x66, 0x00, 0x00};
      int n = ask(1, 6, d, 4, &res); CHECK(rs[2] == 0x03 && n == 5 && reg_get(R_COM_PARITY) == 1); }
    { uint8_t d[] = {0x00, 0x68, 0x00, 0x08};
      ask(1, 6, d, 4, &res); CHECK(res == MB_OK); }

    /* command register: reads 0, a write is queued */
    { uint8_t d[] = {0x00, 0x14, 0x00, 0x01};
      int n = ask(1, 6, d, 4, &res); CHECK(res == MB_OK && n == 8); CHECK(regs_cmd_take() == CMD_START); }
    { uint8_t d[] = {0x00, 0x14, 0x00, 0x01};
      int n = ask(1, 3, d, 4, &res); CHECK(rs[3] == 0 && rs[4] == 0 && n == 7); }

    /* unknown function -> 01 */
    { uint8_t d[] = {0x00, 0x00};
      int n = ask(1, 0x2B, d, 2, &res); CHECK(res == MB_EXCEPTION && rs[1] == 0xAB && rs[2] == 0x01 && n == 5); }

    /* broadcast: executes writes, never answers */
    { uint8_t d[] = {0x00, 0x7C, 0x00, 0x64};                              /* P_SET (124) = 100 */
      int len = build(rq, 0, 6, d, 4);
      int n = modbus_handle(rq, len, rs, 1, &res);
      CHECK(n == 0 && res == MB_OK && reg_get(R_P_SET) == 100); }
    { uint8_t d[] = {0x00, 0x00, 0x00, 0x01};
      int len = build(rq, 0, 3, d, 4); int n = modbus_handle(rq, len, rs, 1, &res); CHECK(n == 0); }

    /* every register in the table can be read one by one */
    for (int i = 0; i < REG_COUNT; i++) {
        uint8_t d[] = { (uint8_t)(reg_table[i].addr >> 8), (uint8_t)reg_table[i].addr, 0, 1 };
        int n = ask(1, 3, d, 4, &res);
        CHECK(res == MB_OK && n == 7);
    }
    /* the groups can be read as blocks */
    { uint8_t d[] = {0x00, 0x78, 0x00, 0x0E};                               /* 120..133 */
      int n = ask(1, 3, d, 4, &res); CHECK(res == MB_OK && n == 3 + 28 + 2); }
    { uint8_t d[] = {0x00, 0xC8, 0x00, 0x07};                               /* 200..206 */
      int n = ask(1, 3, d, 4, &res); CHECK(res == MB_OK && n == 3 + 14 + 2); }
    { uint8_t d[] = {0x00, 0x64, 0x00, 0x07};                               /* 100..106 */
      int n = ask(1, 3, d, 4, &res); CHECK(res == MB_OK && n == 3 + 14 + 2); }

    printf(fails ? "\n%d FAILED\n" : "\nALL OK (modbus)\n", fails);
    return fails != 0;
}
