/* host-test stand-in for the CMSIS device header (only what the HMI code uses) */
#ifndef STUB_STM32F1XX_H
#define STUB_STM32F1XX_H
#include <stdint.h>
typedef struct { volatile uint32_t CRL, CRH, IDR, ODR, BSRR, BRR, LCKR; } GPIO_TypeDef;
typedef struct { volatile uint32_t APB2ENR; } RCC_TypeDef;
typedef struct { volatile uint32_t MAPR; } AFIO_TypeDef;
extern GPIO_TypeDef stub_gpioa, stub_gpiob, stub_gpioc;
extern RCC_TypeDef  stub_rcc;
extern AFIO_TypeDef stub_afio;
#define GPIOA (&stub_gpioa)
#define GPIOB (&stub_gpiob)
#define GPIOC (&stub_gpioc)
#define RCC   (&stub_rcc)
#define AFIO  (&stub_afio)
#define RCC_APB2ENR_IOPAEN (1u << 2)
#define RCC_APB2ENR_IOPBEN (1u << 3)
#define RCC_APB2ENR_IOPCEN (1u << 4)
#endif
