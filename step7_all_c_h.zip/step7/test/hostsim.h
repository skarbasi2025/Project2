/* Host simulation (shared by the tests): a model of the HD44780 (4-bit) and of the key matrix is connected to the
 * simulated GPIO registers, then the real lcd.c / keypad.c / ui_keytest.c are run. */
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include "stm32f1xx.h"
#include "board.h"
#include "delay.h"
#include "lcd.h"
#include "keypad.h"

GPIO_TypeDef stub_gpioa, stub_gpiob, stub_gpioc;
AFIO_TypeDef stub_afio;
RCC_TypeDef  stub_rcc;

/* ---------- simulated time ---------- */
static uint32_t sim_us;
uint32_t millis(void) { return sim_us / 1000u; }
void delay_init(void) {}

/* ---------- HD44780 model (4-bit) behind a PCF8574 I2C slave model ---------- */
static int  lcd_4bit, lcd_have_hi, lcd_inc = 1, lcd_disp_on, lcd_bad;
static uint8_t lcd_hi;
static char ddram[128];
static int  lcd_addr;
static uint32_t last_cmd_us;
static int  last_cmd_busy_us;
static int  lcd_rows_wide = 0;

static void lcd_exec(int rs, uint8_t v)
{
    if ((int32_t)(sim_us - last_cmd_us) < last_cmd_busy_us) lcd_bad++;
    last_cmd_us = sim_us;
    last_cmd_busy_us = 37;
    if (rs) { ddram[lcd_addr & 0x7F] = (char)v; lcd_addr += lcd_inc; return; }
    if (v == 0x01) { memset(ddram, ' ', sizeof ddram); lcd_addr = 0; last_cmd_busy_us = 1520; }
    else if (v & 0x80) lcd_addr = v & 0x7F;
    else if ((v & 0xFC) == 0x04) lcd_inc = (v & 2) ? 1 : -1;
    else if ((v & 0xF8) == 0x08) lcd_disp_on = (v >> 2) & 1;
    else if ((v & 0xE0) == 0x20) { (void)lcd_rows_wide; }
}

static uint8_t pcf_state;
static int backlight_on;
static void pcf_write(uint8_t v)
{
    int e_old = (pcf_state & PCF_E) != 0, e_new = (v & PCF_E) != 0;
    pcf_state = v;
    backlight_on = (v & PCF_BL) != 0;
    if (v & PCF_RW) lcd_bad++;                      /* the driver never reads */
    if (e_old && !e_new) {                          /* E fell: latch */
        int rs = (v & PCF_RS) != 0;
        uint8_t n = v >> 4;
        if (!lcd_4bit) { if (rs) { lcd_bad++; return; } if (n == 0x2) lcd_4bit = 1; return; }
        if (!lcd_have_hi) { lcd_hi = n; lcd_have_hi = 1; }
        else { lcd_have_hi = 0; lcd_exec(rs, (uint8_t)(lcd_hi << 4 | n)); }
    }
}

/* I2C slave: watches PB6 (SCL) and PB7 (SDA), open-drain wired-AND */
static int i2c_scl_prev = 1, i2c_sda_prev = 1, i2c_pull, i2c_bits, i2c_acking, i2c_in_xfer, i2c_first, i2c_addr_ok;
static uint8_t i2c_sh;
static int i2c_acks, i2c_naks;

static int sda_level(void) { return ((stub_gpiob.ODR >> I2C_SDA_PIN) & 1) && !i2c_pull; }

static void i2c_update(void)
{
    int scl = (stub_gpiob.ODR >> I2C_SCL_PIN) & 1;
    int sda = sda_level();
    if (scl && i2c_scl_prev) {
        if (i2c_sda_prev && !sda) { i2c_in_xfer = 1; i2c_first = 1; i2c_bits = 0; i2c_acking = 0; }   /* START */
        if (!i2c_sda_prev && sda) { i2c_in_xfer = 0; }                                                 /* STOP  */
    }
    if (scl && !i2c_scl_prev && i2c_in_xfer && i2c_bits < 8 && !i2c_acking) {          /* rising: sample */
        i2c_sh = (uint8_t)(i2c_sh << 1 | sda);
        i2c_bits++;
    }
    if (!scl && i2c_scl_prev && i2c_in_xfer) {                                          /* falling */
        if (i2c_acking) { i2c_pull = 0; i2c_acking = 0; i2c_bits = 0; }
        else if (i2c_bits == 8) {
            if (i2c_first) { i2c_addr_ok = (i2c_sh == (uint8_t)(LCD_I2C_ADDR << 1)); i2c_first = 0; }
            else if (i2c_addr_ok) pcf_write(i2c_sh);
            if (i2c_addr_ok) { i2c_pull = 1; i2c_acks++; } else i2c_naks++;
            i2c_acking = 1;
        }
    }
    i2c_scl_prev = scl;
    i2c_sda_prev = sda_level();
}

/* ---------- five buttons (active high): a pressed button drives its pin high, released it is low ---------- */
/* index order as in keypad.c: 0 UP, 1 DOWN, 2 ENTER, 3 MODE, 4 SHIFT */
static int sim_key_down[5];
static const pin_t kpins[5] = KEY_PINS_INIT;
static void update_idr(void)
{
    stub_gpioa.IDR = 0xFFFFFFFFu;
    stub_gpiob.IDR = 0xFFFFFFFFu;
    stub_gpioc.IDR = 0xFFFFFFFFu;
    if (!sda_level()) stub_gpiob.IDR &= ~(1u << I2C_SDA_PIN);
    for (int i = 0; i < 5; i++) {
        uint32_t bit = 1u << kpins[i].pin;
        if (sim_key_down[i]) kpins[i].port->IDR |= bit;
        else kpins[i].port->IDR &= ~bit;
    }
}

void mock_bsrr(GPIO_TypeDef *g, uint32_t v)
{
    g->ODR |= (v & 0xFFFFu);
    g->ODR &= ~(v >> 16);
    if (g == &stub_gpiob) i2c_update();
    update_idr();
}

void delay_us(uint32_t us) { sim_us += us; update_idr(); }
void delay_ms(uint32_t ms) { while (ms--) delay_us(1000); }

