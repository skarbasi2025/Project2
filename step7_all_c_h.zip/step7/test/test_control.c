/* Host test of control.c (state machine, protections, commands, sources) with the real register table
 * and the real Modbus protocol layer. Inputs and time are simulated. */
#include <stdio.h>
#include <string.h>
#include "control.h"
#include "regs.h"
#include "modbus.h"
#include "crc16.h"
#include "io.h"
#include "delay.h"
#include "flash_store.h"

static uint16_t mock_page[512];
const uint16_t *flash_hw_page(void) { return mock_page; }
int flash_hw_erase_page(void) { memset(mock_page, 0xFF, sizeof mock_page); return 0; }
int flash_hw_prog16(uint32_t o, uint16_t v) { mock_page[o / 2] = v; return 0; }

static uint32_t now;
uint32_t millis(void) { return now; }
void delay_us(uint32_t u) { (void)u; }
void delay_ms(uint32_t m) { now += m; }
void delay_init(void) {}

static int in_flow, in_estop, in_hw, in_btn, in_stop, latch_clears, led_run, led_fault;
static unsigned pol_applied, pol_calls;
void io_init(void) {}
void io_set_polarity(unsigned m) { pol_applied = m; pol_calls++; }
int io_flow_fault(void) { return in_flow; }
int io_estop(void) { return in_estop; }
int io_hw_fault(void) { return in_hw; }
int io_start_button(void) { return in_btn; }
int io_stop_button(void) { return in_stop; }
void io_latch_clear(void) { latch_clears++; in_hw = 0; }          /* the latch really clears */
void io_led_run(int on) { led_run = on; }
void io_led_fault(int on) { led_fault = on; }

static int fails;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
static void run(uint32_t ms) { while (ms--) { now++; control_step(); } }
static void cmd(int c) { reg_write(20, (uint16_t)c); }
static int state(void) { return (int)reg_get(R_STATE); }
static void reset_all(void)
{
    memset(mock_page, 0xFF, sizeof mock_page);
    regs_init();
    in_flow = in_estop = in_hw = in_btn = in_stop = 0;
    control_init();
    reg_write(R_SIM_EN + 250 - R_SIM_EN, 0);
}
static void sim_on(int v, int i, int t)
{
    reg_write(250, 1); reg_write(251, (uint16_t)v); reg_write(252, (uint16_t)i); reg_write(253, (uint16_t)t);
}

int main(void)
{
    /* ---- boot: no measurements (V_BUS = 0 = undervoltage) -> not ready ---- */
    reset_all();
    run(50);
    CHECK(state() == ST_IDLE);
    CHECK(reg_get(R_FAULT_NOW) & F_UNDERVOLT);
    cmd(CMD_START); run(20);
    CHECK(state() == ST_IDLE && reg_get(R_CMD_RES) == RES_NOT_READY);

    /* ---- simulated measurements: ready, start, sweep, run, ramp ---- */
    sim_on(240, 0, 250);
    run(20);
    CHECK(state() == ST_READY && reg_get(R_V_BUS) == 240);
    cmd(CMD_START); run(10);
    CHECK(state() == ST_START && reg_get(R_CMD_RES) == RES_OK && reg_get(R_FREQ) <= 40000 && reg_get(R_FREQ) >= 39000);
    run(500);
    CHECK(state() == ST_START && reg_get(R_FREQ) < 36000 && reg_get(R_FREQ) > 34000);     /* halfway 40000 -> 31000 */
    run(600);
    CHECK(state() == ST_RUN && reg_get(R_FREQ) == 31000 && reg_get(R_AMPLITUDE) < 20);
    run(1000);
    CHECK(reg_get(R_AMPLITUDE) > 90 && reg_get(R_AMPLITUDE) < 115);                      /* 0.1 %/s -> 100 after 1 s */
    run(1500);
    CHECK(reg_get(R_AMPLITUDE) == 200 && reg_get(R_POWER_OUT) == 200);
    CHECK(led_run && !led_fault);

    /* power setpoint changes live; ramps down too */
    reg_write(124, 500); run(3500);
    CHECK(reg_get(R_AMPLITUDE) == 500);
    reg_write(124, 100); run(5000);
    CHECK(reg_get(R_AMPLITUDE) == 100);

    /* settings locked while running, flash save refused */
    CHECK(reg_write(126, 300) == REG_ERR_BUSY);
    CHECK(regs_save() == 1);

    /* ---- stop ---- */
    cmd(CMD_STOP); run(20);
    CHECK(state() == ST_READY && reg_get(R_AMPLITUDE) == 0 && reg_get(R_FREQ) == 0 && !led_run);

    /* ---- overcurrent trip, latch, refusal, reset ---- */
    cmd(CMD_START); run(1200);
    CHECK(state() == ST_RUN);
    reg_write(252, 250);                                  /* I_MAX = 200 (20.0 A) */
    run(20);
    CHECK(state() == ST_FAULT && (reg_get(R_FAULT_LATCH) & F_OVERCURRENT) && reg_get(R_AMPLITUDE) == 0 && led_fault);
    cmd(CMD_START); run(20);
    CHECK(state() == ST_FAULT && reg_get(R_CMD_RES) == RES_NOT_READY);
    cmd(CMD_RESET_FAULT); run(20);
    CHECK(state() == ST_FAULT && reg_get(R_CMD_RES) == RES_NOT_READY);                   /* cause still there */
    reg_write(252, 100); run(20);
    cmd(CMD_RESET_FAULT); run(20);
    CHECK(state() == ST_READY && reg_get(R_FAULT_LATCH) == 0 && reg_get(R_CMD_RES) == RES_OK && !led_fault);

    /* ---- over / under voltage, over temperature, warning ---- */
    cmd(CMD_START); run(1200); CHECK(state() == ST_RUN);
    reg_write(251, 400); run(20);
    CHECK(state() == ST_FAULT && (reg_get(R_FAULT_LATCH) & F_OVERVOLT));
    reg_write(251, 240); run(20); cmd(CMD_RESET_FAULT); run(20); CHECK(state() == ST_READY);
    cmd(CMD_START); run(1200);
    reg_write(251, 50); run(20);
    CHECK(state() == ST_FAULT && (reg_get(R_FAULT_LATCH) & F_UNDERVOLT));
    reg_write(251, 240); run(20); cmd(CMD_RESET_FAULT); run(20);
    cmd(CMD_START); run(1200);
    reg_write(253, 650); run(600);                        /* above T_WARN 600: warning only */
    CHECK(state() == ST_RUN && (reg_get(R_FAULT_NOW) & F_TEMPWARN) && !(reg_get(R_FAULT_LATCH) & F_TEMPWARN));
    reg_write(253, 750); run(20);
    CHECK(state() == ST_FAULT && (reg_get(R_FAULT_LATCH) & F_OVERTEMP));
    CHECK(reg_get(R_FAULT_NOW) == F_OVERTEMP && reg_get(R_FAULT_LATCH) == F_OVERTEMP);   /* a trip replaces the warning bit */
    reg_write(253, 250); run(20); cmd(CMD_RESET_FAULT); run(20); CHECK(state() == ST_READY);

    /* ---- cooling flow: debounced 200 ms; can be disabled ---- */
    cmd(CMD_START); run(1200);
    in_flow = 1; run(100); in_flow = 0; run(300);
    CHECK(state() == ST_RUN);                             /* short drop: no trip */
    in_flow = 1; run(300);
    CHECK(state() == ST_FAULT && (reg_get(R_FAULT_LATCH) & F_FLOW));
    in_flow = 0; run(300); cmd(CMD_RESET_FAULT); run(20); CHECK(state() == ST_READY);
    reg_write(166, 0); in_flow = 1; run(400); CHECK(state() == ST_READY && !(reg_get(R_FAULT_NOW) & F_FLOW));
    in_flow = 0; reg_write(166, 1);
    run(300);

    /* ---- emergency stop and hardware fault with latch ---- */
    cmd(CMD_START); run(1200);
    in_estop = 1; run(30);
    CHECK(state() == ST_FAULT && (reg_get(R_FAULT_LATCH) & F_ESTOP));
    cmd(CMD_RESET_FAULT); run(20);
    CHECK(state() == ST_FAULT);                           /* e-stop still pressed */
    in_estop = 0; run(30); cmd(CMD_RESET_FAULT); run(20); CHECK(state() == ST_READY);
    cmd(CMD_START); run(1200);
    in_hw = 1; run(30);
    CHECK(state() == ST_FAULT && (reg_get(R_FAULT_LATCH) & F_HWFAULT));
    int lc = latch_clears;
    cmd(CMD_RESET_FAULT); run(20);                        /* reset pulses the latch clear line: the latch releases */
    CHECK(latch_clears > lc && state() == ST_READY);

    /* ---- master link (COMM_TIMEOUT): a status bit only, never a fault or a stop ---- */
    reg_write(165, 2);
    cmd(CMD_START);
    for (int i = 0; i < 10; i++) { run(500); reg_set(R_COM_OK, reg_get(R_COM_OK) + 1); }   /* traffic twice a second */
    CHECK(state() == ST_RUN && reg_get(R_COMM_ST) == 0);
    run(2500);                                            /* master silent for more than 2 s */
    CHECK(state() == ST_RUN && reg_get(R_COMM_ST) == 1 && reg_get(R_FAULT_NOW) == 0 && reg_get(R_FAULT_LATCH) == 0);
    reg_set(R_COM_OK, reg_get(R_COM_OK) + 1); run(20);    /* master back: the bit clears */
    CHECK(state() == ST_RUN && reg_get(R_COMM_ST) == 0);
    cmd(CMD_STOP); run(20); CHECK(state() == ST_READY);
    /* keypad / button start with the master absent: no timeout */
    run(3000);
    cmd(CMD_START); run(1200);
    CHECK(state() == ST_RUN && reg_get(R_COMM_ST) == 1 && reg_get(R_FAULT_NOW) == 0);
    cmd(CMD_STOP); run(20); reg_write(165, 0); run(20);
    CHECK(reg_get(R_COMM_ST) == 0);

    /* ---- control source: 0 local only, 1 RS-485 only, 2 both ---- */
    reg_write(132, 1);
    CHECK(reg_write(20, CMD_START) == REG_ERR_DENIED && reg_get(R_CMD_RES) == RES_DENIED);
    run(20); CHECK(state() == ST_READY);
    in_btn = 1; run(20); in_btn = 0; run(20);
    CHECK(state() == ST_READY);                           /* external button is local: refused */
    {   uint8_t rq[16] = {1, 6, 0, 20, 0, 1}, rs[16]; mb_result_t r;
        uint16_t c = crc16_modbus(rq, 6); rq[6] = c & 0xFF; rq[7] = c >> 8;
        int n = modbus_handle(rq, 8, rs, 1, &r);
        CHECK(n == 8 && r == MB_OK);
        run(20); CHECK(state() == ST_START); }
    cmd(CMD_STOP); run(20); CHECK(state() == ST_READY);   /* STOP works from anywhere */
    reg_write(132, 0);
    {   uint8_t rq[16] = {1, 6, 0, 20, 0, 1}, rs[16]; mb_result_t r;
        uint16_t c = crc16_modbus(rq, 6); rq[6] = c & 0xFF; rq[7] = c >> 8;
        int n = modbus_handle(rq, 8, rs, 1, &r);
        CHECK(n == 5 && rs[1] == 0x86 && rs[2] == 0x04);  /* refused: exception 4 */ }
    in_btn = 1; run(20); in_btn = 0; run(20);
    CHECK(state() == ST_START);                           /* local source: the button starts */
    cmd(CMD_STOP); run(20);
    reg_write(132, 2);

    /* ---- external stop button: stops from RUN, beats a start while held ---- */
    cmd(CMD_START); run(1200); CHECK(state() == ST_RUN);
    in_stop = 1; run(20); CHECK(state() == ST_READY);
    in_btn = 1; run(20); in_btn = 0; run(20);
    CHECK(state() == ST_READY);                           /* held stop blocks the start button */
    cmd(CMD_START); run(20); CHECK(state() == ST_READY);  /* ... and a start command */
    in_stop = 0; run(20);
    in_btn = 1; run(20); in_btn = 0; run(20);
    CHECK(state() == ST_START);                           /* released: start works again */
    cmd(CMD_STOP); run(20);

    /* ---- INPUTS register and INPUT_POL ---- */
    CHECK(pol_applied == 0 && reg_get(R_IO_IN) == 0);
    in_btn = 1; in_stop = 0; in_flow = 1; run(10);
    CHECK(reg_get(R_IO_IN) == (IN_START | IN_FLOW));
    in_btn = 0; in_flow = 0; in_estop = 1; in_stop = 1; run(10);
    CHECK(reg_get(R_IO_IN) == (IN_STOP | IN_ESTOP));
    in_estop = 0; in_stop = 0; run(300);
    cmd(CMD_RESET_FAULT); run(20); cmd(CMD_STOP); run(20);
    CHECK(state() == ST_READY || state() == ST_IDLE);
    run(100);
    /* polarity change: the pulls are re-set, a button that reads "active" because of the change does not start */
    CHECK(state() == ST_READY);
    reg_write(168, 1); run(5);
    CHECK(pol_applied == 1);
    in_btn = 1; run(30);
    CHECK(state() == ST_READY);                           /* inside the 50 ms hold */
    run(100);
    CHECK(state() == ST_READY);                           /* still held: no edge, no start */
    in_btn = 0; run(20); in_btn = 1; run(20); in_btn = 0; run(20);
    CHECK(state() == ST_START);                           /* a real press after the hold starts */
    cmd(CMD_STOP); run(20);
    reg_write(168, 0); run(5); CHECK(pol_applied == 0);
    run(100);
    /* power-up with the button already "pressed": no start */
    cmd(CMD_STOP); run(20);
    in_btn = 1; control_init(); run(200);
    CHECK(state() == ST_READY || state() == ST_IDLE);
    CHECK(state() != ST_START);
    in_btn = 0; run(20);

    /* ---- automatic retry after overcurrent ---- */
    reg_write(167, 2);
    cmd(CMD_START); run(1200); CHECK(state() == ST_RUN);
    reg_write(252, 250); run(20); CHECK(state() == ST_FAULT);
    reg_write(252, 0); run(2500); CHECK(state() == ST_FAULT);          /* waits 3 s */
    run(800); CHECK(state() == ST_START || state() == ST_RUN);         /* retry 1 */
    run(1200); CHECK(state() == ST_RUN);
    reg_write(252, 250); run(20); CHECK(state() == ST_FAULT);
    reg_write(252, 0); run(3500); CHECK(state() == ST_START || state() == ST_RUN);   /* retry 2 */
    run(1200);
    reg_write(252, 250); run(20); CHECK(state() == ST_FAULT);
    reg_write(252, 0); run(5000); CHECK(state() == ST_FAULT);          /* no retries left */
    cmd(CMD_RESET_FAULT); run(20); CHECK(state() == ST_READY);
    reg_write(167, 0);
    /* over-temperature is never retried */
    reg_write(167, 2);
    cmd(CMD_START); run(1200); reg_write(253, 800); run(20); CHECK(state() == ST_FAULT);
    reg_write(253, 250); run(6000); CHECK(state() == ST_FAULT);
    cmd(CMD_RESET_FAULT); run(20); reg_write(167, 0);

    /* ---- the latch keeps every fault that appears while in FAULT ---- */
    cmd(CMD_START); run(1200); CHECK(state() == ST_RUN);
    reg_write(252, 250); run(20); CHECK(state() == ST_FAULT && reg_get(R_FAULT_LATCH) == F_OVERCURRENT);
    reg_write(251, 400); run(20);
    CHECK(reg_get(R_FAULT_LATCH) == (F_OVERCURRENT | F_OVERVOLT));      /* second fault added, order not lost for the first */
    reg_write(253, 800); run(20);
    CHECK(reg_get(R_FAULT_LATCH) == (F_OVERCURRENT | F_OVERVOLT | F_OVERTEMP));
    reg_write(252, 0); reg_write(251, 240); reg_write(253, 250); run(20);
    CHECK(reg_get(R_FAULT_LATCH) == (F_OVERCURRENT | F_OVERVOLT | F_OVERTEMP) && state() == ST_FAULT);  /* stays after the cause is gone */
    cmd(CMD_RESET_FAULT); run(20); CHECK(state() == ST_READY && reg_get(R_FAULT_LATCH) == 0);

    /* ---- FAULT_FIRST: what stopped the unit first (not changed by later faults) ---- */
    cmd(CMD_START); run(1200); CHECK(state() == ST_RUN);
    reg_write(252, 250); run(20); reg_write(251, 400); run(20);
    CHECK(reg_get(R_FAULT_FIRST) == F_OVERCURRENT && reg_get(R_FAULT_LATCH) == (F_OVERCURRENT | F_OVERVOLT));
    reg_write(252, 0); reg_write(251, 240); run(20); cmd(CMD_RESET_FAULT); run(20);
    CHECK(reg_get(R_FAULT_FIRST) == 0 && reg_get(R_FAULT_LATCH) == 0);
    cmd(CMD_START); run(1200);
    reg_write(252, 250); reg_write(251, 400); run(20);                  /* two faults in the same moment */
    CHECK(reg_get(R_FAULT_FIRST) == (F_OVERCURRENT | F_OVERVOLT));
    reg_write(252, 0); reg_write(251, 240); run(20); cmd(CMD_RESET_FAULT); run(20);

    /* ---- STOP in FAULT cancels the pending retry and keeps the fault ---- */
    reg_write(167, 3);
    cmd(CMD_START); run(1200); CHECK(state() == ST_RUN);
    reg_write(252, 250); run(20); CHECK(state() == ST_FAULT);
    reg_write(252, 0); run(1000);
    cmd(CMD_STOP); run(20);
    CHECK(state() == ST_FAULT && (reg_get(R_FAULT_LATCH) & F_OVERCURRENT));
    run(6000); CHECK(state() == ST_FAULT);                              /* no retry although RETRY = 3 */
    in_stop = 1; run(20); in_stop = 0; run(20); CHECK(state() == ST_FAULT);   /* the STOP button does the same */
    cmd(CMD_RESET_FAULT); run(20); CHECK(state() == ST_READY && reg_get(R_FAULT_LATCH) == 0);
    reg_write(167, 0);
    /* STOP button while waiting for a retry */
    reg_write(167, 3);
    cmd(CMD_START); run(1200);
    reg_write(252, 250); run(20); CHECK(state() == ST_FAULT);
    reg_write(252, 0); run(500);
    in_stop = 1; run(20); in_stop = 0;
    run(6000); CHECK(state() == ST_FAULT);
    cmd(CMD_RESET_FAULT); run(20); reg_write(167, 0);

    /* ---- other commands ---- */
    cmd(CMD_REBOOT); run(20); CHECK(control_reboot_requested());
    cmd(CMD_APPLY_COMM); regs_service(); CHECK(regs_comm_changed_take());

    /* STOP is never lost when another command follows in the same loop pass */
    cmd(CMD_START); run(1200);
    cmd(CMD_STOP); cmd(CMD_REBOOT);
    run(10); CHECK(state() == ST_READY);

    /* ---- temperature derating (TEMP_DERATE, TEMP_WARN 600, TEMP_MAX 700, P_SET 20 %) ---- */
    reset_all(); sim_on(240, 0, 650);
    reg_write(169, 1);
    CHECK(derate_power(200, 600) == 200);                 /* at TEMP_WARN: full power */
    CHECK(derate_power(200, 800) == 0);                   /* above TEMP_MAX: zero */
    CHECK(derate_power(200, 650) == 100);                 /* halfway between: half */
    reg_write(169, 0);
    CHECK(derate_power(200, 650) == 200);                 /* function off: P_SET unchanged */
    reg_write(169, 0);
    run(50); cmd(CMD_START); run(3000);
    CHECK(state() == ST_RUN && reg_get(R_P_EFF) == 200);
    reg_write(169, 1); run(20);                           /* TEMP_DERATE on, T = 65.0 C -> half power */
    CHECK(reg_get(R_P_EFF) == 100);
    reg_write(253, 700); run(20); CHECK(reg_get(R_P_EFF) == 0 && state() == ST_RUN);   /* at TEMP_MAX: 0 %, no trip yet */
    reg_write(253, 600); run(20); CHECK(reg_get(R_P_EFF) == 200);                       /* back at TEMP_WARN: full */
    reg_write(253, 750); run(20); CHECK(state() == ST_FAULT && (reg_get(R_FAULT_LATCH) & F_OVERTEMP));  /* over TEMP_MAX: trip */
    reg_write(253, 250); cmd(CMD_RESET_FAULT); run(20);  /* cool down first: a reset with the cause still present is refused */
    CHECK(state() == ST_READY);
    reg_write(169, 0); run(10);

    printf(fails ? "\n%d FAILED\n" : "\nALL OK (control)\n", fails);
    return fails != 0;
}
